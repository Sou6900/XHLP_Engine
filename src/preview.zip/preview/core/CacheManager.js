// Caching parsed resources for performance
│   │