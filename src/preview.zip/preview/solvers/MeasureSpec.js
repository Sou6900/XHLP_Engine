// Android's onMeasure simulation
│   │