import { DensityConverter } from '../../device/DensityConverter.js';

export class AttributeHelper {
    constructor(solver) {
        this.solver = solver;
        this.converter = new DensityConverter();
    }

    getAttr(attr, name) {
        if (!attr) return null;
        return attr[name] || attr[`android:${name}`] || attr[`app:${name}`];
    }

    parsePx(val) {
        if (!val) return 0;
        const res = parseFloat(this.converter.parse(val));
        return isNaN(res) ? 0 : res;
    }

    getId(node) {
        const rawId = node.attributes.id || node.attributes['android:id'] || node.attributes['android:attr/id'];
        return rawId ? rawId.replace(/@\+?id\//, '') : null;
    }

    getMargin(attr, type, targetId) {
        // Handle Gone Margins
        if (type && targetId && targetId !== 'parent') {
            const targetState = this.solver.nodeMap.get(targetId);
            if (targetState) {
                const vis = this.getAttr(targetState.node.attributes, 'visibility');
                if (vis === 'gone') {
                    const goneName = `layout_goneMargin${type}`;
                    const goneVal = this.getAttr(attr, goneName);
                    if (goneVal) return this.parsePx(goneVal);
                    return 0;
                }
            }
        }

        // Standard Directional Margins
        if (type) {
            const val = this.getAttr(attr, `layout_margin${type}`);
            if (val !== undefined && val !== null) {
                return this.parsePx(val);
            }
        }

        // Axis Margins
        if (['Left', 'Right', 'Start', 'End'].includes(type)) {
            const val = this.getAttr(attr, 'layout_marginHorizontal');
            if (val !== undefined && val !== null) return this.parsePx(val);
        }

        if (['Top', 'Bottom'].includes(type)) {
            const val = this.getAttr(attr, 'layout_marginVertical');
            if (val !== undefined && val !== null) return this.parsePx(val);
        }

        // Global Margin
        const val = this.getAttr(attr, 'layout_margin');
        if (val !== undefined && val !== null) return this.parsePx(val);

        return 0;
    }
}