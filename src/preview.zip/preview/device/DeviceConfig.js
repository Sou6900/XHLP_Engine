// Screen sizes (Pixel, Nexus, Tablet)

export const DeviceConfig = {
    width: 380,
    height: 720, // 🔥 Updated based on your visual feedback (was 640)
    density: 0.8,
    scale: 0.9
};