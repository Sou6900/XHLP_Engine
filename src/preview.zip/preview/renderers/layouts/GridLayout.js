// // claude

// import { ViewGroup } from '../widgets/ViewGroup.js';

// /**
// * GridLayout - Android's grid-based layout system
// * 
// * Key Concepts:
// * - columnCount: Number of columns in the grid
// * - rowCount: Number of rows in the grid
// * - layout_column: Which column the child occupies
// * - layout_row: Which row the child occupies
// * - layout_columnSpan: How many columns the child spans
// * - layout_rowSpan: How many rows the child spans
// * - layout_columnWeight: Proportional width distribution
// * - layout_rowWeight: Proportional height distribution
// * - layout_gravity: Alignment within the cell
// */
// export class GridLayout extends ViewGroup {
//     constructor(resolver) {
//         super(resolver);
//     }

//     render(node, renderChildCallback, parentType) {
//         return this.renderWithBounds(node, 360, 640, renderChildCallback, parentType);
//     }

//     _getAttr(attr, name) {
//         if (!attr) return null;
//         return attr[name] || attr[`android:${name}`] || attr[`app:${name}`];
//     }

//     async renderWithBounds(node, width, height, renderChildCallback, parentType) {
//         const attr = node.attributes;
//         const baseStyle = await this.getBaseStyles(attr, parentType || 'ViewGroup');

//         // Grid configuration
//         const columnCount = parseInt(this._getAttr(attr, 'columnCount') || '1');
//         const rowCount = parseInt(this._getAttr(attr, 'rowCount') || '0'); // 0 = auto
//         const orientation = this._getAttr(attr, 'orientation') || 'horizontal'; // horizontal or vertical
//         const alignmentMode = this._getAttr(attr, 'alignmentMode') || 'alignBounds'; // alignBounds or alignMargins
//         const useDefaultMargins = this._getAttr(attr, 'useDefaultMargins') === 'true';
//         const columnOrderPreserved = this._getAttr(attr, 'columnOrderPreserved') !== 'false';
//         const rowOrderPreserved = this._getAttr(attr, 'rowOrderPreserved') !== 'false';

//         console.log(`[GridLayout] Config: ${columnCount} columns, ${rowCount} rows, orientation=${orientation}`);

//         // Parse padding
//         const p = this._getAttr(attr, 'padding');
//         const pl = this._parsePx(this._getAttr(attr, 'paddingLeft') || this._getAttr(attr, 'paddingStart') || p);
//         const pr = this._parsePx(this._getAttr(attr, 'paddingRight') || this._getAttr(attr, 'paddingEnd') || p);
//         const pt = this._parsePx(this._getAttr(attr, 'paddingTop') || p);
//         const pb = this._parsePx(this._getAttr(attr, 'paddingBottom') || p);

//         // Build grid cell data structure
//         const cells = this._buildGridCells(node.children, columnCount, rowCount, orientation);
        
//         console.log('[GridLayout] Built cells:', cells);

//         // Calculate column/row sizes based on weights
//         const { columnSizes, rowSizes } = this._calculateGridSizes(
//             cells, 
//             columnCount, 
//             rowCount, 
//             width - pl - pr, 
//             height - pt - pb
//         );

//         console.log('[GridLayout] Column sizes:', columnSizes);
//         console.log('[GridLayout] Row sizes:', rowSizes);

//         // Render children with calculated positions
//         const childrenHtmlArray = await Promise.all(cells.map(async cell => {
//             const child = cell.node;
//             const childAttr = child.attributes;

//             // Calculate position and size
//             let left = pl;
//             for (let i = 0; i < cell.column; i++) {
//                 left += columnSizes[i];
//             }

//             let top = pt;
//             for (let i = 0; i < cell.row; i++) {
//                 top += rowSizes[i];
//             }

//             let cellWidth = 0;
//             for (let i = 0; i < cell.columnSpan; i++) {
//                 cellWidth += columnSizes[cell.column + i] || 0;
//             }

//             let cellHeight = 0;
//             for (let i = 0; i < cell.rowSpan; i++) {
//                 cellHeight += rowSizes[cell.row + i] || 0;
//             }

//             // Handle layout_gravity within cell
//             const layoutGravity = this._getAttr(childAttr, 'layout_gravity') || '';
//             let alignStyle = '';
            
//             if (layoutGravity.includes('fill')) {
//                 alignStyle = `width: ${cellWidth}px !important; height: ${cellHeight}px !important;`;
//             } else {
//                 // Center by default if no fill
//                 alignStyle = `
//                     display: flex;
//                     justify-content: ${layoutGravity.includes('right') || layoutGravity.includes('end') ? 'flex-end' : layoutGravity.includes('center_horizontal') || layoutGravity.includes('center') ? 'center' : 'flex-start'};
//                     align-items: ${layoutGravity.includes('bottom') ? 'flex-end' : layoutGravity.includes('center_vertical') || layoutGravity.includes('center') ? 'center' : 'flex-start'};
//                     width: ${cellWidth}px;
//                     height: ${cellHeight}px;
//                 `;
//             }

//             // Render child
//             let childHtml = await renderChildCallback(child, 'GridLayout', cellWidth, cellHeight);

//             // Wrap in positioned cell
//             return `
//                 <div class="grid-cell" style="
//                     position: absolute;
//                     left: ${left}px;
//                     top: ${top}px;
//                     ${alignStyle}
//                 ">
//                     ${childHtml}
//                 </div>
//             `;
//         }));

//         // Calculate total grid height
//         const totalHeight = rowSizes.reduce((sum, h) => sum + h, 0) + pt + pb;

//         return `
//             <div class="android-layout grid-layout" style="${baseStyle} position: relative; height: ${totalHeight}px; overflow: hidden;">
//                 ${childrenHtmlArray.join('')}
//             </div>
//         `;
//     }

//     _buildGridCells(children, columnCount, rowCount, orientation) {
//         const cells = [];
//         let currentRow = 0;
//         let currentColumn = 0;

//         children.forEach((child, index) => {
//             const attr = child.attributes;

//             // Check if it's a Space (skip positioning)
//             const isSpace = child.type === 'Space';

//             // Get explicit position
//             let column = parseInt(this._getAttr(attr, 'layout_column') ?? currentColumn);
//             let row = parseInt(this._getAttr(attr, 'layout_row') ?? currentRow);
            
//             const columnSpan = parseInt(this._getAttr(attr, 'layout_columnSpan') || '1');
//             const rowSpan = parseInt(this._getAttr(attr, 'layout_rowSpan') || '1');
//             const columnWeight = parseFloat(this._getAttr(attr, 'layout_columnWeight') || '0');
//             const rowWeight = parseFloat(this._getAttr(attr, 'layout_rowWeight') || '0');

//             console.log(`[GridLayout] Child ${index}: column=${column}, row=${row}, colSpan=${columnSpan}, rowSpan=${rowSpan}, isSpace=${isSpace}`);

//             // Add cell
//             if (!isSpace) {
//                 cells.push({
//                     node: child,
//                     column,
//                     row,
//                     columnSpan,
//                     rowSpan,
//                     columnWeight,
//                     rowWeight
//                 });
//             }

//             // Update current position for next child (auto-flow)
//             if (orientation === 'horizontal') {
//                 currentColumn += columnSpan;
//                 if (currentColumn >= columnCount) {
//                     currentColumn = 0;
//                     currentRow++;
//                 }
//             } else {
//                 // Vertical orientation
//                 currentRow += rowSpan;
//                 if (rowCount > 0 && currentRow >= rowCount) {
//                     currentRow = 0;
//                     currentColumn++;
//                 }
//             }
//         });

//         return cells;
//     }

//     _calculateGridSizes(cells, columnCount, rowCount, availableWidth, availableHeight) {
//         // Initialize arrays
//         const columnSizes = new Array(columnCount).fill(0);
//         const rowSizes = new Array(rowCount || 100).fill(0); // Max 100 rows if auto
//         const columnWeights = new Array(columnCount).fill(0);
//         const rowWeights = new Array(rowCount || 100).fill(0);

//         // Collect weights
//         cells.forEach(cell => {
//             if (cell.columnWeight > 0) {
//                 for (let i = 0; i < cell.columnSpan; i++) {
//                     columnWeights[cell.column + i] = Math.max(columnWeights[cell.column + i], cell.columnWeight);
//                 }
//             }
//             if (cell.rowWeight > 0) {
//                 for (let i = 0; i < cell.rowSpan; i++) {
//                     rowWeights[cell.row + i] = Math.max(rowWeights[cell.row + i], cell.rowWeight);
//                 }
//             }
//         });

//         const totalColumnWeight = columnWeights.reduce((sum, w) => sum + w, 0);
//         const totalRowWeight = rowWeights.reduce((sum, w) => sum + w, 0);

//         console.log('[GridLayout] Column weights:', columnWeights, 'Total:', totalColumnWeight);
//         console.log('[GridLayout] Row weights:', rowWeights, 'Total:', totalRowWeight);

//         // Calculate column sizes
//         if (totalColumnWeight > 0) {
//             // Distribute based on weights
//             columnSizes.forEach((_, i) => {
//                 if (columnWeights[i] > 0) {
//                     columnSizes[i] = (availableWidth * columnWeights[i]) / totalColumnWeight;
//                 }
//             });
//         } else {
//             // Equal distribution
//             const equalWidth = availableWidth / columnCount;
//             columnSizes.fill(equalWidth);
//         }

//         // Calculate row sizes (use wrap_content approach)
//         cells.forEach(cell => {
//             // Estimate row height based on content
//             // For now, use a simple heuristic
//             const estimatedHeight = 60; // Default cell height
            
//             for (let i = 0; i < cell.rowSpan; i++) {
//                 const rowIndex = cell.row + i;
//                 rowSizes[rowIndex] = Math.max(rowSizes[rowIndex], estimatedHeight / cell.rowSpan);
//             }
//         });

//         return { columnSizes, rowSizes };
//     }

//     _parsePx(val) {
//         if (!val) return 0;
//         return parseFloat(this.converter.parse(val)) || 0;
//     }
// }




import { BaseView } from '../widgets/BaseView.js';

export class GridLayout extends BaseView {
    constructor(resolver) {
        super(resolver);
    }

    render(node, renderChildCallback, parentType) {
        return this.renderWithBounds(node, null, null, renderChildCallback, parentType);
    }

    async renderWithBounds(node, width, height, renderChildCallback, parentType) {
        const attr = node.attributes;
        const baseStyle = await this.getBaseStyles(attr, parentType || 'ViewGroup');
        const get = (name) => attr[name] || attr[`android:${name}`] || attr[`app:${name}`];

        // 1. Grid Configuration
        const columnCount = parseInt(get('columnCount') || '1');
        const rowCount = parseInt(get('rowCount') || '0');
        const orientation = get('orientation') || 'horizontal';

        // 2. Weight Calculation (Smart CSS Grid Template)
        let colTemplates = new Array(columnCount).fill('auto');
        
        let currentCol = 0;
        node.children.forEach(child => {
            const childAttr = child.attributes;
            const cGet = (n) => childAttr[n] || childAttr[`android:${n}`] || childAttr[`app:${n}`];
            
            const explicitCol = parseInt(cGet('layout_column'));
            if (!isNaN(explicitCol)) currentCol = explicitCol;

            const weight = parseFloat(cGet('layout_columnWeight') || '0');
            const span = parseInt(cGet('layout_columnSpan') || '1');

            if (weight > 0) {
                for (let i = 0; i < span; i++) {
                    if ((currentCol + i) < columnCount) {
                        colTemplates[currentCol + i] = `${weight}fr`; 
                    }
                }
            }
            
            currentCol += span;
            if (currentCol >= columnCount) currentCol = 0;
        });

        // If all columns are auto but we have items, default to 1fr to spread if needed, or keep auto
        // Better: layout_columnWeight usually implies equal width distribution if set to 1.
        
        const gridTemplateColumns = colTemplates.join(' ');

        const gridStyle = `
            display: grid;
            grid-template-columns: ${gridTemplateColumns};
            ${rowCount > 0 ? `grid-template-rows: repeat(${rowCount}, auto);` : ''}
            grid-auto-flow: ${orientation === 'vertical' ? 'column' : 'row'};
        `;

        // 3. Render Children
        const childrenHtmlArray = await Promise.all(node.children.map(async child => {
            let html = await renderChildCallback(child, 'GridLayout');

            const cAttr = child.attributes;
            const cGet = (n) => cAttr[n] || cAttr[`android:${n}`] || cAttr[`app:${n}`];

            const row = cGet('layout_row');
            const col = cGet('layout_column');
            const rowSpan = cGet('layout_rowSpan') || '1';
            const colSpan = cGet('layout_columnSpan') || '1';
            const colWeight = parseFloat(cGet('layout_columnWeight') || '0');
            const rowWeight = parseFloat(cGet('layout_rowWeight') || '0');
            
            // --- Gravity Logic (Alignment) ---
            const gravity = cGet('layout_gravity') || '';
            let justify = 'stretch'; 
            let align = 'stretch';

            // Horizontal Gravity
            if (gravity.includes('left') || gravity.includes('start')) justify = 'start';
            else if (gravity.includes('right') || gravity.includes('end')) justify = 'end';
            else if (gravity.includes('center_horizontal')) justify = 'center';
            else if (gravity.includes('fill_horizontal') || gravity.includes('fill')) justify = 'stretch';
            
            // Vertical Gravity
            if (gravity.includes('top')) align = 'start';
            else if (gravity.includes('bottom')) align = 'end';
            else if (gravity.includes('center_vertical')) align = 'center';
            else if (gravity.includes('fill_vertical') || gravity.includes('fill')) align = 'stretch';

            if (gravity === 'center') { justify = 'center'; align = 'center'; }

            // 🔥 FIX: Android Weight Behavior
            // If weight is used and no specific gravity prevents it, force fill the cell.
            // This overrides 'wrap_content' max-width behavior from BaseView.
            let sizeOverride = '';
            
            if (colWeight > 0 && justify === 'stretch') {
                sizeOverride += 'width: 100% !important;';
            }
            if (rowWeight > 0 && align === 'stretch') {
                sizeOverride += 'height: 100% !important;';
            }

            let childStyle = `
                ${row ? `grid-row-start: ${parseInt(row) + 1};` : ''}
                ${col ? `grid-column-start: ${parseInt(col) + 1};` : ''}
                grid-row-end: span ${rowSpan};
                grid-column-end: span ${colSpan};
                justify-self: ${justify} !important;
                align-self: ${align} !important;
                max-width: 100%;
                ${sizeOverride}
            `;

            return html.replace('style="', `style="${childStyle} `);
        }));

        return `
            <div class="android-layout grid-layout" style="${baseStyle} ${gridStyle}">
                ${childrenHtmlArray.join('')}
            </div>
        `;
    }
}