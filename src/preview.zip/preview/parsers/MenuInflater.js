// parsers/MenuInflater.js

export class MenuInflater {
    constructor(resolver) {
        this.resolver = resolver;
    }

    /**
     * Parses a <menu> AST and returns a flat list of item nodes
     * that Toolbar.js can render.
     */
    parse(ast) {
        const items = [];
        
        if (!ast || ast.type !== 'menu') {
            console.warn('[MenuInflater] Root tag is not <menu>');
            return items;
        }

        const traverse = (node) => {
            // শুধু <item> ট্যাগগুলো কালেক্ট করব
            if (node.type === 'item') {
                if (!node.attributes) node.attributes = {};
                
                // আইটেম নোডটি লিস্টে যোগ করি
                // Toolbar.js এটিকেই ActionMenuItemView দিয়ে রেন্ডার করবে
                items.push(node);
            }
            
            // Nested <menu> (Submenu) বা <group> থাকলে রিকার্সিভলি খুঁজব
            if (node.children) {
                node.children.forEach(traverse);
            }
        };

        if (ast.children) {
            ast.children.forEach(traverse);
        }

        console.log(`[MenuInflater] Parsed ${items.length} menu items.`);
        return items;
    }
}