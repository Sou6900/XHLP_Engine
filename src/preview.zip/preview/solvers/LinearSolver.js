// // fix for large icons in searchbar 

// import { DensityConverter } from '../device/DensityConverter.js';

// export class LinearSolver {
//     constructor() {
//         this.converter = new DensityConverter();
//     }

//     _getAttr(attr, name) {
//         if (attr[name]) return attr[name];
//         if (attr[`android:${name}`]) return attr[`android:${name}`];
//         return undefined;
//     }

//     getFlexStyle(childAttributes, parentOrientation, parentGravity, totalWeight = 0) {
//         const isVertical = parentOrientation === 'vertical';
        
//         const weightAttr = this._getAttr(childAttributes, 'layout_weight');
//         const weight = parseFloat(weightAttr || '0');
        
//         let style = '';

//         const widthAttr = this._getAttr(childAttributes, 'layout_width');
//         const heightAttr = this._getAttr(childAttributes, 'layout_height');
        
//         // 1. Cross Axis Alignment (match_parent stretches the item)
//         if (isVertical) {
//             if (widthAttr === 'match_parent') style += `width: auto !important; align-self: stretch !important; `;
//         } else {
//             if (heightAttr === 'match_parent') style += `height: auto !important; align-self: stretch !important; `;
//         }

//         const sizeAttr = isVertical ? heightAttr : widthAttr;
//         const isZeroSize = sizeAttr === '0dp' || sizeAttr === '0px' || sizeAttr === '0';

//         // 2. Main Axis Sizing (Flex behavior)
//         if (weight > 0) {
//             let flexBasis = 'auto'; 
//             if (isZeroSize) flexBasis = '0px'; 
            
//             // Weight থাকলে min-size 0 হতে হবে
//             style += `flex: ${weight} ${weight} ${flexBasis} !important; `;
            
//             if (isVertical) {
//                 style += isZeroSize ? `min-height: 0px !important;` : `min-height: min-content;`;
//             } else {
//                 style += isZeroSize ? `min-width: 0px !important;` : `min-width: min-content;`;
//             }
//         } else {
//             // No Weight
//             style += `flex: 0 0 auto !important; `; // Don't grow, Don't shrink by default
            
//             if (isVertical && heightAttr === 'wrap_content') style += `min-height: min-content; `;
//             else if (!isVertical && widthAttr === 'wrap_content') style += `min-width: min-content; `;
//         }

//         // 🔥 FIX: Enforce Fixed Dimensions with !important (Huge Icon Fix)
        
//         if (widthAttr && widthAttr !== 'match_parent' && widthAttr !== 'wrap_content' && widthAttr !== '0dp') {
//             const w = this.parsePx(widthAttr);
//             style += `width: ${w} !important; min-width: ${w} !important; max-width: ${w} !important; `;
//         }
        
//         if (heightAttr && heightAttr !== 'match_parent' && heightAttr !== 'wrap_content' && heightAttr !== '0dp') {
//             const h = this.parsePx(heightAttr);
//             style += `height: ${h} !important; min-height: ${h} !important; max-height: ${h} !important; `;
//         }

//         // 3. Max Width Constraints
//         if (isVertical && widthAttr === 'wrap_content') style += 'max-width: 100%; ';
//         if (!isVertical && heightAttr === 'wrap_content') style += 'max-height: 100%; ';

//         // 4. Gravity / Align Self
//         const layoutGravity = this._getAttr(childAttributes, 'layout_gravity');
//         if (layoutGravity) {
//             let selfAlign = '';
//             if (isVertical) {
//                 if (layoutGravity.includes('left') || layoutGravity.includes('start')) selfAlign = 'flex-start';
//                 else if (layoutGravity.includes('right') || layoutGravity.includes('end')) selfAlign = 'flex-end';
//                 else if (layoutGravity.includes('center_horizontal') || layoutGravity.includes('center')) selfAlign = 'center';
//                 else if (layoutGravity.includes('fill_horizontal') || layoutGravity.includes('fill')) selfAlign = 'stretch';
//             } else {
//                 if (layoutGravity.includes('top')) selfAlign = 'flex-start';
//                 else if (layoutGravity.includes('bottom')) selfAlign = 'flex-end';
//                 else if (layoutGravity.includes('center_vertical') || layoutGravity.includes('center')) selfAlign = 'center';
//                 else if (layoutGravity.includes('fill_vertical') || layoutGravity.includes('fill')) selfAlign = 'stretch';
//             }
//             if (selfAlign) style += `align-self: ${selfAlign} !important;`;
//         }

//         // 5. Margins
//         const mAll = this._getAttr(childAttributes, 'layout_margin');
//         const mHoriz = this._getAttr(childAttributes, 'layout_marginHorizontal');
//         const mVert = this._getAttr(childAttributes, 'layout_marginVertical');

//         const mt = this._getAttr(childAttributes, 'layout_marginTop') || mVert || mAll;
//         const mb = this._getAttr(childAttributes, 'layout_marginBottom') || mVert || mAll;
//         const mStart = this._getAttr(childAttributes, 'layout_marginStart') || mHoriz || mAll;
//         const mEnd = this._getAttr(childAttributes, 'layout_marginEnd') || mHoriz || mAll;
//         const mLeft = this._getAttr(childAttributes, 'layout_marginLeft') || mHoriz || mAll;
//         const mRight = this._getAttr(childAttributes, 'layout_marginRight') || mHoriz || mAll;

//         if (mt) style += `margin-top: ${this.parsePx(mt)} !important;`;
//         if (mb) style += `margin-bottom: ${this.parsePx(mb)} !important;`;
//         if (mStart) style += `margin-inline-start: ${this.parsePx(mStart)} !important;`;
//         if (mEnd) style += `margin-inline-end: ${this.parsePx(mEnd)} !important;`;
        
//         // Fallbacks
//         if (!mStart && mLeft) style += `margin-left: ${this.parsePx(mLeft)} !important;`;
//         if (!mEnd && mRight) style += `margin-right: ${this.parsePx(mRight)} !important;`;

//         return style;
//     }
    
//     // 🔥 FIX: Double 'px' issue solved here
//     parsePx(val) {
//         if (!val) return '0px';
//         if (typeof val === 'number') return `${val}px`;
        
//         let res = val;
//         // Use DensityConverter if available for complex units (dp/sp)
//         if (this.converter && (val.endsWith('dp') || val.endsWith('sp'))) {
//             res = this.converter.parse(val);
//         }
        
//         // Check if result already has 'px', if so, return as is.
//         return String(res).endsWith('px') ? res : `${parseFloat(res) || 0}px`;
//     }
// }



import { DensityConverter } from '../device/DensityConverter.js';

export class LinearSolver {
    constructor() {
        this.converter = new DensityConverter();
    }

    _getAttr(attr, name) {
        if (attr[name]) return attr[name];
        if (attr[`android:${name}`]) return attr[`android:${name}`];
        if (attr[`app:${name}`]) return attr[`app:${name}`];
        return undefined;
    }

    getFlexStyle(childAttributes, parentOrientation, parentGravity, totalWeight = 0) {
        const isVertical = parentOrientation === 'vertical';
        
        const weightAttr = this._getAttr(childAttributes, 'layout_weight');
        const weight = parseFloat(weightAttr || '0');
        
        let style = '';

        const widthAttr = this._getAttr(childAttributes, 'layout_width');
        const heightAttr = this._getAttr(childAttributes, 'layout_height');
        
        // --- 1. Calculate Margins First (Needed for Width Calculation) ---
        const mAll = this._getAttr(childAttributes, 'layout_margin');
        const mHoriz = this._getAttr(childAttributes, 'layout_marginHorizontal');
        const mVert = this._getAttr(childAttributes, 'layout_marginVertical');

        const mtAttr = this._getAttr(childAttributes, 'layout_marginTop') || mVert || mAll;
        const mbAttr = this._getAttr(childAttributes, 'layout_marginBottom') || mVert || mAll;
        const mStartAttr = this._getAttr(childAttributes, 'layout_marginStart') || mHoriz || mAll;
        const mEndAttr = this._getAttr(childAttributes, 'layout_marginEnd') || mHoriz || mAll;
        const mLeftAttr = this._getAttr(childAttributes, 'layout_marginLeft') || mHoriz || mAll;
        const mRightAttr = this._getAttr(childAttributes, 'layout_marginRight') || mHoriz || mAll;

        // Convert to numeric values for calc() logic
        const mtVal = this.parsePxVal(mtAttr);
        const mbVal = this.parsePxVal(mbAttr);
        const mlVal = this.parsePxVal(mStartAttr || mLeftAttr);
        const mrVal = this.parsePxVal(mEndAttr || mRightAttr);

        // --- 2. Cross Axis Alignment & Match Parent Fix ---
        if (isVertical) {
            if (widthAttr === 'match_parent') {
                // Subtract margins from 100% to prevent overflow
                const widthCalc = `calc(100% - ${mlVal + mrVal}px)`;
                style += `width: ${widthCalc} !important; align-self: stretch !important; `;
            }
        } else {
            if (heightAttr === 'match_parent') {
                const heightCalc = `calc(100% - ${mtVal + mbVal}px)`;
                style += `height: ${heightCalc} !important; align-self: stretch !important; `;
            }
        }

        const sizeAttr = isVertical ? heightAttr : widthAttr;
        const isZeroSize = sizeAttr === '0dp' || sizeAttr === '0px' || sizeAttr === '0';

        // --- 3. Main Axis Sizing (Flex behavior) ---
        if (weight > 0) {
            let flexBasis = 'auto'; 
            if (isZeroSize) flexBasis = '0px'; 
            
            style += `flex: ${weight} ${weight} ${flexBasis} !important; `;
            
            if (isVertical) {
                style += isZeroSize ? `min-height: 0px !important;` : `min-height: min-content;`;
            } else {
                style += isZeroSize ? `min-width: 0px !important;` : `min-width: min-content;`;
            }
        } else {
            // No Weight
            
            // 🔥 FIX: Allow shrinking for match_parent to prevent overflow
            // If match_parent is used in a horizontal layout with siblings, it forces overflow.
            // We set flex-shrink: 1 (via '0 1 auto') so it yields space to siblings.
            
            const isMatchParentMain = (!isVertical && widthAttr === 'match_parent') || 
                                      (isVertical && heightAttr === 'match_parent');
            
            const isWrapContent = sizeAttr === 'wrap_content';

            if (isMatchParentMain || isWrapContent) {
                 // Allow shrink
                 style += `flex: 0 1 auto !important; `;
            } else {
                 // Fixed size (e.g. 50dp) -> Don't grow, Don't shrink
                 style += `flex: 0 0 auto !important; `; 
            }
            
            if (isVertical && heightAttr === 'wrap_content') style += `min-height: min-content; `;
            else if (!isVertical && widthAttr === 'wrap_content') style += `min-width: min-content; `;
        }

        // --- 4. Enforce Fixed Dimensions ---
        // We skip this for match_parent to allow the calc() above or flex-shrink to work
        if (widthAttr && widthAttr !== 'match_parent' && widthAttr !== 'wrap_content' && widthAttr !== '0dp') {
             const w = this.parsePx(widthAttr);
             style += `width: ${w} !important; min-width: ${w} !important; max-width: ${w} !important; `;
        }
        
        if (heightAttr && heightAttr !== 'match_parent' && heightAttr !== 'wrap_content' && heightAttr !== '0dp') {
             const h = this.parsePx(heightAttr);
             style += `height: ${h} !important; min-height: ${h} !important; max-height: ${h} !important; `;
        }

        // --- 5. Max Constraints ---
        if (isVertical && widthAttr === 'wrap_content') style += 'max-width: 100%; ';
        if (!isVertical && heightAttr === 'wrap_content') style += 'max-height: 100%; ';

        // --- 6. Gravity / Align Self ---
        const layoutGravity = this._getAttr(childAttributes, 'layout_gravity');
        if (layoutGravity) {
            let selfAlign = '';
            if (isVertical) {
                if (layoutGravity.includes('left') || layoutGravity.includes('start')) selfAlign = 'flex-start';
                else if (layoutGravity.includes('right') || layoutGravity.includes('end')) selfAlign = 'flex-end';
                else if (layoutGravity.includes('center_horizontal') || layoutGravity.includes('center')) selfAlign = 'center';
                else if (layoutGravity.includes('fill_horizontal') || layoutGravity.includes('fill')) selfAlign = 'stretch';
            } else {
                if (layoutGravity.includes('top')) selfAlign = 'flex-start';
                else if (layoutGravity.includes('bottom')) selfAlign = 'flex-end';
                else if (layoutGravity.includes('center_vertical') || layoutGravity.includes('center')) selfAlign = 'center';
                else if (layoutGravity.includes('fill_vertical') || layoutGravity.includes('fill')) selfAlign = 'stretch';
            }
            if (selfAlign) style += `align-self: ${selfAlign} !important;`;
        }

        // --- 7. Apply Margins ---
        if (mtAttr) style += `margin-top: ${mtVal}px !important;`;
        if (mbAttr) style += `margin-bottom: ${mbVal}px !important;`;
        if (mStartAttr) style += `margin-inline-start: ${mlVal}px !important;`;
        if (mEndAttr) style += `margin-inline-end: ${mrVal}px !important;`;
        
        // Fallbacks for physical margins
        if (!mStartAttr && mLeftAttr) style += `margin-left: ${mlVal}px !important;`;
        if (!mEndAttr && mRightAttr) style += `margin-right: ${mrVal}px !important;`;

        return style;
    }
    
    // Returns string '10px'
    parsePx(val) {
        if (!val) return '0px';
        const num = this.parsePxVal(val);
        return `${num}px`;
    }

    // Returns number 10
    parsePxVal(val) {
        if (!val) return 0;
        if (typeof val === 'number') return val;
        
        let res = val;
        // Use DensityConverter if available
        if (this.converter && (val.endsWith('dp') || val.endsWith('sp'))) {
            res = this.converter.parse(val); 
        }
        
        // Strip 'px' and parse float
        return parseFloat(String(res).replace('px', '')) || 0;
    }
}