// rtl fix
import { DebugLogger } from './utils/DebugLogger.js';
import { AttributeHelper } from './utils/AttributeHelper.js';
import { GuidelineResolver } from './constraint/GuidelineResolver.js';
import { DimensionEstimator } from './constraint/DimensionEstimator.js';
import { ChainSolver } from './constraint/ChainSolver.js';
import { HorizontalSolver } from './constraint/HorizontalSolver.js';
import { VerticalSolver } from './constraint/VerticalSolver.js';
import { CircularSolver } from './constraint/CircularSolver.js'; 
import { FlowSolver } from './constraint/FlowSolver.js'; 

export class ConstraintSolver {
    constructor(resourceResolver) {
        this.resolver = resourceResolver;
        this.nodeMap = new Map();
        this.parentW = 360;
        this.parentH = 640;
        this.padding = { left: 0, top: 0, right: 0, bottom: 0 };
        this.debugMode = true;
        this.isRTL = false ;

        // Initialize Modules
        this.logger = new DebugLogger(this.debugMode);
        this.helper = new AttributeHelper(this);
        this.guidelineResolver = new GuidelineResolver(this);
        this.estimator = new DimensionEstimator(this);
        this.chainSolver = new ChainSolver(this);
        this.horizontalSolver = new HorizontalSolver(this);
        this.verticalSolver = new VerticalSolver(this);
        this.circularSolver = new CircularSolver(this); 
        this.flowSolver = new FlowSolver(this);

        if (typeof document !== 'undefined') {
            this.canvas = document.createElement('canvas');
            this.ctx = this.canvas.getContext('2d');
        }
    }

    solve(children, parentWidth, parentHeight, padding = { left: 0, top: 0, right: 0, bottom: 0 }, isRTL = false, isWrapContentHeight = false) {
        this.parentW = parentWidth || 360;
        this.parentH = parentHeight || 640;
        this.padding = padding;
        this.nodeMap.clear();

        this.logger.log('solve', '━━━━━━━━━━━━━━━━ START ━━━━━━━━━━━━━━━━');

        // Phase 1: Guidelines
        this.guidelineResolver.resolve(children);

        // Phase 2: Estimates & Ratios
        this.estimator.estimateAll(children);
        this.applyDimensionRatios(children);

        // Phase 3: Chains
        this.chainSolver.detectChains(children);

        // Phase 4: Main Loop (Flow & Multi-pass)
        this._runSolverLoop(children, isWrapContentHeight);

        // Phase 5: Result Generation
        const resultStyles = new Map();
        this.nodeMap.forEach((state, id) => {
            const isGuide = state.isGuideline;
            
            // 🔥 FIX: Android Pixel Snapping (Round to nearest integer)
            const finalX = Math.round(state.x);
            const finalY = Math.round(state.y);
            const finalW = Math.round(state.w);
            const finalH = Math.round(state.h);

            const css = `
                position: absolute !important;
                left: ${finalX}px !important;
                top: ${finalY}px !important;
                width: ${isGuide ? 0 : finalW}px !important;
                height: ${isGuide ? 0 : finalH}px !important;
                margin: 0 !important;
                display: ${isGuide ? 'none' : 'flex'};
            `;
            resultStyles.set(id, { css, width: finalW, height: finalH, x: finalX, y: finalY, isGuideline: isGuide });
        });

        this.logger.log('solve', '━━━━━━━━━━━━━━━━ END ━━━━━━━━━━━━━━━━');
        return resultStyles;
    }

    _runSolverLoop(children, isMeasuring) {
        if (!isMeasuring) {
            this.nodeMap.forEach(s => {
                s.solvedY = false;
                s.solvedX = false;
            });
        }

        // Phase 2.5: Pre-Solve Virtual Layouts (Flow)
        this.flowSolver.solve(children);

        for (let pass = 0; pass < 6; pass++) {
            children.forEach(node => {
                const id = this.helper.getId(node);
                if (!id) return;
                const state = this.nodeMap.get(id);
                
                // 🔥 CRITICAL FIX 1: গাইডলাইনগুলোকে লুপ থেকে স্কিপ করুন
                // না করলে তাদের পজিশন ০ হয়ে যায় এবং চাইল্ডরা ভুল জায়গায় বসে।
                if (state.isGuideline) return;

                // Optimization: Skip if already solved by Flow
                // if (state.solvedX && state.solvedY) return;

                const hasCircle = this.helper.getAttr(node.attributes, 'layout_constraintCircle');
                
                if (hasCircle) {
                    this.circularSolver.solve(state, node.attributes);
                } else {
                    // Horizontal Logic
                    if (!state.inHorizontalChain) {
                        this.horizontalSolver.solve(state, node.attributes);
                    } else if (pass >= 0 && state.horizontalChain) { 
                        this.chainSolver.solveChainHorizontal(state);
                    }
                    
                    // Vertical Chain Logic
                    if (!state.inVerticalChain) {
                        this.verticalSolver.solve(state, node.attributes, isMeasuring);
                    } else if (pass >= 0 && state.verticalChain) { 
                        this.chainSolver.solveChainVertical(state);
                    }
                }

                // Wrap Content Height Measurement (TextView/Button)
                if ((node.type.includes('TextView') || node.type.includes('Button')) && state.w > 0) {
                    const hAttr = this.helper.getAttr(node.attributes, 'layout_height');
                    if (hAttr === 'wrap_content') {
                        state.h = this.estimator.estimateHeight(node, state.w);
                    }
                }

                this.applySingleRatio(state, node.attributes);
            });
        }
        
        // 🔥 CRITICAL FIX 2: Wrap Content Height ক্যালকুলেশন
        // যদি কন্টেইনার wrap_content হয়, তবে সবচেয়ে নিচে থাকা ভিউ অনুযায়ী হাইট সেট করতে হবে।
        if (isMeasuring) {
            let maxBottom = 0;
            this.nodeMap.forEach(s => {
                if (!s.isGuideline) maxBottom = Math.max(maxBottom, s.y + s.h);
            });
            this.parentH = maxBottom + this.padding.bottom;
        }
    }

    getPos(ref, edge) {
        if (!ref || ref === 'parent') {
            if (edge === 'left' || edge === 'start') return this.padding.left;
            if (edge === 'right' || edge === 'end') return this.parentW - this.padding.right;
            if (edge === 'top') return this.padding.top;
            if (edge === 'bottom') return this.parentH - this.padding.bottom;
            return 0;
        }

        const id = ref.replace(/@\+?id\//, '');
        const state = this.nodeMap.get(id);

        if (!state) return 0;

        if (state.isGuideline) {
            return (state.guideX !== null) ? state.guideX : (state.guideY !== null ? state.guideY : 0);
        }

        switch (edge) {
            case 'left': case 'start': return state.x;
            case 'right': case 'end': return state.x + state.w;
            case 'top': return state.y;
            case 'bottom': return state.y + state.h;
            default: return 0;
        }
    }

    applyDimensionRatios(children) {
        children.forEach(node => {
            const id = this.helper.getId(node);
            const state = this.nodeMap.get(id);
            if (state) this.applySingleRatio(state, node.attributes);
        });
    }

    applySingleRatio(state, attr) {
        const ratioStr = this.helper.getAttr(attr, 'layout_constraintDimensionRatio');
        if (!ratioStr) return;

        const parts = ratioStr.split(',');
        let ratioVal = parts.length > 1 ? parts[1] : parts[0];
        if (ratioVal.includes(':') === false && parts.length > 1) ratioVal = parts[1];

        let side = null;
        if (parts.length > 1) side = parts[0];

        const dims = ratioVal.split(':');
        if (dims.length !== 2) return;

        const ratio = parseFloat(dims[0]) / parseFloat(dims[1]);
        const wMode = this.helper.getAttr(attr, 'layout_width');
        const hMode = this.helper.getAttr(attr, 'layout_height');

        if (wMode === '0dp' && hMode === '0dp') {
            const hasVConstraints = (this.helper.getAttr(attr, 'layout_constraintTop_toTopOf') || this.helper.getAttr(attr, 'layout_constraintTop_toBottomOf')) &&
                                    (this.helper.getAttr(attr, 'layout_constraintBottom_toBottomOf') || this.helper.getAttr(attr, 'layout_constraintBottom_toTopOf'));

            if (side === 'H') {
                state.w = state.boundW;
                state.h = state.w / ratio;
            } else if (side === 'W') {
                state.h = state.boundH;
                state.w = state.h * ratio;
            } else {
                let availableW = state.boundW;
                let availableH = state.boundH;

                if (availableW > 0 && !hasVConstraints) {
                    state.w = availableW;
                    state.h = state.w / ratio;
                } else {
                    if (availableW / availableH > ratio) {
                        state.h = availableH;
                        state.w = state.h * ratio;
                    } else {
                        state.w = availableW;
                        state.h = state.w / ratio;
                    }
                    const hBias = parseFloat(this.helper.getAttr(attr, 'layout_constraintHorizontal_bias') || '0.5');
                    const vBias = parseFloat(this.helper.getAttr(attr, 'layout_constraintVertical_bias') || '0.5');
                    state.x += (availableW - state.w) * (this.isRTL ? (1 - hBias) : hBias);
                    state.y += (availableH - state.h) * vBias;
                }
            }
        } else if (wMode === '0dp') {
            state.w = state.h * ratio;
        } else if (hMode === '0dp') {
            state.h = state.w / ratio;
        }
    }
}