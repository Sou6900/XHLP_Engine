// export class HorizontalSolver {
//     constructor(solver) {
//         this.solver = solver;
//         this.helper = solver.helper;
//     }

//     solve(state, attr) {
//         if (state.node.type.includes('Barrier')) {
//             this.solveBarrier(state, attr);
//             return;
//         }
        
//         const startToStart = this.helper.getAttr(attr, 'layout_constraintStart_toStartOf') || this.helper.getAttr(attr, 'layout_constraintLeft_toLeftOf');
//         const startToEnd = this.helper.getAttr(attr, 'layout_constraintStart_toEndOf') || this.helper.getAttr(attr, 'layout_constraintLeft_toRightOf');
//         const endToEnd = this.helper.getAttr(attr, 'layout_constraintEnd_toEndOf') || this.helper.getAttr(attr, 'layout_constraintRight_toRightOf');
//         const endToStart = this.helper.getAttr(attr, 'layout_constraintEnd_toStartOf') || this.helper.getAttr(attr, 'layout_constraintRight_toLeftOf');

//         const targetStart = (startToStart || startToEnd || '').replace(/@\+?id\//, '');
//         const targetEnd = (endToEnd || endToStart || '').replace(/@\+?id\//, '');

//         let mStart = this.helper.getMargin(attr, 'Start', targetStart) || 
//                     this.helper.getMargin(attr, 'Left', targetStart) || 
//                     this.helper.getMargin(attr, '', targetStart) || 0;

//         let mEnd = this.helper.getMargin(attr, 'End', targetEnd) || 
//                   this.helper.getMargin(attr, 'Right', targetEnd) || 
//                   this.helper.getMargin(attr, '', targetEnd) || 0;

//         let anchorStart = null, anchorEnd = null;

//         if (!this.solver.isRTL) {
//             if (startToStart) anchorStart = this.solver.getPos(startToStart, 'left');
//             else if (startToEnd) anchorStart = this.solver.getPos(startToEnd, 'right');

//             if (endToEnd) anchorEnd = this.solver.getPos(endToEnd, 'right');
//             else if (endToStart) anchorEnd = this.solver.getPos(endToStart, 'left');
//         } else {
//             if (startToStart) anchorStart = this.solver.getPos(startToStart, 'right');
//             else if (startToEnd) anchorStart = this.solver.getPos(startToEnd, 'left');

//             if (endToEnd) anchorEnd = this.solver.getPos(endToEnd, 'left');
//             else if (endToStart) anchorEnd = this.solver.getPos(endToStart, 'right');
//         }

//         const wAttr = this.helper.getAttr(attr, 'layout_width');
//         let calculatedW = state.w;

//         // 🔥 FIX: Parse minWidth
//         const minW = this.helper.parsePx(this.helper.getAttr(attr, 'minWidth')) || 0;

//         const widthPercent = this.helper.getAttr(attr, 'layout_constraintWidth_percent');
//         if (widthPercent && wAttr === '0dp') {
//             calculatedW = this.solver.parentW * parseFloat(widthPercent);
            
//             // 🔥 APPLY MIN WIDTH CHECK
//             calculatedW = Math.max(calculatedW, minW);
            
//             state.w = calculatedW;
//             state.boundW = calculatedW;
//         } else if (wAttr === '0dp' || wAttr === 'match_parent') {
//             if (anchorStart !== null && anchorEnd !== null) {
//                 calculatedW = Math.abs(anchorEnd - anchorStart) - mStart - mEnd;
//             } else if (wAttr === 'match_parent') {
//                 calculatedW = this.solver.parentW - (this.solver.padding.left + this.solver.padding.right + mStart + mEnd);
//             }
            
//             // 🔥 APPLY MIN WIDTH CHECK
//             calculatedW = Math.max(0, Math.max(calculatedW, minW));
            
//             state.w = calculatedW;
//             state.boundW = calculatedW;
//         }
        
//         // Wrap Content এর ক্ষেত্রেও minWidth চেক করা উচিত (যদি আগে সেট না হয়ে থাকে)
//         if (wAttr === 'wrap_content') {
//             state.w = Math.max(state.w, minW);
//         }

//         if (anchorStart !== null && anchorEnd !== null && !widthPercent) {
//             const bias = parseFloat(this.helper.getAttr(attr, 'layout_constraintHorizontal_bias') || '0.5');
//             let availableSpace;
//             if (!this.solver.isRTL) {
//                 availableSpace = anchorEnd - anchorStart - state.w - mStart - mEnd; // Use state.w (final width)
//                 state.x = anchorStart + mStart + (availableSpace * bias);
//             } else {
//                 availableSpace = anchorStart - anchorEnd - state.w - mStart - mEnd;
//                 state.x = anchorEnd + mEnd + (availableSpace * (1 - bias));
//             }
//             state.alignment = 'center';
//         } else if (anchorStart !== null && anchorEnd !== null && widthPercent) {
//             // Percent handling with centering logic (reuse logic)
//             const bias = parseFloat(this.helper.getAttr(attr, 'layout_constraintHorizontal_bias') || '0.5');
//             let availableSpace;
//             if (!this.solver.isRTL) {
//                 availableSpace = anchorEnd - anchorStart - state.w - mStart - mEnd;
//                 state.x = anchorStart + mStart + (availableSpace * bias);
//             } else {
//                 availableSpace = anchorStart - anchorEnd - state.w - mStart - mEnd;
//                 state.x = anchorEnd + mEnd + (availableSpace * (1 - bias));
//             }
//             state.alignment = 'center';
//         } else if (anchorStart !== null) {
//             if (!this.solver.isRTL) state.x = anchorStart + mStart;
//             else state.x = anchorStart - state.w - mStart;
//             state.alignment = 'start';
//         } else if (anchorEnd !== null) {
//             if (!this.solver.isRTL) state.x = anchorEnd - state.w - mEnd;
//             else state.x = anchorEnd + mEnd;
//             state.alignment = 'end';
//         } else {
//             if (!this.solver.isRTL) state.x = this.solver.padding.left + mStart;
//             else state.x = (this.solver.parentW - this.solver.padding.right) - state.w - mStart;
//             state.alignment = 'start';
//         }
//     }
    
//     solveBarrier(state, attr) {
//         const direction = this.helper.getAttr(attr, 'barrierDirection');
//         const referencedIds = this.helper.getAttr(attr, 'constraint_referenced_ids');
//         if (!referencedIds) return;
//         if (['start', 'end', 'left', 'right'].includes(direction)) {
//             const ids = referencedIds.split(',').map(id => id.trim());
//             let maxVal = -Infinity;
//             let minVal = Infinity;
//             let hasTarget = false;
//             ids.forEach(refId => {
//                 const refState = this.solver.nodeMap.get(refId);
//                 if (refState) {
//                     hasTarget = true;
//                     if (direction === 'end' || direction === 'right') {
//                         const rightEdge = refState.x + refState.w;
//                         if (rightEdge > maxVal) maxVal = rightEdge;
//                     } else {
//                         if (refState.x < minVal) minVal = refState.x;
//                     }
//                 }
//             });
//             if (hasTarget) {
//                 if (direction === 'end' || direction === 'right') {
//                     state.x = maxVal;
//                 } else {
//                     state.x = minVal;
//                 }
//                 state.w = 0; 
//             }
//         }
//     }
// }



export class HorizontalSolver {
    constructor(solver) {
        this.solver = solver;
        this.helper = solver.helper;
    }

    solve(state, attr) {
        if (state.node.type.includes('Barrier')) {
            this.solveBarrier(state, attr);
            return;
        }
        
        const startToStart = this.helper.getAttr(attr, 'layout_constraintStart_toStartOf') || this.helper.getAttr(attr, 'layout_constraintLeft_toLeftOf');
        const startToEnd = this.helper.getAttr(attr, 'layout_constraintStart_toEndOf') || this.helper.getAttr(attr, 'layout_constraintLeft_toRightOf');
        const endToEnd = this.helper.getAttr(attr, 'layout_constraintEnd_toEndOf') || this.helper.getAttr(attr, 'layout_constraintRight_toRightOf');
        const endToStart = this.helper.getAttr(attr, 'layout_constraintEnd_toStartOf') || this.helper.getAttr(attr, 'layout_constraintRight_toLeftOf');

        const targetStart = (startToStart || startToEnd || '').replace(/@\+?id\//, '');
        const targetEnd = (endToEnd || endToStart || '').replace(/@\+?id\//, '');

        let mStart = this.helper.getMargin(attr, 'Start', targetStart) || 
                     this.helper.getMargin(attr, 'Left', targetStart) || 
                     this.helper.getMargin(attr, '', targetStart) || 0;

        let mEnd = this.helper.getMargin(attr, 'End', targetEnd) || 
                   this.helper.getMargin(attr, 'Right', targetEnd) || 
                   this.helper.getMargin(attr, '', targetEnd) || 0;

        let anchorStart = null, anchorEnd = null;

        if (!this.solver.isRTL) {
            if (startToStart) anchorStart = this.solver.getPos(startToStart, 'left');
            else if (startToEnd) anchorStart = this.solver.getPos(startToEnd, 'right');

            if (endToEnd) anchorEnd = this.solver.getPos(endToEnd, 'right');
            else if (endToStart) anchorEnd = this.solver.getPos(endToStart, 'left');
        } else {
            if (startToStart) anchorStart = this.solver.getPos(startToStart, 'right');
            else if (startToEnd) anchorStart = this.solver.getPos(startToEnd, 'left');

            if (endToEnd) anchorEnd = this.solver.getPos(endToEnd, 'left');
            else if (endToStart) anchorEnd = this.solver.getPos(endToStart, 'right');
        }

        const wAttr = this.helper.getAttr(attr, 'layout_width');
        const minW = this.helper.parsePx(this.helper.getAttr(attr, 'minWidth')) || 0;
        const widthPercent = this.helper.getAttr(attr, 'layout_constraintWidth_percent');

        // 🔥 FIX: 0dp (match_constraint) and match_parent Width Calculation
        if (widthPercent && wAttr === '0dp') {
            state.w = this.solver.parentW * parseFloat(widthPercent);
        } else if (wAttr === '0dp' || wAttr === 'match_constraint') {
            if (anchorStart !== null && anchorEnd !== null) {
                state.w = Math.abs(anchorEnd - anchorStart) - mStart - mEnd;
            }
        } else if (wAttr === 'match_parent') {
            state.w = this.solver.parentW - (this.solver.padding.left + this.solver.padding.right + mStart + mEnd);
        } else if (wAttr === 'wrap_content') {
            // Keep current wrap_content width but ensure it's at least minW
        }

        // Apply minWidth constraint
        state.w = Math.max(state.w, minW);
        state.boundW = state.w;

        // 🔥 FIX: Positioning and Centering Logic
        if (anchorStart !== null && anchorEnd !== null) {
            const bias = parseFloat(this.helper.getAttr(attr, 'layout_constraintHorizontal_bias') || '0.5');
            const availableSpace = Math.abs(anchorEnd - anchorStart) - state.w - mStart - mEnd;
            
            if (!this.solver.isRTL) {
                state.x = anchorStart + mStart + (availableSpace * bias);
            } else {
                state.x = anchorEnd + mEnd + (availableSpace * (1 - bias));
            }
            state.alignment = 'center';
        } else if (anchorStart !== null) {
            if (!this.solver.isRTL) state.x = anchorStart + mStart;
            else state.x = anchorStart - state.w - mStart;
            state.alignment = 'start';
        } else if (anchorEnd !== null) {
            if (!this.solver.isRTL) state.x = anchorEnd - state.w - mEnd;
            else state.x = anchorEnd + mEnd;
            state.alignment = 'end';
        } else {
            if (!this.solver.isRTL) state.x = this.solver.padding.left + mStart;
            else state.x = (this.solver.parentW - this.solver.padding.right) - state.w - mStart;
            state.alignment = 'start';
        }
    }
    
    solveBarrier(state, attr) {
        const direction = this.helper.getAttr(attr, 'barrierDirection');
        const referencedIds = this.helper.getAttr(attr, 'constraint_referenced_ids');
        if (!referencedIds) return;
        if (['start', 'end', 'left', 'right'].includes(direction)) {
            const ids = referencedIds.split(',').map(id => id.trim());
            let maxVal = -Infinity;
            let minVal = Infinity;
            let hasTarget = false;
            ids.forEach(refId => {
                const refState = this.solver.nodeMap.get(refId);
                if (refState) {
                    hasTarget = true;
                    if (direction === 'end' || direction === 'right') {
                        const rightEdge = refState.x + refState.w;
                        if (rightEdge > maxVal) maxVal = rightEdge;
                    } else {
                        if (refState.x < minVal) minVal = refState.x;
                    }
                }
            });
            if (hasTarget) {
                if (direction === 'end' || direction === 'right') {
                    state.x = maxVal;
                } else {
                    state.x = minVal;
                }
                state.w = 0; 
            }
        }
    }
}