export class XmlParser {
    parse(xmlString) {
        if (!xmlString || xmlString.trim() === '') return null;

        try {
            let cleanXml = xmlString
                // 1. Remove XML declaration & comments
                .replace(/<\?xml.*?\?>/g, '')
                .replace(/<!--[\s\S]*?-->/g, '');

            // 2. 🔥 AGGRESSIVE NAMESPACE STRIPPING
            // Removes "android:", "app:", "tools:" anywhere they appear as a prefix
            // This fixes issues where whitespace/tabs prevented the previous regex from matching
            cleanXml = cleanXml.replace(/(android|app|tools):/g, '');

            // 3. Remove xmlns definitions (now that prefixes are gone, these might look like 'xmlns="..."')
            cleanXml = cleanXml.replace(/\sxmlns\w*="[^"]*"/g, '');

            // 4. Parse
            const parser = new DOMParser();
            const doc = parser.parseFromString(cleanXml, 'text/xml');

            const errorNode = doc.querySelector('parsererror');
            if (errorNode) {
                console.error('XML Raw Error:', errorNode.textContent);
                throw new Error('Invalid XML Structure');
            }

            return this._elementToNode(doc.documentElement);

        } catch (e) {
            console.error('❌ [XmlParser]', e.message);
            return {
                type: 'TextView',
                attributes: {
                    text: `XML Error: ${e.message}`,
                    textColor: '#FF0000',
                    gravity: 'center'
                },
                children: []
            };
        }
    }

    _elementToNode(element) {
        if (!element) return null;

        const node = {
            type: element.tagName,
            attributes: {},
            children: []
        };

        if (element.attributes) {
            for (let i = 0; i < element.attributes.length; i++) {
                const attr = element.attributes[i];
                // Attribute names are already clean due to step 2
                node.attributes[attr.name] = attr.value;
            }
        }

        if (element.children) {
            for (let i = 0; i < element.children.length; i++) {
                const childNode = this._elementToNode(element.children[i]);
                if (childNode) node.children.push(childNode);
            }
        }

        return node;
    }
}