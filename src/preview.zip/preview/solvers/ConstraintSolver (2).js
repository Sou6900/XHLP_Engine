// ConstraintSolver.js V2.4 - Button Height Sync & Vertical Alignment Fix
import { DensityConverter } from '../device/DensityConverter.js';
import { TextMeasurer } from '../text/TextMeasurer.js';

export class ConstraintSolver {
    constructor(resourceResolver) {
        this.converter = new DensityConverter();
        this.resolver = resourceResolver;
        this.measurer = new TextMeasurer();
        this.nodeMap = new Map();
        this.parentW = 360;
        this.parentH = 640;
        this.padding = { left: 0, top: 0, right: 0, bottom: 0 };
        this.isRTL = false;
        
        if (typeof document !== 'undefined') {
            this.canvas = document.createElement('canvas');
            this.ctx = this.canvas.getContext('2d');
        }
    }


    
    /**
    *  solve method with Guideline Preservation & Higher Multiplier
    */
    solve(children, parentWidth, parentHeight, padding = { left: 0, top: 0, right: 0, bottom: 0 }, isRTL = false, isWrapContentHeight = false) {
        this.parentW = parentWidth || 360;
        this.parentH = parentHeight || 640;
        this.padding = padding;
        this.isRTL = isRTL;
        this.nodeMap.clear();

        console.log(`[Solver] 🛠️ Solving: Device=${this.parentW}x${this.parentH}`);

        // Phase 1: Register and Pre-calc Guidelines
        children.forEach(node => {
            const id = this.getId(node);
            if (!id) return;
            const type = node.type.split('.').pop();
            const isGuideline = type === 'Guideline';
            const state = {
                node, id, x: 0, y: 0, 
                w: isGuideline ? 0 : this.estimateWidth(node), 
                h: isGuideline ? 0 : this.estimateHeight(node, 0),
                isGuideline, guideX: null, guideY: null
            };
            if (isGuideline) {
                const orient = this._getAttr(node.attributes, 'orientation');
                const begin = this._getAttr(node.attributes, 'layout_constraintGuide_begin');
                const end = this._getAttr(node.attributes, 'layout_constraintGuide_end');
                const percent = this._getAttr(node.attributes, 'layout_constraintGuide_percent');
                if (orient === 'vertical') {
                    if (begin) state.guideX = this.parsePx(begin);
                    else if (end) state.guideX = this.parentW - this.parsePx(end);
                    else if (percent) state.guideX = this.parentW * parseFloat(percent);
                    state.x = state.guideX || 0;
                } else {
                    if (begin) state.guideY = this.parsePx(begin);
                    else if (end) state.guideY = this.parentH - this.parsePx(end);
                    else if (percent) state.guideY = this.parentH * parseFloat(percent);
                    state.y = state.guideY || 0;
                }
            }
            this.nodeMap.set(id, state);
        });

        this.applyDimensionRatios(children);
        this.detectChains(children);
        this._runSolverLoop(children, isWrapContentHeight);

        // Phase 3: Result Generation
        const resultStyles = new Map();
        this.nodeMap.forEach((state, id) => {
            // 🔥 FIX: Include Guidelines in result map to prevent 'undefined' crash in Layout
            const isGuide = state.isGuideline;
            const finalW = Math.ceil(state.w);
            const finalH = Math.ceil(state.h);

            const css = `
                position: absolute !important;
                left: ${state.x}px !important;
                top: ${state.y}px !important;
                width: ${isGuide ? 0 : finalW}px !important;
                height: ${isGuide ? 0 : finalH}px !important;
                margin: 0 !important;
                display: ${isGuide ? 'none' : 'flex'};
            `;
            resultStyles.set(id, { css, width: finalW, height: finalH, x: state.x, y: state.y, isGuideline: isGuide });
        });
        return resultStyles;
    }


        /**
    *  getPos with Explicit Null Checks for Guidelines
    */
    getPos(ref, edge) {
        if (!ref || ref === 'parent') { 
            if (edge === 'left' || edge === 'start') return this.padding.left;
            if (edge === 'right' || edge === 'end') return this.parentW - this.padding.right;
            if (edge === 'top') return this.padding.top;
            if (edge === 'bottom') return this.parentH - this.padding.bottom;
            return 0;
        }
        
        const id = ref.replace(/@\+?id\//, '');
        const state = this.nodeMap.get(id);
        
        if (!state) {
            console.warn(`[Solver] ❌ Target ID not found: ${id} (Called for edge: ${edge})`);
            return 0;
        }
        
        if (state.isGuideline) {
            // Guidelines represent a single coordinate regardless of the edge requested
            return (state.guideX !== null) ? state.guideX : (state.guideY !== null ? state.guideY : 0);
        }
        
        switch(edge) {
            case 'left': case 'start': return state.x;
            case 'right': case 'end': return state.x + state.w;
            case 'top': return state.y;
            case 'bottom': return state.y + state.h;
            default: return 0;
        }
    }
    

    _runSolverLoop(children, isMeasuring) {
        if (!isMeasuring) {
            this.nodeMap.forEach(s => s.solvedY = false);
        }

        for (let pass = 0; pass < 6; pass++) {
            children.forEach(node => {
                const id = this.getId(node);
                if (!id) return;
                
                const state = this.nodeMap.get(id);
                
                if (!state.inHorizontalChain) {
                    this.solveHorizontal(state, node.attributes);
                } else if (pass >= 0 && state.chainHead) {
                    this.solveChainHorizontal(state);
                }

                if ((node.type.includes('TextView') || node.type.includes('Button')) && state.w > 0) {
                  const hAttr = this._getAttr(node.attributes, 'layout_height');
                  if (hAttr === 'wrap_content') {
                      let text = this._resolveText(node);
                      if (node.type.includes('Button') || this._getAttr(node.attributes, 'textAllCaps') === 'true') {
                          text = text ? text.toUpperCase() : '';
                      }
                      
                      const exactSize = this.measurer.measure(
                          text, 
                          node.attributes, 
                          state.w 
                      );
                      
                      let measuredH = exactSize.height;
                      // 🔥 FIX: Removed 48px floor to sync with Button.js styling
                      if (node.type.includes('Button')) {
                          const hasPad = this._getAttr(node.attributes, 'padding') || this._getAttr(node.attributes, 'paddingVertical');
                          if (!hasPad) measuredH += 12; // Add default 6px+6px padding if not present
                          measuredH += 8; // Borders
                      }
                      
                      state.h = measuredH;
                      state.baseline = exactSize.baseline;
                  }
                }

                if (!state.inVerticalChain) {
                    this.solveVertical(state, node.attributes, isMeasuring);
                }
                
                this.applySingleRatio(state, node.attributes);
            });
        }
    }

    estimateWidth(node) {
        const attr = node.attributes;
        if (this._getAttr(attr, 'visibility') === 'gone') return 0;

        const w = this._getAttr(attr, 'layout_width');
        if (w === '0dp' || w === 'match_parent') return 50;
        if (w && w !== 'wrap_content' && w !== '0dp' && w !== 'match_parent') return this.parsePx(w);

        const type = node.type.split('.').pop();
        const id = this.getId(node);

        if (['LinearLayout', 'ConstraintLayout', 'RelativeLayout', 'FrameLayout', 'CardView', 'ViewGroup','HorizontalScrollView','ScrollView', 'GridLayout'].includes(type)) {
            if (node.children) {
                let totalW = 0;
                let maxW = 0;
                const isVertical = (this._getAttr(attr, 'orientation') || 'horizontal') === 'vertical';
                const isStack = type === 'LinearLayout' && !isVertical;

                node.children.forEach(child => {
                    if(child !== node) {
                        const childW = this.estimateWidth(child);
                        const ml = this.parsePx(this._getAttr(child.attributes, 'layout_marginStart'));
                        const mr = this.parsePx(this._getAttr(child.attributes, 'layout_marginEnd'));
                        const actualChildW = childW + ml + mr;
                        if (isStack) totalW += actualChildW;
                        else maxW = Math.max(maxW, actualChildW);
                    }
                });
                
                const p = this.parsePx(this._getAttr(attr, 'padding'));
                const pH = this.parsePx(this._getAttr(attr, 'paddingHorizontal'));
                const cp = this.parsePx(this._getAttr(attr, 'contentPadding')); 
                const pl = this.parsePx(this._getAttr(attr, 'paddingLeft') || this._getAttr(attr, 'paddingStart')) || pH || cp || p;
                const pr = this.parsePx(this._getAttr(attr, 'paddingRight') || this._getAttr(attr, 'paddingEnd')) || pH || cp || p;
                
                const contentW = (isStack || type === 'GridLayout') ? totalW : maxW;
                if (type === 'GridLayout') {
                    const colCount = parseInt(this._getAttr(attr, 'columnCount') || '1');
                    return Math.max(10, (maxW * colCount) + pl + pr);
                }
                return Math.max(10, contentW + pl + pr);
            }
            return 100;
        }

        if (type === 'ProgressBar') return 50; 

        if (type === 'TextView' || type.includes('Button')) {
            let text = this._resolveText(node);
            const isButton = type.includes('Button');

            if (isButton || this._getAttr(attr, 'textAllCaps') === 'true') {
                text = text ? text.toUpperCase() : '';
            }

            const result = this.measurer.measure(text, attr, this.parentW);
            let measuredW = result.width;

            if (isButton) {
                // Button Precision Fix (1.45x)
                const baseW = measuredW;
                const multiplier = 1.45;
                measuredW = (measuredW * multiplier); 
                measuredW += 32; // Padding
                measuredW += 8;  // Border
                measuredW = Math.max(measuredW, 64);
                return Math.min(Math.max(0, measuredW), this.parentW);
            }
            
            else {
                //  Multiplier increased from 1.05 to 1.25 to combat TextMeasurer bias
                // This prevents wrapping for TextViews like "Verified ✓"
                const oldW = measuredW;
                measuredW = (measuredW * 1.25); 

                const p = this.parsePx(this._getAttr(attr, 'padding'));
                const pH = this.parsePx(this._getAttr(attr, 'paddingHorizontal'));
                const pl = this.parsePx(this._getAttr(attr, 'paddingLeft') || this._getAttr(attr, 'paddingStart')) || pH || p;
                const pr = this.parsePx(this._getAttr(attr, 'paddingRight') || this._getAttr(attr, 'paddingEnd')) || pH || p;
                measuredW += (pl + pr);
                
                measuredW = Math.ceil(measuredW) + 2;
                console.log(`[Solver] TextView '${id}' Estimate: Base=${oldW}px -> Final=${measuredW}px (Multiplier: 1.25x)`);
                return Math.min(Math.max(0, measuredW), this.parentW);
            }
            
            
            
        }
        return 100;
    }
    
    
    

    estimateHeight(node, calculatedWidth) {
        const attr = node.attributes;
        if (this._getAttr(attr, 'visibility') === 'gone') return 0;

        const h = this._getAttr(attr, 'layout_height');
        if (h && h !== 'wrap_content' && h !== '0dp' && h !== 'match_parent') return this.parsePx(h);
        
        const type = node.type.split('.').pop();
        const isLayout = ['LinearLayout', 'ConstraintLayout', 'RelativeLayout', 'FrameLayout', 'CardView', 'ViewGroup','HorizontalScrollView','ScrollView', 'GridLayout'].includes(type);

        if (node.children && isLayout) {
            let totalH = 0;
            let maxH = 0;
            const isVertical = (this._getAttr(attr, 'orientation') || 'horizontal') === 'vertical';
            const isStack = type === 'LinearLayout' && isVertical;
            
            const p = this.parsePx(this._getAttr(attr, 'padding'));
            const pV = this.parsePx(this._getAttr(attr, 'paddingVertical'));
            const cp = this.parsePx(this._getAttr(attr, 'contentPadding')); 
            const pt = this.parsePx(this._getAttr(attr, 'paddingTop')) || pV || cp || p;
            const pb = this.parsePx(this._getAttr(attr, 'paddingBottom')) || pV || cp || p;
            
            if (isVertical && type === 'LinearLayout') {
                // ... (LinearLayout vertical logic same as before) ...
                node.children.forEach(child => {
                    if(child !== node) {
                        const childH = this.estimateHeight(child, calculatedWidth); 
                        const mt = this.parsePx(this._getAttr(child.attributes, 'layout_marginTop'));
                        const mb = this.parsePx(this._getAttr(child.attributes, 'layout_marginBottom'));
                        totalH += childH + mt + mb;
                    }
                });
                return Math.max(20, totalH + pt + pb);
            }

            node.children.forEach(child => {
                if(child !== node) {
                    const childH = this.estimateHeight(child, calculatedWidth); 
                    const mt = this.parsePx(this._getAttr(child.attributes, 'layout_marginTop'));
                    const mb = this.parsePx(this._getAttr(child.attributes, 'layout_marginBottom'));
                    const actualChildH = childH + mt + mb;
                    if (isStack) totalH += actualChildH;
                    else maxH = Math.max(maxH, actualChildH);
                }
            });
            const contentH = isStack ? totalH : maxH;
            return Math.max(20, contentH + pt + pb);
        }

        if (type === 'ProgressBar') return 50; 

        if (type === 'TextView' || type.includes('Button')) {
            const availableW = (calculatedWidth > 0) ? calculatedWidth : this.parentW;
            const result = this.measurer.measure(this._resolveText(node), attr, availableW);
            let measuredH = result.height;
            
            //  Height Precision for Button.js
            if (type.includes('Button')) {
                // If user didn't set padding, Button.js adds 6px vertical (3px top + 3px bottom? No, 6px top+bottom in css)
                // Button.js: padding: 6px 16px. So 12px total vertical padding.
                const hasUserPadding = attr['android:padding'] || attr['padding'] || 
                                    attr['android:paddingTop'] || attr['paddingTop'] ||
                                    attr['android:paddingVertical'] || attr['paddingVertical'];
                                     
                if (!hasUserPadding) {
                    measuredH += 12; // 6px Top + 6px Bottom
                }
                measuredH += 8; // 4px solid transparent border * 2
                // REMOVED: measuredH = Math.max(measuredH, 48); 
            }
            
            // Standard padding applied by measurer or manually added here if measurer didn't catch it
            const p = this.parsePx(this._getAttr(attr, 'padding'));
            const pV = this.parsePx(this._getAttr(attr, 'paddingVertical'));
            const pt = this.parsePx(this._getAttr(attr, 'paddingTop')) || pV || p;
            const pb = this.parsePx(this._getAttr(attr, 'paddingBottom')) || pV || p;
            
            return measuredH + pt + pb;
        }
        return 50; 
    }

    solveHorizontal(state, attr) {
        const startToStart = this._getAttr(attr, 'layout_constraintStart_toStartOf') || this._getAttr(attr, 'layout_constraintLeft_toLeftOf');
        const startToEnd = this._getAttr(attr, 'layout_constraintStart_toEndOf') || this._getAttr(attr, 'layout_constraintLeft_toRightOf');
        const endToEnd = this._getAttr(attr, 'layout_constraintEnd_toEndOf') || this._getAttr(attr, 'layout_constraintRight_toRightOf');
        const endToStart = this._getAttr(attr, 'layout_constraintEnd_toStartOf') || this._getAttr(attr, 'layout_constraintRight_toLeftOf');

        const targetStart = (startToStart || startToEnd || '').replace(/@\+?id\//, '');
        const targetEnd = (endToEnd || endToStart || '').replace(/@\+?id\//, '');

        let mStart = this.getMargin(attr, 'Start', targetStart);
        if (mStart === null) mStart = this.getMargin(attr, 'Left', targetStart);
        if (mStart === null) mStart = this.getMargin(attr, '', targetStart); 
        if (mStart === null) mStart = 0;

        let mEnd = this.getMargin(attr, 'End', targetEnd);
        if (mEnd === null) mEnd = this.getMargin(attr, 'Right', targetEnd);
        if (mEnd === null) mEnd = this.getMargin(attr, '', targetEnd); 
        if (mEnd === null) mEnd = 0;

        let anchorStart = null, anchorEnd = null;

        if (!this.isRTL) {
            if (startToStart) anchorStart = this.getPos(startToStart, 'left');
            else if (startToEnd) anchorStart = this.getPos(startToEnd, 'right');

            if (endToEnd) anchorEnd = this.getPos(endToEnd, 'right');
            else if (endToStart) anchorEnd = this.getPos(endToStart, 'left');
        } else {
            if (startToStart) anchorStart = this.getPos(startToStart, 'right');
            else if (startToEnd) anchorStart = this.getPos(startToEnd, 'left');

            if (endToEnd) anchorEnd = this.getPos(endToEnd, 'left');
            else if (endToStart) anchorEnd = this.getPos(endToStart, 'right');
        }

        const wAttr = this._getAttr(attr, 'layout_width');
        let calculatedW = state.w;

        const widthPercent = this._getAttr(attr, 'layout_constraintWidth_percent');
        if (widthPercent && wAttr === '0dp') {
            calculatedW = this.parentW * parseFloat(widthPercent);
            state.w = calculatedW;
            state.boundW = calculatedW;
        }
        else if (wAttr === '0dp' || wAttr === 'match_parent') {
            if (anchorStart !== null && anchorEnd !== null) {
                calculatedW = Math.abs(anchorEnd - anchorStart) - mStart - mEnd;
            } else if (wAttr === 'match_parent') {
                calculatedW = this.parentW - (this.padding.left + this.padding.right + mStart + mEnd);
            }
            calculatedW = Math.max(0, calculatedW);
            state.w = calculatedW;
            state.boundW = calculatedW;
        }

        if (anchorStart !== null && anchorEnd !== null && !widthPercent) {
            const bias = parseFloat(this._getAttr(attr, 'layout_constraintHorizontal_bias') || '0.5');
            let availableSpace;
            if (!this.isRTL) {
                availableSpace = anchorEnd - anchorStart - calculatedW - mStart - mEnd;
                state.x = anchorStart + mStart + (availableSpace * bias);
            } else {
                availableSpace = anchorStart - anchorEnd - calculatedW - mStart - mEnd;
                state.x = anchorEnd + mEnd + (availableSpace * (1 - bias));
            }
            state.alignment = 'center';
        } else if (anchorStart !== null && anchorEnd !== null && widthPercent) {
            if (!this.isRTL) state.x = anchorStart + mStart;
            else state.x = anchorStart - calculatedW - mStart;
            state.alignment = 'start';
        } else if (anchorStart !== null) {
            if (!this.isRTL) state.x = anchorStart + mStart;
            else state.x = anchorStart - state.w - mStart; 
            state.alignment = 'start';
        } else if (anchorEnd !== null) {
            if (!this.isRTL) state.x = anchorEnd - state.w - mEnd;
            else state.x = anchorEnd + mEnd; 
            state.alignment = 'end'; 
        } else {
            if (!this.isRTL) state.x = this.padding.left + mStart;
            else state.x = (this.parentW - this.padding.right) - state.w - mStart;
            state.alignment = 'start';
        }
    }
    

    solveVertical(state, attr, isMeasuring = false) {
        let top = null, bottom = null;
        
        const topToTop = this._getAttr(attr, 'layout_constraintTop_toTopOf');
        const topToBottom = this._getAttr(attr, 'layout_constraintTop_toBottomOf');
        const bottomToBottom = this._getAttr(attr, 'layout_constraintBottom_toBottomOf');
        const bottomToTop = this._getAttr(attr, 'layout_constraintBottom_toTopOf');
        const baselineToBaseline = this._getAttr(attr, 'layout_constraintBaseline_toBaselineOf');

        const topTarget = (topToTop || topToBottom || '').replace(/@\+?id\//, '');
        const bottomTarget = (bottomToBottom || bottomToTop || '').replace(/@\+?id\//, '');
        const baselineTarget = (baselineToBaseline || '').replace(/@\+?id\//, '');

        if (isMeasuring) {
            const dependsOnParentH = 
                bottomTarget === 'parent' || 
                (topTarget === 'parent' && bottomTarget === 'parent') ||
                this._getAttr(attr, 'layout_height') === 'match_parent';

            if (dependsOnParentH && (topTarget === 'parent' || !topTarget)) {
                // Skip vertical solving
            }
        }

        if (topToTop) top = this.getPos(topToTop, 'top');
        else if (topToBottom) top = this.getPos(topToBottom, 'bottom');

        if (bottomToBottom) {
            if (!isMeasuring || bottomTarget !== 'parent') bottom = this.getPos(bottomToBottom, 'bottom');
        }
        else if (bottomToTop) {
            if (!isMeasuring || bottomTarget !== 'parent') bottom = this.getPos(bottomToTop, 'top');
        }

        if (baselineToBaseline) {
            const targetState = this.nodeMap.get(baselineTarget);
            if (targetState) {
                const targetBaselineY = targetState.y + (targetState.baseline || targetState.h * 0.8);
                const myBaseline = state.baseline || (state.h * 0.8);
                state.y = targetBaselineY - myBaseline;
                state.solvedY = true;
                return; 
            }
        }

        let mt = this.getMargin(attr, 'Top', topTarget);
        if (mt === null) mt = this.getMargin(attr, '', topTarget); 
        if (mt === null) mt = 0;

        let mb = this.getMargin(attr, 'Bottom', bottomTarget);
        if (mb === null) mb = this.getMargin(attr, '', bottomTarget); 
        if (mb === null) mb = 0;

        const hAttr = this._getAttr(attr, 'layout_height');
        let calculatedH = state.h;

        const heightPercent = this._getAttr(attr, 'layout_constraintHeight_percent');
        if (heightPercent && hAttr === '0dp') {
            calculatedH = this.parentH * parseFloat(heightPercent);
            state.h = calculatedH;
            state.boundH = calculatedH;
        }
        else if (hAttr === '0dp' || hAttr === 'match_parent') {
            if (top !== null && bottom !== null) calculatedH = Math.max(0, bottom - top - mt - mb);
            else if (hAttr === 'match_parent') calculatedH = this.parentH - (this.padding.top + this.padding.bottom + mt + mb);
            state.h = calculatedH;
            state.boundH = calculatedH;
        }

        if (top !== null && bottom !== null && !heightPercent) {
            const bias = parseFloat(this._getAttr(attr, 'layout_constraintVertical_bias') || '0.5');
            state.y = top + mt + ((bottom - top - mt - mb - calculatedH) * bias);
            state.solvedY = true;
        } else if (top !== null && bottom !== null && heightPercent) {
            state.y = top + mt;
            state.solvedY = true;
        } else if (top !== null) {
            state.y = top + mt;
            state.solvedY = true;
        } else if (bottom !== null) {
            state.y = bottom - state.h - mb;
            state.solvedY = true;
        } else {
            state.y = this.padding.top + mt; 
            state.solvedY = true;
        }
    }

    _getAttr(attr, name) {
        if (!attr) return null;
        return attr[name] || attr[`android:${name}`] || attr[`app:${name}`];
    }

    getPos(ref, edge) {
        if (!ref || ref === 'parent') { 
            if (edge === 'left') return this.padding.left;
            if (edge === 'right') return this.parentW - this.padding.right;
            if (edge === 'top') return this.padding.top;
            if (edge === 'bottom') return this.parentH - this.padding.bottom;
            return 0;
        }
        const id = ref.replace(/@\+?id\//, '');
        const state = this.nodeMap.get(id);
        if (!state) return 0;
        
        switch(edge) {
            case 'left': return state.x;
            case 'right': return state.x + state.w;
            case 'top': return state.y;
            case 'bottom': return state.y + state.h;
            default: return 0;
        }
    }

    parsePx(val) { 
        if (!val) return 0;
        const res = parseFloat(this.converter.parse(val));
        return isNaN(res) ? 0 : res;
    }

        /**
    *  Robust ID resolution (Supports both 'id' and 'android:id')
    */
    getId(node) {
        const rawId = node.attributes.id || node.attributes['android:id'] || node.attributes['android:attr/id'];
        return rawId ? rawId.replace(/@\+?id\//, '') : null;
    }

    _resolveText(node) {
        const raw = this._getAttr(node.attributes, 'text') || '';
        return this.resolver ? this.resolver.resolveString(raw) : raw;
    }

    getMargin(attr, type, targetId) {
        if (type && targetId && targetId !== 'parent') {
            const targetState = this.nodeMap.get(targetId);
            if (targetState) {
                const vis = this._getAttr(targetState.node.attributes, 'visibility');
                if (vis === 'gone') {
                    const goneName = `layout_goneMargin${type}`;
                    const goneVal = this._getAttr(attr, goneName);
                    if (goneVal) return this.parsePx(goneVal);
                    return 0; 
                }
            }
        }

        if (type) {
            const val = this._getAttr(attr, `layout_margin${type}`);
            if (val !== undefined && val !== null) {
                return this.parsePx(val);
            }
        }

        if (type === 'Left' || type === 'Right' || type === 'Start' || type === 'End') {
            const val = this._getAttr(attr, 'layout_marginHorizontal');
            if (val !== undefined && val !== null) return this.parsePx(val);
        }
        
        if (type === 'Top' || type === 'Bottom') {
            const val = this._getAttr(attr, 'layout_marginVertical');
            if (val !== undefined && val !== null) return this.parsePx(val);
        }

        const val = this._getAttr(attr, 'layout_margin');
        if (val !== undefined && val !== null) return this.parsePx(val);
        
        return 0; 
    }

    applySingleRatio(state, attr) {
        const ratioStr = this._getAttr(attr, 'layout_constraintDimensionRatio');
        if (!ratioStr) return;

        const parts = ratioStr.split(',');
        let ratioVal = parts.length > 1 ? parts[1] : parts[0];
        if (ratioVal.includes(':') === false && parts.length > 1) ratioVal = parts[1];

        let side = null;
        if(parts.length > 1) side = parts[0]; 
        
        const dims = ratioVal.split(':');
        if (dims.length !== 2) return;

        const wRatio = parseFloat(dims[0]);
        const hRatio = parseFloat(dims[1]);
        const ratio = wRatio / hRatio; 

        const wMode = this._getAttr(attr, 'layout_width');
        const hMode = this._getAttr(attr, 'layout_height');

        if (wMode === '0dp' && hMode === '0dp') {
            const hasVConstraints = (this._getAttr(attr, 'layout_constraintTop_toTopOf') || this._getAttr(attr, 'layout_constraintTop_toBottomOf')) &&
                                    (this._getAttr(attr, 'layout_constraintBottom_toBottomOf') || this._getAttr(attr, 'layout_constraintBottom_toTopOf'));

            if (side === 'H') {
                state.w = state.boundW;
                state.h = state.w / ratio;
            } else if (side === 'W') {
                state.h = state.boundH;
                state.w = state.h * ratio;
            } else {
                let availableW = state.boundW;
                let availableH = state.boundH;

                if (availableW > 0 && !hasVConstraints) {
                    state.w = availableW;
                    state.h = state.w / ratio;
                } else {
                    if (availableW / availableH > ratio) {
                        state.h = availableH;
                        state.w = state.h * ratio;
                    } else {
                        state.w = availableW;
                        state.h = state.w / ratio;
                    }
                    const hBias = parseFloat(this._getAttr(attr, 'layout_constraintHorizontal_bias') || '0.5');
                    const vBias = parseFloat(this._getAttr(attr, 'layout_constraintVertical_bias') || '0.5');
                    if (!this.isRTL) state.x += (availableW - state.w) * hBias;
                    else state.x += (availableW - state.w) * (1 - hBias);
                    state.y += (availableH - state.h) * vBias;
                }
            }
        } else if (wMode === '0dp') {
            state.w = state.h * ratio;
        } else if (hMode === '0dp') {
            state.h = state.w / ratio;
        }
    }

    applyDimensionRatios(children) {
        children.forEach(node => {
            const id = this.getId(node);
            const state = this.nodeMap.get(id);
            if(state) this.applySingleRatio(state, node.attributes);
        });
    }

    /**
    *: Strict Chain Detection with Bidirectional Check
    */
    detectChains(children) {
        const processed = new Set();
        children.forEach(node => {
            const id = this.getId(node);
            if (!id || processed.has(id)) return;
            
            const members = this.collectChainMembers(id, children);
            
            // Only consider it a chain if it has 2+ members AND bidirectional links
            if (members.length >= 2) {
                const headNode = members[0].node;
                const headAttr = headNode.attributes;
                const tailNode = members[members.length - 1].node;
                const tailAttr = tailNode.attributes;

                // Chain Head must have a start constraint to something outside the chain
                const headHasStart = this._getAttr(headAttr, 'layout_constraintStart_toStartOf') ||
                                    this._getAttr(headAttr, 'layout_constraintStart_toEndOf') ||
                                    this._getAttr(headAttr, 'layout_constraintLeft_toLeftOf') ||
                                    this._getAttr(headAttr, 'layout_constraintLeft_toRightOf');

                // Chain Tail must have an end constraint to something outside the chain
                const hasEndConstraint = this._getAttr(tailAttr, 'layout_constraintEnd_toEndOf') || 
                                        this._getAttr(tailAttr, 'layout_constraintEnd_toStartOf') ||
                                        this._getAttr(tailAttr, 'layout_constraintRight_toRightOf') ||
                                        this._getAttr(tailAttr, 'layout_constraintRight_toLeftOf');

                if (headHasStart && hasEndConstraint) {
                    console.log(`[ConstraintSolver] ✅ Valid Horizontal Chain detected: ${members.map(m => m.id).join(' <-> ')}`);
                    
                    const style = this._getAttr(headNode.attributes, 'layout_constraintHorizontal_chainStyle') || 'spread';
                    const bias = parseFloat(this._getAttr(headNode.attributes, 'layout_constraintHorizontal_bias') || '0.5');
                    
                    members.forEach(m => {
                        this.nodeMap.get(m.id).inHorizontalChain = true;
                        processed.add(m.id);
                    });
                    
                    const headState = this.nodeMap.get(members[0].id);
                    headState.chainMembers = members;
                    headState.chainStyle = style;
                    headState.chainBias = bias;
                    headState.chainHead = true;
                }
            }
        });
    }
    
    

    /**
    * Strict Chain Detection with Detailed Logs
    */
    collectChainMembers(headId, children) {
        const members = [];
        let currentId = headId;
        const visited = new Set();

        while (currentId && !visited.has(currentId)) {
            visited.add(currentId);
            const node = children.find(c => this.getId(c) === currentId);
            if (!node) break;
            
            const state = this.nodeMap.get(currentId);
            members.push({ id: currentId, node, state });
            
            let next = null;
            const nextIdAttr = this._getAttr(node.attributes, 'layout_constraintEnd_toStartOf') || 
                              this._getAttr(node.attributes, 'layout_constraintRight_toLeftOf');
            
            if (nextIdAttr) {
                const potentialNextId = nextIdAttr.replace(/@\+?id\//, '');
                const nextNode = children.find(c => this.getId(c) === potentialNextId);
                
                if (nextNode) {
                    // Check if next node points BACK to this node
                    const prevIdAttr = this._getAttr(nextNode.attributes, 'layout_constraintStart_toEndOf') || 
                                      this._getAttr(nextNode.attributes, 'layout_constraintLeft_toRightOf');
                    
                    if (prevIdAttr && prevIdAttr.includes(currentId)) {
                        next = potentialNextId;
                    } else {
                        // This log will confirm why btnAction is not part of a chain with Verified
                        console.log(`[Solver] Chain Link Refused: ${currentId} -> ${potentialNextId} (No bidirectional link)`);
                    }
                }
            }
            currentId = next;
        }
        return members;
    }
    
    

    solveChainHorizontal(headState) {
        const members = headState.chainMembers;
        const style = headState.chainStyle;
        const bias = headState.chainBias || 0.5;
        
        const visibleMembers = members.filter(m => {
            const vis = this._getAttr(m.node.attributes, 'visibility');
            return vis !== 'gone';
        });

        if (visibleMembers.length === 0) return;

        let totalFixedChainWidth = 0;
        let weightedMembers = [];

        visibleMembers.forEach((m, i) => {
            let targetId = null;
            if (i > 0) targetId = visibleMembers[i-1].id; 
            else {
                const startAttr = this._getAttr(m.node.attributes, 'layout_constraintStart_toStartOf') || this._getAttr(m.node.attributes, 'layout_constraintStart_toEndOf');
                if (startAttr) targetId = startAttr.replace(/@\+?id\//, '');
            }

            const ml = this.getMargin(m.node.attributes, 'Start', targetId) || this.getMargin(m.node.attributes, 'Left', targetId) || this.getMargin(m.node.attributes, '', targetId) || 0;
            
            let endTargetId = null;
            if (i < visibleMembers.length - 1) endTargetId = visibleMembers[i+1].id;
            const mr = this.getMargin(m.node.attributes, 'End', endTargetId) || this.getMargin(m.node.attributes, 'Right', endTargetId) || this.getMargin(m.node.attributes, '', endTargetId) || 0;

            const wAttr = this._getAttr(m.node.attributes, 'layout_width');

            if (wAttr === '0dp' || wAttr === 'match_parent') {
                weightedMembers.push(m);
                totalFixedChainWidth += ml + mr; 
            } else {
                totalFixedChainWidth += m.state.w + ml + mr;
            }
        });

        const availableSpace = this.parentW - (this.padding.left + this.padding.right);
        const remainingSpace = availableSpace - totalFixedChainWidth;

        if (weightedMembers.length > 0) {
            const widthPerNode = Math.max(0, remainingSpace / weightedMembers.length);
            weightedMembers.forEach(m => {
                m.state.w = widthPerNode;
            });
        }

        let finalChainWidth = 0;
        visibleMembers.forEach((m, i) => {
            const ml = this.parsePx(this._getAttr(m.node.attributes, 'layout_marginStart'));
            const mr = this.parsePx(this._getAttr(m.node.attributes, 'layout_marginEnd'));
            finalChainWidth += m.state.w + ml + mr;
        });

        const spaceLeft = availableSpace - finalChainWidth;
        let startX = this.padding.left;
        let gap = 0;

        if (weightedMembers.length === 0) {
            if (style === 'spread') {
                gap = spaceLeft / (visibleMembers.length + 1);
                startX += gap;
            } else if (style === 'spread_inside') {
                gap = spaceLeft / (visibleMembers.length - 1);
            } else if (style === 'packed') {
                gap = 0;
                startX += spaceLeft * bias;
            }
        }

        if (!this.isRTL) {
            let currentX = startX;
            visibleMembers.forEach((m) => {
                const ml = this.parsePx(this._getAttr(m.node.attributes, 'layout_marginStart'));
                const mr = this.parsePx(this._getAttr(m.node.attributes, 'layout_marginEnd'));
                
                m.state.x = currentX + ml;
                m.state.alignment = 'start';
                currentX += ml + m.state.w + mr + gap;
            });
        } else {
            let currentX = this.parentW - this.padding.right; 
            visibleMembers.forEach((m) => {
                const ml = this.parsePx(this._getAttr(m.node.attributes, 'layout_marginStart'));
                const mr = this.parsePx(this._getAttr(m.node.attributes, 'layout_marginEnd'));
                currentX -= ml;  
                m.state.x = currentX - m.state.w;
                m.state.alignment = 'start'; 
                currentX -= (m.state.w + mr + gap);
            });
        }
    }
}