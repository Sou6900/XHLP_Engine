// export class GuidelineResolver {
//     constructor(solver) {
//         this.solver = solver;
//         this.helper = solver.helper;
//     }

//     resolve(children) {
//         this.solver.logger.log('solve', '─── Phase 1: Guideline Registration ───');

//         children.forEach(node => {
//             const id = this.helper.getId(node);
//             if (!id) return;
            
//             const type = node.type.split('.').pop();
//             const isGuideline = type === 'Guideline';
            
//             // Initial State Object
//             const state = {
//                 node, 
//                 id, 
//                 x: 0, 
//                 y: 0,
//                 // Note: Dimensions are calculated later for views, 0 for guidelines
//                 w: isGuideline ? 0 : 0, 
//                 h: isGuideline ? 0 : 0,
//                 isGuideline, 
//                 guideX: null, 
//                 guideY: null
//             };

//             if (isGuideline) {
//                 const orient = this.helper.getAttr(node.attributes, 'orientation');
//                 const begin = this.helper.getAttr(node.attributes, 'layout_constraintGuide_begin');
//                 const end = this.helper.getAttr(node.attributes, 'layout_constraintGuide_end');
//                 const percent = this.helper.getAttr(node.attributes, 'layout_constraintGuide_percent');

//                 this.solver.logger.log('solve', `Guideline: ${id}`, { orient, begin, end, percent });

//                 if (orient === 'vertical') {
//                     if (begin) state.guideX = this.helper.parsePx(begin);
//                     else if (end) state.guideX = this.solver.parentW - this.helper.parsePx(end);
//                     else if (percent) state.guideX = this.solver.parentW * parseFloat(percent);
//                     state.x = state.guideX || 0;
//                 } else {
//                     if (begin) state.guideY = this.helper.parsePx(begin);
//                     else if (end) state.guideY = this.solver.parentH - this.helper.parsePx(end);
//                     else if (percent) state.guideY = this.solver.parentH * parseFloat(percent);
//                     state.y = state.guideY || 0;
//                 }
//             }

//             this.solver.nodeMap.set(id, state);
//         });
//     }
// }


export class GuidelineResolver {
    constructor(solver) {
        this.solver = solver;
        this.helper = solver.helper;
    }

    resolve(children) {
        this.solver.logger.log('solve', '─── Phase 1: State Initialization & Guideline Registration ───');

        children.forEach(node => {
            const id = this.helper.getId(node);
            if (!id) return;
            
            const type = node.type.split('.').pop();
            const isGuideline = type === 'Guideline';
            
            // ❌ আগের ভুল: if (!isGuideline) return; (এটি রাখা যাবে না)
            // আমাদের সব নোডের জন্যই state তৈরি করতে হবে।

            // Initial State Object
            const state = {
                node, 
                id, 
                x: 0, 
                y: 0,
                w: 0, 
                h: 0,
                isGuideline, 
                guideX: null, 
                guideY: null,
                solvedX: false, 
                solvedY: false
            };

            // শুধু গাইডলাইন হলে পজিশন ক্যালকুলেট এবং সলভ মার্ক করব
            if (isGuideline) {
                const orient = this.helper.getAttr(node.attributes, 'orientation');
                const begin = this.helper.getAttr(node.attributes, 'layout_constraintGuide_begin');
                const end = this.helper.getAttr(node.attributes, 'layout_constraintGuide_end');
                const percent = this.helper.getAttr(node.attributes, 'layout_constraintGuide_percent');

                this.solver.logger.log('solve', `Guideline: ${id}`, { orient, begin, end, percent });

                if (orient === 'vertical') {
                    if (begin) state.guideX = this.helper.parsePx(begin);
                    else if (end) state.guideX = this.solver.parentW - this.helper.parsePx(end);
                    else if (percent) state.guideX = this.solver.parentW * parseFloat(percent);
                    
                    state.x = state.guideX || 0;
                    state.h = this.solver.parentH;
                    state.solvedX = true; // ✅ Solved
                    state.solvedY = true; // ✅ Solved (Infinite height)

                } else {
                    if (begin) state.guideY = this.helper.parsePx(begin);
                    else if (end) state.guideY = this.solver.parentH - this.helper.parsePx(end);
                    else if (percent) state.guideY = this.solver.parentH * parseFloat(percent);
                    
                    state.y = state.guideY || 0;
                    state.w = this.solver.parentW;
                    state.solvedY = true; // ✅ Solved
                    state.solvedX = true; // ✅ Solved (Infinite width)
                }
            }

            // সবার জন্য State সেট করছি
            this.solver.nodeMap.set(id, state);
        });
    }
}
