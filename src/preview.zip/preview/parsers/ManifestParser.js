const fs = acode.require('fs');

export class ManifestParser {
    async getAppTheme(projectRoot) {
        try {
            // 🔥 FIX: Add safety check for fs
            if (!fs) {
                console.warn("⚠️ [Manifest] fs module not available");
                return null;
            }

            const path = `${projectRoot}/app/src/main/AndroidManifest.xml`;
            const altPath = `${projectRoot}/src/main/AndroidManifest.xml`;
            
            let content = "";
            
            // 🔥 FIX: Proper async/await error handling
            try {
                const exists = await fs(path).exists();
                if (exists) {
                    content = await fs(path).readFile('utf-8');
                }
            } catch (e) {
                // Try alternate path
                try {
                    const altExists = await fs(altPath).exists();
                    if (altExists) {
                        content = await fs(altPath).readFile('utf-8');
                    }
                } catch (e2) {
                    // Both paths failed, return null silently
                    return null;
                }
            }
            
            if (!content) return null;

            // Simple Regex to find android:theme
            const match = content.match(/android:theme="(@style\/[\w.]+)"/);
            if (match) {
                return match[1];
            }
        } catch (e) {
            console.warn("⚠️ [Manifest] Failed to parse theme:", e.message);
        }
        return null;
    }
}