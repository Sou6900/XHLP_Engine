import { PreviewEngine } from '../core/PreviewEngine.js';
import { ToolbarControls } from './ToolbarControls.js';
import { previewStyles } from '../../styles/styles.js';
import { DeviceConfig } from '../device/DeviceConfig.js';
import { StatusBar } from './StatusBar.js'; 
import { svgs } from '../../assets/icons/svg/svg.js';

import { LogcatUI } from './LogcatUI.js';
import { LogManager } from '../core/LogManager.js';
import { BlueprintRenderer } from '../renderers/BlueprintRenderer.js';

let instance = null;

// 🔥 BLUEPRINT MODE STYLES (Stylesheets Array-এর জন্য)
const blueprintStyles = `
    /* 🟦 BLUEPRINT MODE STYLES (Android Studio Look) */
    .device-frame.blueprint-mode #preview-root {
        background-color: #1b4e8f !important; /* Blueprint Blue */
        /*background-image: 
            linear-gradient(rgba(255,255,255,0.15) 1px, transparent 1px),
            linear-gradient(90deg, rgba(255,255,255,0.15) 1px, transparent 1px) !important;*/
        background-size: 10px 10px !important;
        color: white !important;
    }

    /* Make ALL elements transparent with white borders */
    .device-frame.blueprint-mode .android-layout,
    .device-frame.blueprint-mode .android-view,
    .device-frame.blueprint-mode div:not(.hardware-camera):not(#status-bar-container):not(#preview-root) {
        background: transparent !important;
        background-image: none !important;
        background-color: transparent !important;
        border: 1px solid #6c84cb !important;
        box-shadow: none !important;
        color: #c7e6ffe6 !important;
        border-radius: 2px !important; 
    }

    /* Force Text & SVG to be WHITE in Blueprint Mode */
    .device-frame.blueprint-mode span, 
    .device-frame.blueprint-mode p,
    .device-frame.blueprint-mode h1, .device-frame.blueprint-mode h2, 
    .device-frame.blueprint-mode h3, .device-frame.blueprint-mode h4, 
    .device-frame.blueprint-mode h5, .device-frame.blueprint-mode h6,
    .device-frame.blueprint-mode label,
    .device-frame.blueprint-mode svg {
        color: #c7e6ffe6 !important;
        fill: #c7e6ffe6 !important;
        stroke: #c7e6ffe6 !important;
        text-shadow: none !important;
    }

    /* Images should be placeholders */
    .device-frame.blueprint-mode img {
        opacity: 0.3 !important;
        filter: grayscale(100%) !important;
        border: 1px dashed #c7e6ffe6 !important;
    }

    /* Hide Status Bar background */
    .device-frame.blueprint-mode .android-status-bar {
        background: rgba(0,0,0,0.2) !important;
        color: #c7e6ffe6 !important;
    }
`;

export class LayoutPreviewUI {
    constructor() {
        if (instance) return instance;
        instance = this;
        this.engine = new PreviewEngine();
        this.controls = new ToolbarControls(this);
        this.statusBar = new StatusBar(); 
        this.currentFileUri = null;
        this.isDark = this.controls.isDark; 
        
        // Initialize Blueprint Renderer
        this.blueprintRenderer = new BlueprintRenderer();
    }

    async show() {
        const activeFile = editorManager.activeFile;
        if (!activeFile || !activeFile.uri.endsWith('.xml')) {
            window.toast("❌ Please open an XML file", 2000);
            return;
        }
        
        // Pass renderer to controls
        this.controls.blueprintRenderer = this.blueprintRenderer;
        
        // 🔥 HOOK: Toggle Blueprint করলে যাতে Theme আপডেট হয়
        const originalToggle = this.controls.toggleBlueprint.bind(this.controls);
        this.controls.toggleBlueprint = (force) => {
            originalToggle(force); // Original logic run করো
            // UI Theme জোর করে আপডেট করো
            this.updateThemeUI(this.$root, this.controls.isDark);
        };

        // --- TOOLBAR MANAGEMENT ---
        const quickTools = document.querySelector('#quick-tools');
        const quickToolsToggler = document.querySelector('#quicktools-toggler');
    
        function updateToolbarVisibility() {
            const file = editorManager.activeFile;
            if (file && (file.uri || file.location)) {
                if (quickTools) quickTools.style.display = '';
                if (quickToolsToggler) quickToolsToggler.style.display = '';
            } else {
                if (quickTools) quickTools.style.display = 'none';
                if (quickToolsToggler) quickToolsToggler.style.display = 'none';
            }
        }
    
        if (quickTools) quickTools.style.display = 'none';
        if (quickToolsToggler) quickToolsToggler.style.display = 'none';
        editorManager.on('switch-file', updateToolbarVisibility);
        
        this.currentFileUri = activeFile.uri;
        await this.engine.init(activeFile.uri);
        
        const EditorFile = acode.require('editorFile');
        const $content = document.createElement('div');
        $content.className = 'xml-preview-container';
        $content.style.cssText = "height: 100%; width: 100%; display: flex; flex-direction: column; background: var(--primary-color); position: relative; color: var(--primary-text-color);";
        
        // CAMERA PUNCH-HOLE HTML
        const cameraHtml = `
            <div class="hardware-camera" style="
                position: absolute;
                width: 14px; height: 14px;
                background: #000; border-radius: 50%;
                display: flex; align-items: center; justify-content: center;
                z-index: 9999; pointer-events: none;
                box-shadow: 0 0 0 2px rgba(0,0,0,0.1);
            ">
                <div style="width: 6px; height: 6px; border-radius: 50%; background: #1a1a1a; border: 1.5px solid #333;">
                    <div style="width: 2px; height: 2px; background: rgba(255,255,255,0.4); border-radius: 50%; margin: 0.5px;"></div>
                </div>
            </div>
        `;

        // DYNAMIC FRAME STYLES
        const frameStyles = `
            <style>
                .device-frame {
                    border: 12px solid #111 !important; 
                    border-radius: 32px !important;
                    transition: all 0.5s cubic-bezier(0.175, 0.885, 0.32, 1.275);
                    flex-shrink: 0 !important;
                    flex-grow: 0 !important; 
                }
                .device-frame .hardware-camera {
                    top: 6px; left: 50%; transform: translateX(-50%);
                }
                .device-frame.landscape { 
                    border-width: 12px !important; 
                }
                .device-frame.landscape .hardware-camera {
                    top: 50%; left: 6px; transform: translateY(-50%);
                }
                /* Ensure SVGs inherit text color in Normal Mode */
                .device-frame svg {
                    fill: currentColor;
                }
                /* Smooth Color Transition */
                #preview-root, #preview-root * {
                    transition: background-color 0.2s, color 0.2s, border-color 0.2s;
                }
            </style>
        `;

        $content.innerHTML = `
            ${frameStyles}
            <div class="preview-toolbar" style="padding: 0 12px; border-bottom: 1px solid var(--border-color); background: var(--secondary-color); display: flex; justify-content: space-between; align-items: center; flex-shrink: 0; box-shadow: 0 2px 4px var(--box-shadow-color); position: relative; z-index: 999; color: var(--primary-text-color);">
                <div style="display:flex; gap:10px; align-items:center;height:23px;">
                    ${this.controls.render()} 
                </div>
            </div>
            
            <div class="frame-wrapper" style="flex: 1; overflow: auto; display: flex; align-items: flex-start; justify-content: center; padding: 18px 10px 10px 10px; position: relative; z-index: 1;">
                
                <div class="device-frame" style="
                    background: var(--bg-default); 
                    width: ${DeviceConfig.width}px; 
                    height: ${DeviceConfig.height}px; 
                    min-width: ${DeviceConfig.width}px; 
                    max-width: ${DeviceConfig.width}px;
                    min-height: ${DeviceConfig.height}px;
                    max-height: ${DeviceConfig.height}px;
                    border: 12px solid #333; 
                    border-radius: 24px; 
                    box-shadow: 0 20px 50px rgba(0,0,0,0.2); 
                    position: relative; 
                    flex-shrink: 0; 
                    overflow: hidden; 
                    display: flex; 
                    flex-direction: column;
                    color: var(--text-default);">
                    
                    ${cameraHtml}
                    
                    <div id="status-bar-container" style="height: 24px; width: 100%; position: absolute; top: 0; left: 0; z-index: 1000; pointer-events: none;"></div>

                    <div id="preview-root" style="flex: 1; width: 100%; overflow: auto; position: relative; background: var(--bg-default); color: var(--text-default); display: flex; flex-direction: column;">
                        <div style="padding: 20px; text-align: center; color: #888;">Loading...</div>
                    </div>
                </div>
            </div>
        `;

        this.$root = $content.querySelector('#preview-root');
        
        const sbContainer = $content.querySelector('#status-bar-container');
        sbContainer.appendChild(this.statusBar.getElement());

        this.controls.bindEvents($content, (isDark) => {
            this.isDark = isDark;
            if(this.engine.context && this.engine.context.setDarkMode) {
                 this.engine.context.setDarkMode(isDark);
            }
            this.updateThemeUI($content, isDark);
            this.manualRefresh();
        });

        $content.querySelector('#btn-refresh').onclick = () => this.manualRefresh();

        // 🔥 FIX: Blueprint Styles passed via stylesheets array
        new EditorFile(`Preview`, {
            type: 'page', 
            content: $content, 
            id: 'js.xml.preview.engine',
            icon: 'play_circle_filled', 
            stylesheets: [
                previewStyles || '',
                blueprintStyles 
            ]
        });

        this.updateThemeUI($content, this.isDark); 

        this.observer = new ResizeObserver(() => this.manualRefresh());
        this.observer.observe($content.querySelector('.device-frame'));

        this.onSave = () => {
            if (editorManager.activeFile.uri === this.currentFileUri) this.manualRefresh();
        };
        editorManager.on('save-file', this.onSave);

        this.logcat = new LogcatUI($content);
        
        LogManager.d("PreviewEngine", "Engine Initialized successfully.");
        LogManager.i("DeviceConfig", `Device: ${DeviceConfig.width}x${DeviceConfig.height}`);
    }

    updateThemeUI(container, isDark) {
        const root = container; 
        
        // 🔥 LOGIC CHANGE: 
        // যদি Blueprint Mode অন থাকে, তবে Theme Ignore করো।
        // সবসময় Blueprint Colors (Blue/White) ব্যবহার করো।
        
        const isBlueprint = this.controls && this.controls.showBlueprint;

        if (isBlueprint) {
            // Force Blueprint Variables
            root.style.setProperty('--bg-default', '#1b4e8f');
            root.style.setProperty('--text-default', '#ffffff');
            root.style.setProperty('--btn-text-default', '#ffffff');
            this.statusBar.setTheme(true); // Status bar white text
        } else {
            // Normal Mode (Respect Theme)
            if (isDark) {
                // Dark Mode: Black BG, White Text
                root.style.setProperty('--bg-default', '#000000');
                root.style.setProperty('--text-default', '#ffffff'); 
                root.style.setProperty('--btn-text-default', '#ffffff');
                this.statusBar.setTheme(true);
            } else {
                // Light Mode: White BG, Black Text
                root.style.setProperty('--bg-default', '#ffffff');
                root.style.setProperty('--text-default', '#000000'); 
                root.style.setProperty('--btn-text-default', '#000000');
                this.statusBar.setTheme(false);
            }
        }
    }

    manualRefresh() {
        if (!this.$root) return;
        const width = DeviceConfig.width;
        const height = DeviceConfig.height;
        
        const frame = this.$root.closest('.device-frame');
        if (frame) {
            frame.style.width = `${width}px`;
            frame.style.height = `${height}px`;
            frame.style.minWidth = `${width}px`;
            frame.style.maxWidth = `${width}px`;
            frame.style.minHeight = `${height}px`;
            frame.style.maxHeight = `${height}px`;
        }
        
        this.renderWithDimensions(width, height);
    }
    
    async renderWithDimensions(width, height) {
        if (!this.$root) return;
        
        // 🔥 FIX: Clean previous render immediately
        this.$root.innerHTML = ''; 
        
        try {
            const xmlContent = editorManager.editor.getValue();
            
            const hasFitsTrue = xmlContent.match(/android:fitsSystemWindows\s*=\s*"true"/);
            const hasFitsFalse = xmlContent.match(/android:fitsSystemWindows\s*=\s*"false"/);
            const isFullScreen = xmlContent.match(/windowFullscreen\s*=\s*"true"/) || hasFitsFalse;

            let renderHeight = height;
            const isNormalMode = !isFullScreen && !hasFitsTrue;

            if (isNormalMode) {
                renderHeight = height - 24; 
            }

            const { html, statusBarColor } = await this.engine.render(xmlContent, width, renderHeight);
            
            this.$root.innerHTML = html;

            this.$root.style.height = '100%'; 
            this.$root.style.boxSizing = 'border-box';
            this.$root.style.display = 'flex';
            this.$root.style.flexDirection = 'column';
            this.$root.style.justifyContent = 'flex-start'; 

            if (isNormalMode) {
                 this.$root.style.paddingTop = '24px'; 
            } else {
                 this.$root.style.paddingTop = '0px';
            }

            const rootTagMatch = xmlContent.match(/<[^>]+xmlns:android[^>]*>/); 
            if (rootTagMatch) {
                const rootTagString = rootTagMatch[0];
                if (rootTagString.match(/android:layout_gravity\s*=\s*"[^"]*bottom[^"]*"/)) {
                    this.$root.style.justifyContent = 'flex-end'; 
                } 
                else if (rootTagString.match(/android:layout_gravity\s*=\s*"[^"]*center[^"]*"/)) {
                    this.$root.style.justifyContent = 'center'; 
                }
            }

            const scrim = this.$root.querySelector('.drawer-scrim');
            if (scrim) {
                scrim.onclick = () => this.closeAllDrawers(this.$root);
            }

            // Status Bar Color Logic
            const effectiveFullScreen = !!isFullScreen;
            const isBlueprint = this.controls && this.controls.showBlueprint;

            if (effectiveFullScreen) {
                this.statusBar.setBackground('transparent');
                setTimeout(() => { this._updateDynamicContrast(); }, 50);
            } else if (statusBarColor) {
                this.statusBar.setBackground(statusBarColor);
            } else {
                // Default Status Bar Colors
                if (isBlueprint) {
                    this.statusBar.setBackground('rgba(0,0,0,0.2)');
                } else {
                    this.statusBar.setBackground(this.isDark ? '#000000' : 'rgba(0,0,0,0.1)');
                }
            }

            // Force theme update after render to ensure variables are correct
            this.updateThemeUI(this.$root, this.isDark);
            
            if (isBlueprint) {
                setTimeout(() => {
                    const solver = window.__latestConstraintSolver;
                    this.blueprintRenderer.enableBlueprint(this.$root, solver);
                }, 50);
            }

        } catch (e) {
            this.showError(e);
        }
    }

    _updateDynamicContrast() {
        if (!this.$root) return;
        const frame = this.$root.closest('.device-frame');
        if (!frame) return;
        const rect = frame.getBoundingClientRect();
        const x = rect.left + 20; 
        const y = rect.top + 10; 
        const sbContainer = frame.querySelector('#status-bar-container');
        sbContainer.style.display = 'none';
        let element = document.elementFromPoint(x, y);
        sbContainer.style.display = 'block';
        let effectiveColor = 'rgba(0, 0, 0, 0)';
        while (element && element !== document.body) {
            const style = window.getComputedStyle(element);
            const bg = style.backgroundColor;
            if (bg !== 'rgba(0, 0, 0, 0)' && bg !== 'transparent') {
                effectiveColor = bg;
                break;
            }
            element = element.parentElement;
        }
        const isDark = this.statusBar._isColorDark(effectiveColor);
        this.statusBar.setTheme(isDark);
    }

    toggleDrawer(gravity = null) {
        const container = this.$root;
        if (!container) return;

        const openDrawer = Array.from(container.querySelectorAll('.android-drawer')).find(d => 
            d.style.transform === 'translateX(0%)' || d.style.transform === 'translateY(0%)'
        );

        if (!gravity) {
            if (openDrawer) {
                this.closeAllDrawers(container);
            } else {
                this.openSpecificDrawer(container, 'start');
            }
        } else {
            this.openSpecificDrawer(container, gravity);
        }
    }
    
    openSpecificDrawer(container, gravity) {
        let selector = '.drawer-start'; 
        if (gravity === 'end' || gravity === 'right') selector = '.drawer-end';
        if (gravity === 'bottom') selector = '.drawer-bottom';

        const drawer = container.querySelector(selector);
        const scrim = container.querySelector('.drawer-scrim');

        if (drawer) {
            if (gravity === 'bottom') drawer.style.transform = 'translateY(0%)';
            else if (gravity === 'end' || gravity === 'right') drawer.style.transform = 'translateX(0%)'; 
            else drawer.style.transform = 'translateX(0%)'; 

            if (scrim) {
                scrim.style.opacity = '1';
                scrim.style.pointerEvents = 'auto';
            }
        }
    }

    closeAllDrawers(container) {
        const drawers = container.querySelectorAll('.android-drawer');
        const scrim = container.querySelector('.drawer-scrim');
        
        drawers.forEach(d => {
            if (d.classList.contains('drawer-start')) d.style.transform = 'translateX(-100%)';
            if (d.classList.contains('drawer-end')) d.style.transform = 'translateX(100%)';
            if (d.classList.contains('drawer-bottom')) d.style.transform = 'translateY(100%)';
        });
        
        if (scrim) {
            scrim.style.opacity = '0';
            scrim.style.pointerEvents = 'none';
        }
    }

    showError(e) {
        if (this.$root) this.$root.innerHTML = '';
        
        this.$root.innerHTML = `
            <div style="padding: 20px; color: #D32F2F; font-family: monospace; background: #FFEBEE; height:100%;">
                <h3 style="margin-top:0;">🚫 Rendering Error</h3>
                <p>${e.message}</p>
                <div style="font-size:12px; background:#fff; padding:10px; border:1px solid #ffcdd2; margin-top:10px;">
                    ${e.stack ? e.stack.replace(/\n/g, '<br>') : ''}
                </div>
            </div>
        `;
    }

    destroy() {
        if (this.onSave) editorManager.off('save-file', this.onSave);
        if (this.observer) this.observer.disconnect();
    }
}