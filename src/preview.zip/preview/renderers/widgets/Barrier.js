import { BaseView } from './BaseView.js';

export class Barrier extends BaseView {
    
    async render(node, parentType) {
        // Barrier is a virtual helper, it should not be visible.
        const attr = node.attributes;
        const idStr = attr.id ? `id="${attr.id.replace('@+id/', '')}"` : '';
        
        // আমরা class এ 'android-barrier' দিচ্ছি যাতে ব্লুপ্রিন্ট মোডে একে ধরা সহজ হয়
        // style="display: none" দিচ্ছি কারণ এটি সাধারণ UI তে দেখা যাওয়ার কথা নয়
        return `<div class="android-view android-barrier" ${idStr} style="display: none !important; width: 0px; height: 0px;"></div>`;
    }
}