// dimens.xml

export class DimenParser {

    /**
     * Parse dimens.xml content
     * @param {Document} xmlDoc 
     * @returns {Map<string, string>} Map of dimen names to values (e.g., "16dp")
     */
    parse(xmlDoc) {
        const dimens = new Map();
        if (!xmlDoc) return dimens;

        const dimenElements = xmlDoc.getElementsByTagName('dimen');
        
        for (let i = 0; i < dimenElements.length; i++) {
            const el = dimenElements[i];
            const name = el.getAttribute('name');
            const value = el.textContent.trim();
            
            if (name && value) {
                dimens.set(name, value);
            }
        }
        return dimens;
    }
}