// import { FrameLayout } from './FrameLayout.js';

// export class CardView extends FrameLayout {
    
//     // Override render to delegate to renderWithBounds
//     render(node, renderChildCallback, parentType) {
//         return this.renderWithBounds(node, null, null, renderChildCallback, parentType);
//     }

//     // 🔥 FIX: Override renderWithBounds to keep card styling
//     async renderWithBounds(node, width, height, renderChildCallback, parentType) {
//         // Call super (FrameLayout) to get the HTML structure with bounds logic
//         let html = await super.renderWithBounds(node, width, height, renderChildCallback, parentType);

//         const attr = node.attributes;
//         const converter = this.converter; 

//         // Apply Card Styling...
//         const radius = attr['app:cardCornerRadius'] || attr['cardCornerRadius'] || '0dp';
//         const cssRadius = converter.parse(radius);

//         const elevation = attr['app:cardElevation'] || attr['cardElevation'] || '0dp';
//         const elVal = parseFloat(elevation);
//         let boxShadow = 'none';
//         let zIndexRule = ''; // 🔥 FIX: Z-Index variable

//         if (!isNaN(elVal) && elVal > 0) {
//             boxShadow = `0px ${elVal/2}px ${elVal}px rgba(0,0,0,0.24)`;
//             zIndexRule = `z-index: ${Math.round(10 + elVal)};`; // Map elevation to z-index
//         }

//         let bgColor = '#FFFFFF';
//         const bgAttr = attr['app:cardBackgroundColor'] || attr['cardBackgroundColor'];
//         if (bgAttr) {
//             bgColor = this.resolver.resolveColor(bgAttr);
//         }

//         const cp = attr['app:contentPadding'] || attr['contentPadding'];
//         let paddingStyle = '';
//         if (cp) {
//             paddingStyle = `border-width: ${converter.parse(cp)}; border-style: solid; border-color: transparent;`;
//         }

//         const cardStyle = `
//             background-color: ${bgColor};
//             border-radius: ${cssRadius};
//             box-shadow: ${boxShadow};
//             ${paddingStyle}
//             overflow: hidden; 
//             background-clip: border-box;
//         `;

//         return html
//             .replace('class="android-layout frame-layout"', 'class="android-layout card-view"')
//             .replace('style="', `style="${cardStyle} `);
//     }
// }







import { FrameLayout } from './FrameLayout.js';

export class CardView extends FrameLayout {
    
    // Override render to delegate to renderWithBounds
    render(node, renderChildCallback, parentType) {
        return this.renderWithBounds(node, null, null, renderChildCallback, parentType);
    }

    async renderWithBounds(node, width, height, renderChildCallback, parentType) {
        // Call super (FrameLayout) to get the HTML structure
        let html = await super.renderWithBounds(node, width, height, renderChildCallback, parentType);

        const attr = node.attributes;
        const converter = this.converter; 

        // Apply Card Styling...
        const radius = attr['app:cardCornerRadius'] || attr['cardCornerRadius'] || '0dp';
        const cssRadius = converter.parse(radius);

        const elevation = attr['app:cardElevation'] || attr['cardElevation'] || '0dp';
        const elVal = parseFloat(elevation);
        let boxShadow = 'none';
        let zIndexRule = ''; // 🔥 FIX: Z-Index variable

        if (!isNaN(elVal) && elVal > 0) {
            boxShadow = `0px ${elVal/2}px ${elVal}px rgba(0,0,0,0.24)`;
            // Elevation থাকলে Z-index বাড়াবে যাতে এটি সাধারণ টেক্সটের উপরে থাকে
            zIndexRule = `z-index: ${Math.round(10 + elVal)};`; 
        }

        let bgColor = '#FFFFFF';
        const bgAttr = attr['app:cardBackgroundColor'] || attr['cardBackgroundColor'];
        if (bgAttr) {
            bgColor = this.resolver.resolveColor(bgAttr);
        }

        const cp = attr['app:contentPadding'] || attr['contentPadding'];
        let paddingStyle = '';
        if (cp) {
            paddingStyle = `border-width: ${converter.parse(cp)}; border-style: solid; border-color: transparent;`;
        }

        const cardStyle = `
            background-color: ${bgColor};
            border-radius: ${cssRadius};
            box-shadow: ${boxShadow};
            ${zIndexRule}
            ${paddingStyle}
            overflow: hidden; 
            background-clip: border-box;
        `;

        return html
            .replace('class="android-layout frame-layout"', 'class="android-layout card-view"')
            .replace('style="', `style="${cardStyle} `);
    }
}