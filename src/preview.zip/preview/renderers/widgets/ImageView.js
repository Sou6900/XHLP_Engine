// // ImageView.js - 100% Android Compliant Tinting + AdjustViewBounds + Alpha + CropToPadding
// import { BaseView } from './BaseView.js';

// export class ImageView extends BaseView {
    
//     async render(node, parentType) {
//         const attr = node.attributes;
//         const baseStyle = await this.getBaseStyles(attr, parentType);
        
//         // ---------------------------------------------------------
//         // 1. ScaleType Mapping
//         // ---------------------------------------------------------
//         const scaleType = attr.scaleType || attr['android:scaleType'] || 'fitCenter';
        
//         let objectFit = 'contain'; 
//         let objectPosition = 'center';
//         let maskSize = 'contain';
//         let maskPosition = 'center';

//         switch (scaleType) {
//             case 'centerCrop': 
//                 objectFit = 'cover'; 
//                 maskSize = 'cover';
//                 break;
//             case 'fitXY': 
//                 objectFit = 'fill'; 
//                 maskSize = '100% 100%';
//                 break;
//             case 'fitStart': 
//                 objectFit = 'contain'; 
//                 objectPosition = 'left top'; 
//                 maskSize = 'contain'; 
//                 maskPosition = 'left top';
//                 break;
//             case 'fitEnd': 
//                 objectFit = 'contain'; 
//                 objectPosition = 'right bottom'; 
//                 maskSize = 'contain'; 
//                 maskPosition = 'right bottom';
//                 break;
//             case 'center': 
//                 objectFit = 'none'; 
//                 maskSize = 'auto';
//                 break;
//             case 'fitCenter':
//             case 'centerInside':
//             default: 
//                 objectFit = 'contain'; 
//                 maskSize = 'contain';
//                 break;
//         }

//         // ---------------------------------------------------------
//         // 2. New Props Implementation
//         // ---------------------------------------------------------

//         // A. Handle AdjustViewBounds
//         const adjustViewBounds = attr['android:adjustViewBounds'] === 'true' || attr['adjustViewBounds'] === 'true';
//         const layoutW = attr['android:layout_width'] || attr['layout_width'];
//         const layoutH = attr['android:layout_height'] || attr['layout_height'];

//         let cssWidth = '100%';
//         let cssHeight = '100%';

//         if (adjustViewBounds) {
//             // যদি adjustViewBounds সত্য হয় এবং ডাইমেনশন wrap_content হয়, 
//             // তখন আমরা হার্ডকোড 100% এর বদলে 'auto' দেব যাতে অ্যাসপেক্ট রেশিও ঠিক থাকে।
//             if (layoutW === 'wrap_content') {
//                 cssWidth = 'auto';
//                 // wrap_content এর ক্ষেত্রে max-width প্যারেন্টের সাইজ হওয়া উচিত
//                 baseStyle.includes('max-width') ? null : (cssWidth += '; max-width: 100%'); 
//             }
//             if (layoutH === 'wrap_content') {
//                 cssHeight = 'auto';
//                 baseStyle.includes('max-height') ? null : (cssHeight += '; max-height: 100%');
//             }
//         }

//         // B. Handle CropToPadding
//         const cropToPadding = attr['android:cropToPadding'] === 'true' || attr['cropToPadding'] === 'true';
//         let cropStyle = '';
//         if (cropToPadding) {
//             // প্যাডিং এরিয়া বাদ দিয়ে কন্টেন্ট দেখানোর জন্য
//             cropStyle = `
//                 box-sizing: border-box; 
//                 background-clip: content-box;
//             `;
//             // ইমেজের ক্ষেত্রে প্যাডিং যেন কন্টেন্টকে ছোট করে দেয়
//             if (!adjustViewBounds) { // adjustViewBounds থাকলে ফ্লেক্সিবিলিটি দরকার
//                 cropStyle += `padding: inherit;`; // BaseView থেকে আসা প্যাডিং ইনহেরিট করবে
//             }
//         }

//         // C. Handle Alpha
//         const alpha = attr['android:alpha'] || attr['alpha'];
//         let alphaStyle = '';
//         if (alpha !== undefined && alpha !== null) {
//             const opacityVal = parseFloat(alpha);
//             if (!isNaN(opacityVal)) {
//                 alphaStyle = `opacity: ${opacityVal};`;
//             }
//         }

//         // ---------------------------------------------------------
//         // 3. Tint & Source Processing
//         // ---------------------------------------------------------
//         const tint = attr['app:tint'] || attr['android:tint'] || attr.tint;
//         const tintMode = attr['app:tintMode'] || attr['android:tintMode'] || 'src_in';
        
//         let tintColor = null;
//         if (tint) {
//             tintColor = this.resolver.resolveColor(tint);
//         }

//         let src = '';
//         let svgContent = null;
//         const rawSrc = attr.src || attr['android:src'];
        
//         if (rawSrc) {
//             if (rawSrc.startsWith('@drawable/') || rawSrc.startsWith('@mipmap/')) {
//                 const drawable = await this.resolver.resolveDrawable(rawSrc);
//                 if (drawable && drawable.type === 'svg') svgContent = drawable.value;
//                 else if (drawable && drawable.type === 'bitmap') src = drawable.value; 
//             } 
//             // Handle Color source
//             else if (rawSrc.startsWith('@color/') || rawSrc.startsWith('@android:color/') || rawSrc.startsWith('#')) {
//                 const color = this.resolver.resolveColor(rawSrc);
//                 const encodedColor = encodeURIComponent(color); 
//                 svgContent = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1 1"><rect width="1" height="1" fill="${color}"/></svg>`;
//                 objectFit = 'cover'; 
//                 maskSize = 'cover'; 
//             }
//             else {
//                 src = rawSrc;
//             }
//         }
        
//         // Fallback
//         if (!src && !svgContent) {
//             svgContent = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="#CCCCCC"><path d="M21 19V5c0-1.1-.9-2-2-2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2zM8.5 13.5l2.5 3.01L14.5 12l4.5 6H5l3.5-4.5z"/></svg>`;
//         }

//         // ---------------------------------------------------------
//         // 4. SVG Processing
//         // ---------------------------------------------------------
//         if (svgContent) {
//             if (tintColor && tintMode === 'src_in') {
//                 svgContent = this.applySrcInTint(svgContent, tintColor);
//             }
//             if (scaleType === 'fitXY' && svgContent.includes('<svg') && !svgContent.includes('preserveAspectRatio')) {
//                 svgContent = svgContent.replace('<svg', '<svg preserveAspectRatio="none"');
//             }
//             src = `data:image/svg+xml;utf8,${encodeURIComponent(svgContent)}`;
//         }

//         // ---------------------------------------------------------
//         // 5. Render
//         // ---------------------------------------------------------
        
//         // Common Styles merged with new props
//         const commonStyles = `
//             ${alphaStyle}
//             ${cropStyle}
//             display: block;
//             min-width: 0;
//             min-height: 0;
//             width: ${cssWidth};
//             height: ${cssHeight};
//         `;

//         // Render Method A: CSS Mask (For complex tints)
//         if (tintColor && tintMode !== 'src_in') {
//             const maskStyle = `
//                 background-color: ${tintColor};
//                 -webkit-mask-image: url('${src}');
//                 mask-image: url('${src}');
//                 -webkit-mask-size: ${maskSize};
//                 mask-size: ${maskSize};
//                 -webkit-mask-repeat: no-repeat;
//                 mask-repeat: no-repeat;
//                 -webkit-mask-position: ${maskPosition};
//                 mask-position: ${maskPosition};
//                 ${commonStyles}
//             `;
//             return `<div class="android-view image-view" style="${baseStyle} ${maskStyle}"></div>`;
//         } 
        
//         // Render Method B: Standard Image Tag (src_in or No Tint)
//         const imgStyle = `
//             object-fit: ${objectFit};
//             object-position: ${objectPosition};
//             ${commonStyles}
//         `;
//         return `<img src="${src}" class="android-view image-view" style="${baseStyle} ${imgStyle}" alt="ImageView" />`;
//     }

//     applySrcInTint(svgContent, tintColor) {
//         try {
//             let tinted = svgContent;
//             tinted = tinted.replace(/android:fillColor="[^"]*"/g, `android:fillColor="${tintColor}"`);
//             tinted = tinted.replace(/fill="[^"]*"/g, `fill="${tintColor}"`);
//             if (!tinted.includes('fill=')) {
//                 tinted = tinted.replace(/<path/g, `<path fill="${tintColor}"`);
//             }
//             return tinted;
//         } catch (e) {
//             console.error('❌ Tint application failed:', e);
//             return svgContent;
//         }
//     }
// }



// ImageView.js - 100% Android Compliant Tinting + AdjustViewBounds + Alpha + CropToPadding + Constraint String support
import { BaseView } from './BaseView.js';

export class ImageView extends BaseView {
    
    async render(node, parentType) {
        const attr = node.attributes;
        const baseStyle = await this.getBaseStyles(attr, parentType);
        
        // ---------------------------------------------------------
        // 1. ScaleType Mapping
        // ---------------------------------------------------------
        const scaleType = attr.scaleType || attr['android:scaleType'] || 'fitCenter';
        
        let objectFit = 'contain'; 
        let objectPosition = 'center';
        let maskSize = 'contain';
        let maskPosition = 'center';

        switch (scaleType) {
            case 'centerCrop': 
                objectFit = 'cover'; 
                maskSize = 'cover';
                break;
            case 'fitXY': 
                objectFit = 'fill'; 
                maskSize = '100% 100%';
                break;
            case 'fitStart': 
                objectFit = 'contain'; 
                objectPosition = 'left top'; 
                maskSize = 'contain'; 
                maskPosition = 'left top';
                break;
            case 'fitEnd': 
                objectFit = 'contain'; 
                objectPosition = 'right bottom'; 
                maskSize = 'contain'; 
                maskPosition = 'right bottom';
                break;
            case 'center': 
                objectFit = 'none'; 
                maskSize = 'auto';
                break;
            case 'fitCenter':
            case 'centerInside':
            default: 
                objectFit = 'contain'; 
                maskSize = 'contain';
                break;
        }

        // ---------------------------------------------------------
        // 2. New Props Implementation
        // ---------------------------------------------------------

        // A. Handle AdjustViewBounds
        const adjustViewBounds = attr['android:adjustViewBounds'] === 'true' || attr['adjustViewBounds'] === 'true';
        const layoutW = attr['android:layout_width'] || attr['layout_width'];
        const layoutH = attr['android:layout_height'] || attr['layout_height'];

        let cssWidth = '100%';
        let cssHeight = '100%';

        if (adjustViewBounds) {
            if (layoutW === 'wrap_content') {
                cssWidth = 'auto';
                baseStyle.includes('max-width') ? null : (cssWidth += '; max-width: 100%'); 
            }
            if (layoutH === 'wrap_content') {
                cssHeight = 'auto';
                baseStyle.includes('max-height') ? null : (cssHeight += '; max-height: 100%');
            }
        }

        // B. Handle CropToPadding
        const cropToPadding = attr['android:cropToPadding'] === 'true' || attr['cropToPadding'] === 'true';
        let cropStyle = '';
        if (cropToPadding) {
            cropStyle = `
                box-sizing: border-box; 
                background-clip: content-box;
            `;
            if (!adjustViewBounds) { 
                cropStyle += `padding: inherit;`; 
            }
        }

        // C. Handle Alpha
        const alpha = attr['android:alpha'] || attr['alpha'];
        let alphaStyle = '';
        if (alpha !== undefined && alpha !== null) {
            const opacityVal = parseFloat(alpha);
            if (!isNaN(opacityVal)) {
                alphaStyle = `opacity: ${opacityVal};`;
            }
        }

        // ---------------------------------------------------------
        // 3. Tint & Source Processing
        // ---------------------------------------------------------
        const tint = attr['app:tint'] || attr['android:tint'] || attr.tint;
        const tintMode = attr['app:tintMode'] || attr['android:tintMode'] || 'src_in';
        
        let tintColor = null;
        if (tint) {
            tintColor = this.resolver.resolveColor(tint);
        }

        let src = '';
        let svgContent = null;
        const rawSrc = attr.src || attr['android:src'];
        
        if (rawSrc) {
            if (rawSrc.startsWith('@drawable/') || rawSrc.startsWith('@mipmap/')) {
                const drawable = await this.resolver.resolveDrawable(rawSrc);
                if (drawable && drawable.type === 'svg') svgContent = drawable.value;
                else if (drawable && drawable.type === 'bitmap') src = drawable.value; 
            } 
            else if (rawSrc.startsWith('@color/') || rawSrc.startsWith('@android:color/') || rawSrc.startsWith('#')) {
                const color = this.resolver.resolveColor(rawSrc);
                svgContent = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1 1"><rect width="1" height="1" fill="${color}"/></svg>`;
                objectFit = 'cover'; 
                maskSize = 'cover'; 
            }
            else {
                src = rawSrc;
            }
        }
        
        if (!src && !svgContent) {
             svgContent = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="#CCCCCC"><path d="M21 19V5c0-1.1-.9-2-2-2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2zM8.5 13.5l2.5 3.01L14.5 12l4.5 6H5l3.5-4.5z"/></svg>`;
        }

        // ---------------------------------------------------------
        // 4. SVG Processing
        // ---------------------------------------------------------
        if (svgContent) {
            if (tintColor && tintMode === 'src_in') {
                svgContent = this.applySrcInTint(svgContent, tintColor);
            }
            if (scaleType === 'fitXY' && svgContent.includes('<svg') && !svgContent.includes('preserveAspectRatio')) {
                svgContent = svgContent.replace('<svg', '<svg preserveAspectRatio="none"');
            }
            src = `data:image/svg+xml;utf8,${encodeURIComponent(svgContent)}`;
        }

        // ---------------------------------------------------------
        // 5. Render
        // ---------------------------------------------------------
        
        const commonStyles = `
            ${alphaStyle}
            ${cropStyle}
            display: block;
            min-width: 0;
            min-height: 0;
            width: ${cssWidth};
            height: ${cssHeight};
        `;

        // 🔥 FIX: Generate ID string so BlueprintRenderer can find this element
        const idStr = attr.id ? `id="${attr.id.replace('@+id/', '')}"` : '';

        // Render Method A: CSS Mask (For complex tints)
        if (tintColor && tintMode !== 'src_in') {
            const maskStyle = `
                background-color: ${tintColor};
                -webkit-mask-image: url('${src}');
                mask-image: url('${src}');
                -webkit-mask-size: ${maskSize};
                mask-size: ${maskSize};
                -webkit-mask-repeat: no-repeat;
                mask-repeat: no-repeat;
                -webkit-mask-position: ${maskPosition};
                mask-position: ${maskPosition};
                ${commonStyles}
            `;
            // Added ${idStr} here
            return `<div class="android-view image-view" ${idStr} style="${baseStyle} ${maskStyle}"></div>`;
        } 
        
        // Render Method B: Standard Image Tag (src_in or No Tint)
        const imgStyle = `
            object-fit: ${objectFit};
            object-position: ${objectPosition};
            ${commonStyles}
        `;
        // Added ${idStr} here
        return `<img src="${src}" class="android-view image-view" ${idStr} style="${baseStyle} ${imgStyle}" alt="ImageView" />`;
    }

    applySrcInTint(svgContent, tintColor) {
        try {
            let tinted = svgContent;
            tinted = tinted.replace(/android:fillColor="[^"]*"/g, `android:fillColor="${tintColor}"`);
            tinted = tinted.replace(/fill="[^"]*"/g, `fill="${tintColor}"`);
            if (!tinted.includes('fill=')) {
                tinted = tinted.replace(/<path/g, `<path fill="${tintColor}"`);
            }
            return tinted;
        } catch (e) {
            console.error('❌ Tint application failed:', e);
            return svgContent;
        }
    }
}