// styles.xml & themes.xml (Complex)
const fs = acode.require('fs');

export class StyleParser {
    constructor() {
        // Map<StyleName, { parent: String, items: Object }>
        this.styles = new Map();
    }

    async parse(resPath) {
        const files = ['styles.xml', 'themes.xml'];

        for (const file of files) {
            const path = `${resPath}/values/${file}`;
            if (await fs(path).exists().catch(() => false)) {
                const content = await fs(path).readFile('utf-8');
                this._parseContent(content);
            }
        }
        console.log(`🎨 [StyleParser] Loaded ${this.styles.size} styles`);
    }

    _parseContent(xmlString) {
        // 🔥 Clean XML (same strategy as XmlParser)
        const cleanXml = xmlString
            .replace(/<\?xml.*?\?>/g, '')          // Remove XML declaration
            .replace(/<!--[\s\S]*?-->/g, '');      // Remove XML comments ✅ FIX

        const parser = new DOMParser();
        const doc = parser.parseFromString(cleanXml, 'text/xml');

        const styleTags = doc.getElementsByTagName('style');

        for (let i = 0; i < styleTags.length; i++) {
            const styleEl = styleTags[i];
            const name = styleEl.getAttribute('name');
            let parent = styleEl.getAttribute('parent');

            // Implicit parent: AppTheme.Child → AppTheme
            if (!parent && name && name.includes('.')) {
                parent = name.substring(0, name.lastIndexOf('.'));
            }

            const items = {};
            const itemTags = styleEl.getElementsByTagName('item');

            for (let j = 0; j < itemTags.length; j++) {
                const itemEl = itemTags[j];
                const attrName = itemEl
                    .getAttribute('name')
                    .replace('android:', '');
                items[attrName] = itemEl.textContent;
            }

            this.styles.set(name, { parent, items });
        }
    }

    getStyle(name) {
        if (!name) return null;
        const cleanName = name.replace('@style/', '');
        return this.styles.get(cleanName);
    }
}
