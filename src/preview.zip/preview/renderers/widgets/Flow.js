import { BaseView } from './BaseView.js';

export class Flow extends BaseView {
    async render(node) {
        const attr = node.attributes;
        const idStr = attr.id ? `id="${attr.id.replace('@+id/', '')}"` : '';
        
        // Flow এর নিজস্ব কোনো ভিজ্যুয়াল নেই, কিন্তু সলভারের জন্য এটি DOM এ থাকা দরকার
        return `<div class="android-view android-flow" ${idStr} 
                    style="display: none !important; width: 0px; height: 0px;">
                </div>`;
    }
}