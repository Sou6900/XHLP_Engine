import { TextView } from './TextView.js';

export class Button extends TextView {
    
    async render(node, parentType) {
        // 1. Get Base HTML
        let html = await super.render(node, parentType); 
        
        const attr = node.attributes;
        const resolver = this.resolver;

        // Robust Tint Check
        const bgTint = attr['android:backgroundTint'] || attr['app:backgroundTint'] || attr['backgroundTint'];
        
        let bgColor = '#bababa'; // Default gray
        
        if (bgTint) {
            bgColor = resolver.resolveColor(bgTint);
        } 
        else if (attr['android:background']) {
             const bg = resolver.resolveColor(attr['android:background']);
             if (bg !== 'transparent') bgColor = bg;
        }

        // --- Shadow Interaction Logic ---
        const shadowFilter = `drop-shadow(0px 1px 1px rgba(0,0,0,0.24))`;
        
        if (bgColor !== 'transparent') {
            const down = `this.style.filter='none'`;
            const up = `this.style.filter='${shadowFilter}'`;
            
            if (this.interactiveEvents) {
                this.interactiveEvents = this.interactiveEvents
                    .replace(/onmousedown="([^"]*)"/, `onmousedown="$1; ${down}"`)
                    .replace(/onmouseup="([^"]*)"/, `onmouseup="$1; ${up}"`)
                    .replace(/onmouseleave="([^"]*)"/, `onmouseleave="$1; ${up}"`)
                    .replace(/ontouchstart="([^"]*)"/, `ontouchstart="$1; ${down}"`)
                    .replace(/ontouchend="([^"]*)"/, `ontouchend="$1; ${up}"`);
            } else {
                this.interactiveEvents = `onmousedown="${down}" onmouseup="${up}" onmouseleave="${up}" ontouchstart="${down}" ontouchend="${up}"`;
            }
        }

        if (this.interactiveEvents) {
            html = html.replace('class="android-view', `${this.interactiveEvents} class="android-view`);
        }
        
        // --- Dimension Logic ---
        const layoutHeight = attr['android:layout_height'] || attr['layout_height'];
        const layoutWidth = attr['android:layout_width'] || attr['layout_width'];
        
        const isFixedH = layoutHeight && layoutHeight !== 'wrap_content' && layoutHeight !== 'match_parent';
        const isFixedW = layoutWidth && layoutWidth !== 'wrap_content' && layoutWidth !== 'match_parent';

        // --- Padding Logic ---
        const hasUserPadding = attr['android:padding'] || attr['padding'] || 
                             attr['android:paddingTop'] || attr['paddingTop'] ||
                             attr['android:paddingVertical'] || attr['paddingVertical'];

        // Reduced Vertical Padding (10px -> 6px) & Standard Horizontal (12px -> 16px)
        let py = isFixedH ? '0px' : '6px';
        let px = isFixedW ? '0px' : '16px'; 

        if (hasUserPadding) {
            py = '0px'; 
            px = '0px'; 
        }

        // --- Inset Simulation & Style ---
        let insetStyle = '';
        let shadowStyle = '';
        
        if (bgColor !== 'transparent') {
            insetStyle = `border: 4px solid transparent; background-clip: padding-box;`;
            shadowStyle = `filter: ${shadowFilter};`;
        }

        const buttonStyle = `
            display: flex;
            justify-content: center;
            align-items: center;
            padding: ${hasUserPadding ? '0' : `${py} ${px}`}; 
            
            /* Added min-width to match Android's default button constraint */
            min-width: ${isFixedW ? '0px' : '64px'}; 
            min-height: 0;
            
            height: auto;
            
            /* Text Style */
            text-transform: uppercase;
            letter-spacing: 0.08em;
            font-weight: 500;
            white-space: nowrap !important; 
            
            /* Shape & Color */
            border-radius: 4px; 
            background-color: ${bgColor}; 
            color: white;
            
            /* Browser Reset */
            border: none;
            outline: none;
            box-shadow: none;
            
            /* Insets & Initial Shadow */
            ${insetStyle}
            ${shadowStyle}
            
            cursor: pointer;
            overflow: visible; 
            transition: filter 0.1s ease;
        `;

        return html
            .replace('class="android-view text-view"', 'class="android-view android-button"')
            .replace('style="', `style="${buttonStyle} `);
    }
}