// PreviewEngine.js - With Menu Support
import { ProjectContext } from './ProjectContext.js';
import { XmlParser } from '../parsers/XmlParser.js';
import { ResourceResolver } from '../resolvers/ResourceResolver.js';
import { ViewFactory } from '../renderers/ViewFactory.js'; 
import { MenuInflater } from '../parsers/MenuInflater.js'; // 🔥 NEW Import

export class PreviewEngine {
    constructor() {
        this.context = new ProjectContext();
        this.parser = new XmlParser();
        this.resolver = new ResourceResolver(this.context);
        this.viewFactory = new ViewFactory(this.resolver);
        this.menuInflater = new MenuInflater(this.resolver); // 🔥 NEW Init
    }

    async init(fileUri) {
        await this.context.initialize(fileUri);
        await this.resolver.loadResources();
    }

    async render(xmlContent, width, height) {
        try {
            const ast = this.parser.parse(xmlContent);
            if (!ast) throw new Error("Invalid XML");

            // 🔥 MENU FILE DETECTION
            if (ast.type === 'menu') {
                return await this._renderMenuPreview(ast, width, height);
            }

            // Normal Layout Rendering
            const getRootAttr = (name) => ast.attributes[name] || ast.attributes[`android:${name}`];
            const fitsAttr = getRootAttr('fitsSystemWindows');
            const isFullScreen = getRootAttr('windowFullscreen') === 'true' || fitsAttr === 'false';

            let statusBarColor = null;
            this._findNodeById(ast, 'status_bar', (node) => {
                const bgAttr = node.attributes['background'] || node.attributes['android:background'];
                if (bgAttr) statusBarColor = this.resolver.resolveColor(bgAttr);
            });

            if (!statusBarColor) {
                statusBarColor = this.resolver.resolveColor('?android:attr/statusBarColor') || 
                                this.resolver.resolveColor('?attr/colorPrimaryDark');
            }

            const html = await this._renderNode(ast, 'Root', width, height, {});
            
            return { html, statusBarColor, isFullScreen, fitsSystemWindows: fitsAttr }; 
        } catch (e) {
            console.error(e);
            return { html: `<div style="color:red; padding:20px;">Error: ${e.message}</div>`, statusBarColor: null, isFullScreen: false };
        }
    }

    /**
     * 🔥 NEW: Creates a virtual Toolbar layout to display the menu
     */
    async _renderMenuPreview(menuAst, width, height) {
        // 1. Parse the menu items
        const menuItems = this.menuInflater.parse(menuAst);

        // 2. Create a Synthetic Tree (ConstraintLayout -> Toolbar)
        // This simulates how a menu looks inside an app
        const syntheticRoot = {
            type: 'ConstraintLayout',
            attributes: {
                'android:layout_width': 'match_parent',
                'android:layout_height': 'match_parent',
                'android:background': '#FFFFFF' // Clean background for preview
            },
            children: [
                {
                    type: 'Toolbar',
                    attributes: {
                        'android:id': '@+id/preview_toolbar',
                        'android:layout_width': 'match_parent',
                        'android:layout_height': 'wrap_content',
                        'android:background': '#6200EE', // Default Material Purple
                        'android:title': 'Menu Preview',
                        'android:subtitle': 'Action Bar',
                        'app:titleTextColor': '#FFFFFF',
                        'android:elevation': '4dp',
                        'app:layout_constraintTop_toTopOf': 'parent'
                    },
                    children: [],
                    menuItems: menuItems // 🔥 Injecting items for Toolbar.js to read
                },
                {
                    type: 'TextView',
                    attributes: {
                        'android:layout_width': 'wrap_content',
                        'android:layout_height': 'wrap_content',
                        'android:text': 'Menu Preview Mode',
                        'android:textColor': '#888888',
                        'app:layout_constraintStart_toStartOf': 'parent',
                        'app:layout_constraintEnd_toEndOf': 'parent',
                        'app:layout_constraintTop_toBottomOf': '@+id/preview_toolbar',
                        'app:layout_constraintBottom_toBottomOf': 'parent'
                    }
                }
            ]
        };

        // 3. Render the synthetic tree
        const html = await this._renderNode(syntheticRoot, 'Root', width, height, {});
        
        // Return with a default status bar color matching the toolbar
        return { html, statusBarColor: '#3700B3', isFullScreen: false, fitsSystemWindows: true };
    }

    async _renderNode(node, parentType, availableW, availableH, context = {}) {
        if (!node) return '';
        
        const attr = node.attributes || {};
        const getAttr = (k) => attr[k] || attr[`android:${k}`];
        
        const explicitDir = getAttr('layoutDirection');
        const currentDir = explicitDir || context.layoutDirection || 'ltr';

        if (!explicitDir) {
            if (!node.attributes) node.attributes = {};
            node.attributes['android:layoutDirection'] = currentDir;
        }

        const nextContext = { ...context, layoutDirection: currentDir };
        const renderer = this.viewFactory.create(node.type);
        if (!renderer) return `<div style="border:1px dashed red; padding:10px;">Unknown View: ${node.type}</div>`;

        const isLayout = this.viewFactory.isViewGroup(renderer);

        if (isLayout) {
            const renderChild = async (child, pType, overrideW, overrideH) => 
                await this._renderNode(child, pType, overrideW || availableW, overrideH || availableH, nextContext);

            if (typeof renderer.renderWithBounds === 'function') {
                return await renderer.renderWithBounds(node, availableW, availableH, renderChild, parentType);
            }
            return await renderer.render(node, renderChild, parentType);
        } 
        else {
            if (renderer.constructor.name === 'RecyclerView') {
                renderer.renderSubLayout = async (xmlString) => {
                    const itemAst = this.parser.parse(xmlString);
                    return await this._renderNode(itemAst, 'ViewGroup', availableW, availableH, nextContext);
                };
            }
            return await renderer.render(node, parentType);
        }
    }
    
    _findNodeById(node, id, callback) {
        if (!node) return;
        const nodeId = node.attributes?.id || node.attributes?.['android:id'];
        if (nodeId && (nodeId === `@+id/${id}` || nodeId === `@id/${id}`)) {
            callback(node);
        }
        if (node.children) {
            node.children.forEach(child => this._findNodeById(child, id, callback));
        }
    }
}