import { FrameLayout } from './FrameLayout.js';

export class NavigationView extends FrameLayout {
    constructor(resolver) {
        super(resolver);
    }

    // NavigationView is basically a specialized FrameLayout usually used inside Drawer
    async renderWithBounds(node, width, height, renderChildCallback, parentType) {
        // ডিফল্ট ব্যাকগ্রাউন্ড সাদা যদি না দেওয়া থাকে
        if (!node.attributes.background && !node.attributes['android:background']) {
            node.attributes['android:background'] = '#FFFFFF';
        }
        
        // FrameLayout এর রেন্ডার মেথড ব্যবহার করব
        let html = await super.renderWithBounds(node, width, height, renderChildCallback, parentType);
        
        // NavigationView ক্লাস রিপ্লেস করা
        return html.replace('class="android-layout frame-layout"', 'class="android-layout navigation-view"');
    }
}