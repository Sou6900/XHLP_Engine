// BlueprintRenderer.js V4.1 - Detour Routing (U-Turn) Update
export class BlueprintRenderer {
    constructor() {
        this.constraintData = new Map();
        this.svgOverlay = null;
        this.selectedId = null;
        this.rootElement = null;
        this._clickHandler = this.handleViewClick.bind(this);
    }

    enableBlueprint(rootElement, constraintSolver) {
        if (!rootElement) return;
        this.rootElement = rootElement;

        const frame = rootElement.closest('.device-frame');
        if (frame) {
            frame.classList.add('blueprint-mode');
        }

        rootElement.removeEventListener('click', this._clickHandler);
        rootElement.addEventListener('click', this._clickHandler);

        if (constraintSolver && constraintSolver.nodeMap) {
            this.extractConstraintData(constraintSolver.nodeMap);
            this.drawSpringLines();
        }
    }
    

    disableBlueprint(rootElement) {
        if (!rootElement) return;

        const frame = rootElement.closest('.device-frame');
        if (frame) {
            frame.classList.remove('blueprint-mode');
        }

        rootElement.removeEventListener('click', this._clickHandler);

        if (this.svgOverlay) {
            this.svgOverlay.remove();
            this.svgOverlay = null;
        }
        this.selectedId = null;
    }
    
    
    handleScroll() {
        if (this.isScrolling) return;
        
        this.isScrolling = true;
        window.requestAnimationFrame(() => {
            this.drawSpringLines(); // স্ক্রল করার সাথে সাথে লাইনগুলো রি-ড্র হবে
            this.isScrolling = false;
        });
    }

    handleViewClick(e) {
        const targetView = e.target.closest('.android-view') || e.target.closest('.android-layout');
        
        if (!targetView || targetView === this.rootElement) {
            this.selectedId = null;
        } else {
            const rawId = targetView.getAttribute('id');
            this.selectedId = rawId ? rawId.replace(/@\+?id\//, '') : null;
            if (this.selectedId) {
                this.inspectView(this.selectedId);
            }
        }
        this.drawSpringLines();
    }

    inspectView(id) {
        const data = this.constraintData.get(id);
        if (!data) return;
        console.group(`%c 🔍 Inspector: ${id}`, 'color: #00E5FF; font-weight: bold;');
        console.log(data);
        console.groupEnd();
    }

    extractConstraintData(nodeMap) {
        this.constraintData.clear();
        nodeMap.forEach((state, id) => {
            const attrs = state.node.attributes;
            
            const type = state.node.type || '';
            const isGuideline = state.isGuideline || type.endsWith('Guideline');
            const isBarrier = type.includes('Barrier');
            const barrierDir = this._getAttr(attrs, 'barrierDirection');

            const constraints = {
                id: id,
                x: state.x, 
                y: state.y, 
                w: state.w, 
                h: state.h,
                
                isGuideline: isGuideline,
                isBarrier: isBarrier,
                
                guideX: state.guideX,
                guideY: state.guideY,
                barrierDir: barrierDir,
                
                baseline: state.baseline || (state.h * 0.8),
                
                // Circular Constraints
                circleTo: this._getAttr(attrs, 'layout_constraintCircle'),
                circleRadius: this._getAttr(attrs, 'layout_constraintCircleRadius'),
                circleAngle: this._getAttr(attrs, 'layout_constraintCircleAngle'),

                // Standard Constraints
                startToStart: this._getAttr(attrs, 'layout_constraintStart_toStartOf'),
                startToEnd: this._getAttr(attrs, 'layout_constraintStart_toEndOf'),
                endToStart: this._getAttr(attrs, 'layout_constraintEnd_toStartOf'),
                endToEnd: this._getAttr(attrs, 'layout_constraintEnd_toEndOf'),
                
                topToTop: this._getAttr(attrs, 'layout_constraintTop_toTopOf'),
                topToBottom: this._getAttr(attrs, 'layout_constraintTop_toBottomOf'),
                bottomToTop: this._getAttr(attrs, 'layout_constraintBottom_toTopOf'),
                bottomToBottom: this._getAttr(attrs, 'layout_constraintBottom_toBottomOf'),
                baselineToBaseline: this._getAttr(attrs, 'layout_constraintBaseline_toBaselineOf'),
                
                inHorizontalChain: state.inHorizontalChain,
                inVerticalChain: state.inVerticalChain
            };
            this.constraintData.set(id, constraints);
        });
    }

    drawSpringLines() {
        if (this.svgOverlay) this.svgOverlay.remove();
        if (!this.rootElement) return;

        const bounds = this.rootElement.getBoundingClientRect();
        const unscaledWidth = this.rootElement.offsetWidth;
        const unscaledHeight = this.rootElement.offsetHeight;
        
        if (unscaledWidth === 0 || bounds.width === 0) return;

        const scaleX = bounds.width / unscaledWidth;
        const scaleY = bounds.height / unscaledHeight;

        const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
        svg.setAttribute('class', 'blueprint-springs-overlay');
        svg.style.cssText = `position: absolute; top: 0; left: 0; width: 100%; height: 100%; pointer-events: none; z-index: 9999;`;
        svg.setAttribute('width', unscaledWidth);
        svg.setAttribute('height', unscaledHeight);
        svg.setAttribute('viewBox', `0 0 ${unscaledWidth} ${unscaledHeight}`);

        this.constraintData.forEach((constraints, id) => {
            if (constraints.isGuideline) {
                this.drawGuidelineVisuals(svg, constraints, unscaledWidth, unscaledHeight);
                return;
            }

            if (constraints.isBarrier) {
                this.drawBarrierVisuals(svg, constraints, unscaledWidth, unscaledHeight);
                return;
            }

            const element = this.rootElement.querySelector(`[id="${id}"]`);
            if (!element) return;

            const rect = this.getRelativeRect(element, this.rootElement, scaleX, scaleY);
            
            let opacity = 1.0;
            if (this.selectedId) {
                const circleTargetId = constraints.circleTo ? constraints.circleTo.replace(/@\+?id\//, '') : null;
                
                if (id === this.selectedId || circleTargetId === this.selectedId) {
                    opacity = 1.0;
                    if (id === this.selectedId) this.drawAnchors(svg, rect); 
                } else {
                    opacity = 0.15; 
                }
            }

            if (constraints.circleTo) {
                this.drawCircularConstraint(svg, constraints, rect, opacity, scaleX, scaleY);
            } else {
                this.drawHorizontalConstraints(svg, constraints, rect, opacity, scaleX, scaleY);
                this.drawVerticalConstraints(svg, constraints, rect, opacity, scaleX, scaleY);
            }
        });

        this.rootElement.appendChild(svg);
        this.svgOverlay = svg;
    }

    drawCircularConstraint(svg, c, rect, opacity, scaleX, scaleY) {
        const targetId = this._getIdFromAttr(c.circleTo);
        let targetRect;
        
        if (targetId === 'parent') {
            targetRect = { 
                left:0, top:0, 
                width: this.rootElement.offsetWidth, 
                height: this.rootElement.offsetHeight 
            };
        } else {
            targetRect = this.getTargetRect(c.circleTo, this.rootElement, scaleX, scaleY);
        }

        if (!targetRect) return;

        const sourceCx = rect.left + rect.width / 2;
        const sourceCy = rect.top + rect.height / 2;
        
        const targetCx = targetRect.left + targetRect.width / 2;
        const targetCy = targetRect.top + targetRect.height / 2;

        const color = (c.id === this.selectedId) ? '#3E86F2' : '#64C8FF';

        const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
        path.setAttribute('d', `M ${targetCx} ${targetCy} L ${sourceCx} ${sourceCy}`);
        path.setAttribute('stroke', color);
        path.setAttribute('stroke-width', '1.5');
        path.setAttribute('opacity', opacity);
        svg.appendChild(path);

        const circle = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
        circle.setAttribute('cx', targetCx);
        circle.setAttribute('cy', targetCy);
        circle.setAttribute('r', '3');
        circle.setAttribute('fill', color);
        circle.setAttribute('opacity', opacity);
        svg.appendChild(circle);

        this.drawArrowHead(svg, sourceCx, sourceCy, targetCx, targetCy, color, opacity);
    }

    drawGuidelineVisuals(svg, c, parentW, parentH) {
        let x1, y1, x2, y2;
        const isVertical = (c.guideX !== null && c.guideX !== undefined);

        if (isVertical) {
            x1 = c.guideX; y1 = 0; x2 = c.guideX; y2 = parentH;
        } else {
            x1 = 0; y1 = c.guideY; x2 = parentW; y2 = c.guideY;
        }

        const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
        path.setAttribute('d', `M ${x1} ${y1} L ${x2} ${y2}`);
        path.setAttribute('stroke', '#E91E63'); 
        path.setAttribute('stroke-width', '1');
        path.setAttribute('stroke-dasharray', '5, 3');
        path.setAttribute('opacity', '0.8');
        svg.appendChild(path);

        const circle = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
        circle.setAttribute('cx', isVertical ? x1 : 12);
        circle.setAttribute('cy', isVertical ? 12 : y1);
        circle.setAttribute('r', '4');
        circle.setAttribute('fill', '#E91E63');
        svg.appendChild(circle);
    }

    drawBarrierVisuals(svg, c, parentW, parentH) {
        let x1, y1, x2, y2;
        const isVertical = ['start', 'end', 'left', 'right'].includes(c.barrierDir);

        if (isVertical) {
            x1 = c.x; y1 = 0; x2 = c.x; y2 = parentH;
        } else {
            x1 = 0; y1 = c.y; x2 = parentW; y2 = c.y;
        }

        const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
        path.setAttribute('d', `M ${x1} ${y1} L ${x2} ${y2}`);
        path.setAttribute('stroke', '#FF9800'); 
        path.setAttribute('stroke-width', '2');
        path.setAttribute('stroke-dasharray', '8, 4'); 
        path.setAttribute('opacity', '0.8');
        svg.appendChild(path);

        const mark = document.createElementNS('http://www.w3.org/2000/svg', 'path');
        if (isVertical) {
            const d = `M ${x1 - 4} 10 L ${x1 + 4} 10 L ${x1} 18 Z`; 
            mark.setAttribute('d', d);
        } else {
            const d = `M 10 ${y1 - 4} L 10 ${y1 + 4} L 18 ${y1} Z`;
            mark.setAttribute('d', d);
        }
        mark.setAttribute('fill', '#FF9800');
        svg.appendChild(mark);
    }

    drawAnchors(svg, rect) {
        const anchors = [
            { cx: rect.left, cy: rect.top + rect.height / 2 },       
            { cx: rect.right, cy: rect.top + rect.height / 2 },      
            { cx: rect.left + rect.width / 2, cy: rect.top },        
            { cx: rect.left + rect.width / 2, cy: rect.bottom }      
        ];

        anchors.forEach(pos => {
            const circle = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
            circle.setAttribute('cx', pos.cx);
            circle.setAttribute('cy', pos.cy);
            circle.setAttribute('r', '3.5');
            circle.setAttribute('fill', '#ffffff');
            circle.setAttribute('stroke', '#3E86F2');
            circle.setAttribute('stroke-width', '2');
            svg.appendChild(circle);
        });
    }

    drawHorizontalConstraints(svg, c, rect, opacity, scaleX, scaleY) {
        const centerY = rect.top + rect.height / 2;
        
        const hasStart = c.startToStart || c.startToEnd;
        const hasEnd = c.endToStart || c.endToEnd;
        const isSpring = hasStart && hasEnd;
        
        const type = c.inHorizontalChain ? 'chain' : (isSpring ? 'spring' : 'straight');

        const processConstraint = (attr, sourceEdge, targetEdge) => {
            if (!attr) return;
            const targetId = this._getIdFromAttr(attr);
            if (this.selectedId && c.id !== this.selectedId && targetId !== this.selectedId) return;

            let targetRect, anchorX, targetY;

            if (targetId === 'parent') {
                targetRect = { right: this.rootElement.offsetWidth, left: 0, top: 0, height: this.rootElement.offsetHeight };
                anchorX = (targetEdge === 'right') ? targetRect.right : targetRect.left;
                targetY = centerY;
            } else {
                const targetData = this.constraintData.get(targetId);
                if (targetData && (targetData.isGuideline || targetData.isBarrier)) {
                    anchorX = (targetData.isGuideline && targetData.guideX !== null) ? targetData.guideX : targetData.x;
                    targetY = centerY; 
                } else {
                    targetRect = this.getTargetRect(attr, this.rootElement, scaleX, scaleY);
                    if (!targetRect) return;
                    anchorX = (targetEdge === 'right') ? targetRect.right : targetRect.left;
                    targetY = targetRect.top + targetRect.height / 2;
                }
            }
            
            const startX = (sourceEdge === 'right') ? rect.right : rect.left;
            // Passed sourceEdge
            this.drawConstraint(svg, startX, centerY, anchorX, targetY, type, c.id, targetId, opacity, 'horizontal', sourceEdge);
        };

        if (c.startToStart) processConstraint(c.startToStart, 'left', 'left');
        if (c.startToEnd) processConstraint(c.startToEnd, 'left', 'right');
        if (c.endToStart) processConstraint(c.endToStart, 'right', 'left');
        if (c.endToEnd) processConstraint(c.endToEnd, 'right', 'right');
    }

    drawVerticalConstraints(svg, c, rect, opacity, scaleX, scaleY) {
        const centerX = rect.left + rect.width / 2;
        
        const hasTop = c.topToTop || c.topToBottom;
        const hasBottom = c.bottomToTop || c.bottomToBottom;
        const isSpring = hasTop && hasBottom;
        
        const type = c.inVerticalChain ? 'chain' : (isSpring ? 'spring' : 'straight');

        const processConstraint = (attr, sourceEdge, targetEdge) => {
            if (!attr) return;
            const targetId = this._getIdFromAttr(attr);
            if (this.selectedId && c.id !== this.selectedId && targetId !== this.selectedId) return;

            let anchorY, targetX;

            if (targetId === 'parent') {
                const parentH = this.rootElement.offsetHeight;
                anchorY = (targetEdge === 'bottom') ? parentH : 0;
                targetX = centerX;
            } else {
                const targetData = this.constraintData.get(targetId);
                if (targetData && (targetData.isGuideline || targetData.isBarrier)) {
                    anchorY = (targetData.isGuideline && targetData.guideY !== null) ? targetData.guideY : targetData.y;
                    targetX = centerX;
                } else {
                    const targetRect = this.getTargetRect(attr, this.rootElement, scaleX, scaleY);
                    if (!targetRect) return;
                    anchorY = (targetEdge === 'bottom') ? targetRect.bottom : targetRect.top;
                    targetX = targetRect.left + targetRect.width / 2;
                }
            }

            const startY = (sourceEdge === 'bottom') ? rect.bottom : rect.top;
            // Passed sourceEdge
            this.drawConstraint(svg, centerX, startY, targetX, anchorY, type, c.id, targetId, opacity, 'vertical', sourceEdge);
        };

        if (c.topToTop) processConstraint(c.topToTop, 'top', 'top');
        if (c.topToBottom) processConstraint(c.topToBottom, 'top', 'bottom');
        if (c.bottomToTop) processConstraint(c.bottomToTop, 'bottom', 'top');
        if (c.bottomToBottom) processConstraint(c.bottomToBottom, 'bottom', 'bottom');

        if (c.baselineToBaseline) {
            const targetRect = this.getTargetRect(c.baselineToBaseline, this.rootElement, scaleX, scaleY);
            const targetId = this._getIdFromAttr(c.baselineToBaseline);
            const targetData = this.constraintData.get(targetId);
            if (targetData && targetRect) {
                const sourceBaseY = rect.top + c.baseline;
                const targetBaseY = targetRect.top + targetData.baseline;
                // Baseline uses 'bottom' logic for visual simplicity
                this.drawConstraint(svg, rect.left, sourceBaseY, targetRect.left, targetBaseY, 'baseline', c.id, targetId, opacity, 'vertical', 'bottom');
            }
        }
    }

    // Correct Arrow Direction for Detour Paths
    drawConstraint(svg, x1, y1, x2, y2, type, sourceId, targetId, opacity, orientation, sourceEdge) {
        const isSelected = (sourceId === this.selectedId);
        const finalOpacity = isSelected ? 1.0 : opacity;
        const color = isSelected ? '#3E86F2' : '#64C8FF'; 

        const length = Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2));
        if (length < 2) return;

        // Chain Handling
        if (type === 'chain') {
            this.drawChainConnection(svg, x1, y1, x2, y2, color, finalOpacity, orientation);
            return; 
        }

        const isAngled = Math.abs(x2 - x1) > 10 && Math.abs(y2 - y1) > 10;
        const isElbow = (type === 'straight' && length > 50 && isAngled);
        const isSameAxis = (orientation === 'vertical' && Math.abs(y1 - y2) < 10) || 
                          (orientation === 'horizontal' && Math.abs(x1 - x2) < 10);

        // Arrow Angle Logic 
        let arrowAngle;
        
        if (isSameAxis && length > 30) {
            // Detour পাথ সবসময় টার্গেটের এজ (Edge) এর দিকে লম্বভাবে ঢোকে।
            // তাই sourceEdge দেখেই আমরা অ্যাঙ্গেল বলে দিতে পারি।
            if (sourceEdge === 'top') {
                arrowAngle = Math.PI / 2; // উপর থেকে নিচে নামছে (Points Down)
            } else if (sourceEdge === 'bottom') {
                arrowAngle = -Math.PI / 2; // নিচ থেকে উপরে উঠছে (Points Up)
            } else if (sourceEdge === 'left') {
                arrowAngle = 0; // বাম থেকে ডানে যাচ্ছে (Points Right)
            } else if (sourceEdge === 'right') {
                arrowAngle = Math.PI; // ডান থেকে বামে আসছে (Points Left)
            } else {
                // Fallback (Safe check)
                arrowAngle = (orientation === 'horizontal') ? ((x2 > x1) ? 0 : Math.PI) : ((y2 > y1) ? Math.PI / 2 : -Math.PI / 2);
            }
        } 
        else if (isElbow) {
            if (orientation === 'horizontal') {
                arrowAngle = (x2 > x1) ? 0 : Math.PI; 
            } else {
                arrowAngle = (y2 > y1) ? Math.PI / 2 : -Math.PI / 2;
            }
        } 
        else {
            arrowAngle = Math.atan2(y2 - y1, x2 - x1);
        }

        // অ্যারো পজিশন ক্যালকুলেশন (গ্যাপ মেইনটেইন করে)
        const gap = 3;
        // লক্ষ্য করুন: Detour পাথে অ্যারো সোজা লাইনে থাকে না, তাই Start Point সবসময় (x1, y1) নয়।
        // তবে আমরা অ্যারো হেড (Tip) আগে আঁকছি, তাই এটা ঠিক আছে।
        
        this.drawArrowHeadWithAngle(svg, x2, y2, arrowAngle, color, finalOpacity);

        // লাইনের শেষ বিন্দু (যেখানে অ্যারো শুরু হয়েছে)
        const arrowBackOff = 5;
        const endX = x2 - arrowBackOff * Math.cos(arrowAngle);
        const endY = y2 - arrowBackOff * Math.sin(arrowAngle);

        let d = '';
        if (type === 'spring') {
            d = this.generateTightSpringPath(x1, y1, endX, endY);
        } 
        else if (isSameAxis && length > 30) {
            d = this.generateDetourPath(x1, y1, endX, endY, sourceEdge);
        }
        else if (isElbow) {
            d = this.generateElbowPath(x1, y1, endX, endY, orientation);
        } else {
            // সাধারণ স্ট্রেইট লাইনের ক্ষেত্রে গ্যাপ অ্যাডজাস্টমেন্ট
            const startX = x1 + gap * Math.cos(arrowAngle);
            const startY = y1 + gap * Math.sin(arrowAngle);
            d = `M ${startX} ${startY} L ${endX} ${endY}`;
        }

        const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
        path.setAttribute('d', d);
        path.setAttribute('stroke', color);
        path.setAttribute('stroke-width', isSelected ? '1.8' : '1.2');
        path.setAttribute('fill', 'none');
        path.setAttribute('opacity', finalOpacity);
        svg.appendChild(path);
    }

    /**
    * Generates a U-Turn (Detour) path for same-axis constraints
    */
    generateDetourPath(x1, y1, x2, y2, edge) {
        const offset = 30; // Detour distance

        if (edge === 'top') {
            // Up -> Across -> Down
            const midY = y1 - offset;
            return `M ${x1} ${y1} L ${x1} ${midY} L ${x2} ${midY} L ${x2} ${y2}`;
        } 
        else if (edge === 'bottom') {
            // Down -> Across -> Up
            const midY = y1 + offset;
            return `M ${x1} ${y1} L ${x1} ${midY} L ${x2} ${midY} L ${x2} ${y2}`;
        } 
        else if (edge === 'left') {
            // Left -> Vertical -> Right
            const midX = x1 - offset;
            return `M ${x1} ${y1} L ${midX} ${y1} L ${midX} ${y2} L ${x2} ${y2}`;
        } 
        else if (edge === 'right') {
            // Right -> Vertical -> Left
            const midX = x1 + offset;
            return `M ${x1} ${y1} L ${midX} ${y1} L ${midX} ${y2} L ${x2} ${y2}`;
        }
        
        return `M ${x1} ${y1} L ${x2} ${y2}`; // Fallback
    }

    drawChainConnection(svg, x1, y1, x2, y2, color, opacity) {
        const dx = x2 - x1;
        const dy = y2 - y1;
        const distance = Math.hypot(dx, dy);
        const angleDeg = Math.atan2(dy, dx) * 180 / Math.PI;

        const linkSize = 18;
        const linkStep = 14; 
        const linkId = "chainLinkSymbol";

        if (!document.getElementById(linkId)) {
            const defs = document.createElementNS("http://www.w3.org/2000/svg", "defs");
            const symbol = document.createElementNS("http://www.w3.org/2000/svg", "symbol");

            symbol.setAttribute("id", linkId);
            symbol.setAttribute("viewBox", "0 0 24 24");

            const paths = [
                "M3 3c-1.108 0-2 .892-2 2v4c0 1.108.892 2 2 2h3c1.108 0 2-.892 2-2V5c0-1.108-.892-2-2-2zm0 1h3c.554 0 1 .446 1 1v4c0 .554-.446 1-1 1H3c-.554 0-1-.446-1-1V5c0-.554.446-1 1-1z",
                "M3 13c-1.108 0-2 .892-2 2v4c0 1.108.892 2 2 2h3c1.108 0 2-.892 2-2v-4c0-1.108-.892-2-2-2zm0 1h3c.554 0 1 .446 1 1v4c0 .554-.446 1-1 1H3c-.554 0-1-.446-1-1v-4c0-.554.446-1 1-1z"
            ];

            paths.forEach(d => {
                const p = document.createElementNS("http://www.w3.org/2000/svg", "path");
                p.setAttribute("d", d);
                p.setAttribute("fill", color);
                symbol.appendChild(p);
            });

            defs.appendChild(symbol);
            svg.appendChild(defs);
        }

        const group = document.createElementNS("http://www.w3.org/2000/svg", "g");
        group.setAttribute("transform", `translate(${x1}, ${y1}) rotate(${angleDeg})`);
        group.setAttribute("opacity", opacity);

        const count = Math.floor(distance / linkStep);

        for (let i = 0; i < count; i++) {
            const use = document.createElementNS("http://www.w3.org/2000/svg", "use");
            use.setAttributeNS("http://www.w3.org/1999/xlink", "href", `#${linkId}`);
            use.setAttribute("x", i * linkStep);
            use.setAttribute("y", -linkSize / 2);
            use.setAttribute("width", linkSize);
            use.setAttribute("height", linkSize);
            use.setAttribute("transform", `rotate(-90 ${i * linkStep + linkSize / 2} 0)`);
            group.appendChild(use);
        }

        svg.appendChild(group);
    }

    generateElbowPath(x1, y1, x2, y2, orientation) {
        const midX = x1 + (x2 - x1) / 2;
        const midY = y1 + (y2 - y1) / 2;

        if (orientation === 'horizontal') {
            return `M ${x1} ${y1} L ${midX} ${y1} L ${midX} ${y2} L ${x2} ${y2}`;
        } else {
            return `M ${x1} ${y1} L ${x1} ${midY} L ${x2} ${midY} L ${x2} ${y2}`;
        }
    }

    generateTightSpringPath(x1, y1, x2, y2) {
        const segmentLen = 4; 
        const amplitude = 2.0;
        const totalDist = Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2));
        
        if (totalDist < segmentLen * 2) return `M ${x1} ${y1} L ${x2} ${y2}`;

        const segments = Math.floor(totalDist / segmentLen);
        const dx = (x2 - x1) / totalDist;
        const dy = (y2 - y1) / totalDist;
        const nx = -dy;
        const ny = dx;

        let d = `M ${x1} ${y1}`;
        for (let i = 1; i < segments; i++) {
            const tx = x1 + dx * (i * segmentLen);
            const ty = y1 + dy * (i * segmentLen);
            const offset = (i % 2 === 0) ? amplitude : -amplitude;
            d += ` L ${tx + nx * offset} ${ty + ny * offset}`;
        }
        d += ` L ${x2} ${y2}`;
        return d;
    }

    drawArrowHead(svg, tipX, tipY, tailX, tailY, color, opacity) {
        const size = 5;
        const angle = Math.atan2(tipY - tailY, tipX - tailX);
        const x1 = tipX - size * Math.cos(angle - Math.PI / 6);
        const y1 = tipY - size * Math.sin(angle - Math.PI / 6);
        const x2 = tipX - size * Math.cos(angle + Math.PI / 6);
        const y2 = tipY - size * Math.sin(angle + Math.PI / 6);

        const d = `M ${x1} ${y1} L ${tipX} ${tipY} L ${x2} ${y2}`;
        const arrow = document.createElementNS('http://www.w3.org/2000/svg', 'path');
        arrow.setAttribute('d', d);
        arrow.setAttribute('stroke', color);
        arrow.setAttribute('stroke-width', '1.5');
        arrow.setAttribute('fill', 'none');
        arrow.setAttribute('stroke-linecap', 'round');
        arrow.setAttribute('stroke-linejoin', 'round');
        arrow.setAttribute('opacity', opacity);
        svg.appendChild(arrow);
    }

    _getIdFromAttr(attrVal) { return attrVal ? attrVal.replace(/@\+?id\//, '') : null; }
    _getAttr(attrs, name) { return attrs[name] || attrs[`android:${name}`] || attrs[`app:${name}`]; }
    
    
    getRelativeRect(element, rootElement, scaleX = 1, scaleY = 1) {
        if (!element || !rootElement) return { left:0, top:0, right:0, bottom:0, width:0, height:0 };
        
        const e = element.getBoundingClientRect();
        const r = rootElement.getBoundingClientRect();

        const scrollX = rootElement.scrollLeft || 0;
        const scrollY = rootElement.scrollTop || 0;

        return {
            // আগে স্কেল দিয়ে ভাগ করুন, তারপর স্ক্রল যোগ করুন (Bracket Order Change)
            left: (e.left - r.left) / scaleX + scrollX,
            top: (e.top - r.top) / scaleY + scrollY,
            right: (e.right - r.left) / scaleX + scrollX,
            bottom: (e.bottom - r.top) / scaleY + scrollY,
            
            width: e.width / scaleX,
            height: e.height / scaleY
        };
    }

    getTargetRect(targetIdRaw, rootElement, scaleX, scaleY) {
        const targetId = this._getIdFromAttr(targetIdRaw);
        if (targetId === 'parent') {
            return { 
                left:0, top:0, 
                right: rootElement.offsetWidth, 
                bottom: rootElement.offsetHeight, 
                width: rootElement.offsetWidth, 
                height: rootElement.offsetHeight 
            };
        }
        const t = rootElement.querySelector(`[id="${targetId}"]`);
        return t ? this.getRelativeRect(t, rootElement, scaleX, scaleY) : null;
    }
    
    drawArrowHeadWithAngle(svg, tipX, tipY, angle, color, opacity) {
        const size = 5;
        const x1 = tipX - size * Math.cos(angle - Math.PI / 6);
        const y1 = tipY - size * Math.sin(angle - Math.PI / 6);
        const x2 = tipX - size * Math.cos(angle + Math.PI / 6);
        const y2 = tipY - size * Math.sin(angle + Math.PI / 6);

        const d = `M ${x1} ${y1} L ${tipX} ${tipY} L ${x2} ${y2}`;
        const arrow = document.createElementNS('http://www.w3.org/2000/svg', 'path');
        arrow.setAttribute('d', d);
        arrow.setAttribute('stroke', color);
        arrow.setAttribute('stroke-width', '1.5');
        arrow.setAttribute('fill', 'none');
        arrow.setAttribute('stroke-linecap', 'round');
        arrow.setAttribute('stroke-linejoin', 'round');
        arrow.setAttribute('opacity', opacity);
        svg.appendChild(arrow);
    }
}