// export class VerticalSolver {
//     constructor(solver) {
//         this.solver = solver;
//         this.helper = solver.helper;
//     }

//     solve(state, attr, isMeasuring = false) {
//         // Barrier Check
//         if (state.node.type.includes('Barrier')) {
//             this.solveBarrier(state, attr);
//             return;
//         }

//         let top = null, bottom = null;

//         const topToTop = this.helper.getAttr(attr, 'layout_constraintTop_toTopOf');
//         const topToBottom = this.helper.getAttr(attr, 'layout_constraintTop_toBottomOf');
//         const bottomToBottom = this.helper.getAttr(attr, 'layout_constraintBottom_toBottomOf');
//         const bottomToTop = this.helper.getAttr(attr, 'layout_constraintBottom_toTopOf');
//         const baselineToBaseline = this.helper.getAttr(attr, 'layout_constraintBaseline_toBaselineOf');

//         // 🔥 FIX: Baseline Logic (Must return early if solved)
//         if (baselineToBaseline) {
//             const targetId = baselineToBaseline.replace(/@\+?id\//, '');
//             const targetState = this.solver.nodeMap.get(targetId);

//             if (targetState && targetState.solvedY) {
//                 const targetBaselineOffset = targetState.baseline !== undefined ? targetState.baseline : 0;
//                 const targetBaselineY = targetState.y + targetBaselineOffset;
//                 const myBaselineOffset = state.baseline || 0;
                
//                 state.y = targetBaselineY - myBaselineOffset;
//                 state.solvedY = true;
//                 return; // 🚀 Exit
//             }
//         }

//         // Check for Dimension Ratio
//         const hasRatio = this.helper.getAttr(attr, 'layout_constraintDimensionRatio');

//         const topTarget = (topToTop || topToBottom || '').replace(/@\+?id\//, '');
//         const bottomTarget = (bottomToBottom || bottomToTop || '').replace(/@\+?id\//, '');

//         if (isMeasuring) {
//             const dependsOnParentH =
//                 bottomTarget === 'parent' ||
//                 (topTarget === 'parent' && bottomTarget === 'parent') ||
//                 this.helper.getAttr(attr, 'layout_height') === 'match_parent';
            
//             if (dependsOnParentH) return; 
//         }

//         // Top Constraint
//         if (topToTop) {
//             if (topToTop === 'parent') top = this.solver.padding.top;
//             else {
//                 const t = this.solver.nodeMap.get(topTarget);
//                 if (t && t.solvedY) top = t.y;
//             }
//         } else if (topToBottom) {
//             const t = this.solver.nodeMap.get(topTarget);
//             if (t && t.solvedY) top = t.y + t.h;
//         }

//         // Bottom Constraint
//         if (bottomToBottom) {
//             if (bottomToBottom === 'parent') bottom = this.solver.parentH - this.solver.padding.bottom;
//             else {
//                 const t = this.solver.nodeMap.get(bottomTarget);
//                 if (t && t.solvedY) bottom = t.y + t.h;
//             }
//         } else if (bottomToTop) {
//             const t = this.solver.nodeMap.get(bottomTarget);
//             if (t && t.solvedY) bottom = t.y;
//         }

//         const mt = this.helper.getMargin(attr, 'Top', topTarget) || 0;
//         const mb = this.helper.getMargin(attr, 'Bottom', bottomTarget) || 0;

//         // Positioning Logic (Standard)
//         // 🔥 FIX: Handle Centering even with heightPercent
//         if (top !== null && bottom !== null) {
//             const bias = parseFloat(this.helper.getAttr(attr, 'layout_constraintVertical_bias') || '0.5');
//             // bias সূত্র ব্যবহার করে পজিশন সেট হবে (সেন্টার হবে)
//             const availableSpace = (bottom - top) - state.h - mt - mb;
//             state.y = top + mt + (availableSpace * bias);
//             state.solvedY = true;
//         } else if (top !== null) {
//             state.y = top + mt;
//             state.solvedY = true;
//         } else if (bottom !== null) {
//             state.y = bottom - state.h - mb;
//             state.solvedY = true;
//         } else {
//             // No constraints -> Top Left (0,0) + Padding
//             if (!state.solvedY) {
//                 state.y = this.solver.padding.top + mt;
//                 state.solvedY = true;
//             }
//         }
//     }

//     solveBarrier(state, attr) {
//         const direction = this.helper.getAttr(attr, 'barrierDirection');
//         const referencedIds = this.helper.getAttr(attr, 'constraint_referenced_ids');
//         if (!referencedIds) return;
        
//         if (['top', 'bottom'].includes(direction)) {
//             const ids = referencedIds.split(',').map(id => id.trim());
//             let maxVal = -Infinity;
//             let minVal = Infinity;
//             let hasTarget = false;
            
//             ids.forEach(refId => {
//                 const refState = this.solver.nodeMap.get(refId);
//                 if (refState && refState.solvedY) {
//                     hasTarget = true;
//                     if (direction === 'bottom') {
//                         const bottomEdge = refState.y + refState.h;
//                         if (bottomEdge > maxVal) maxVal = bottomEdge;
//                     } else {
//                         if (refState.y < minVal) minVal = refState.y;
//                     }
//                 }
//             });

//             if (hasTarget) {
//                 state.y = (direction === 'bottom') ? maxVal : minVal;
//                 state.h = 0;
//                 state.solvedY = true;
//             }
//         }
//     }
// }


export class VerticalSolver {
    constructor(solver) {
        this.solver = solver;
        this.helper = solver.helper;
    }

    solve(state, attr, isMeasuring = false) {
        if (state.node.type.includes('Barrier')) {
            this.solveBarrier(state, attr);
            return;
        }

        let top = null, bottom = null;

        const topToTop = this.helper.getAttr(attr, 'layout_constraintTop_toTopOf');
        const topToBottom = this.helper.getAttr(attr, 'layout_constraintTop_toBottomOf');
        const bottomToBottom = this.helper.getAttr(attr, 'layout_constraintBottom_toBottomOf');
        const bottomToTop = this.helper.getAttr(attr, 'layout_constraintBottom_toTopOf');
        const baselineToBaseline = this.helper.getAttr(attr, 'layout_constraintBaseline_toBaselineOf');

        // Baseline Logic
        if (baselineToBaseline) {
            const targetId = baselineToBaseline.replace(/@\+?id\//, '');
            const targetState = this.solver.nodeMap.get(targetId);

            if (targetState && targetState.solvedY) {
                const targetBaselineOffset = targetState.baseline !== undefined ? targetState.baseline : 0;
                const targetBaselineY = targetState.y + targetBaselineOffset;
                const myBaselineOffset = state.baseline || 0;
                
                state.y = targetBaselineY - myBaselineOffset;
                state.solvedY = true;
                return; 
            }
        }

        const topTarget = (topToTop || topToBottom || '').replace(/@\+?id\//, '');
        const bottomTarget = (bottomToBottom || bottomToTop || '').replace(/@\+?id\//, '');
        const hasRatio = this.helper.getAttr(attr, 'layout_constraintDimensionRatio');

        if (isMeasuring) {
            const dependsOnParentH =
                bottomTarget === 'parent' ||
                (topTarget === 'parent' && bottomTarget === 'parent') ||
                this.helper.getAttr(attr, 'layout_height') === 'match_parent';
            
            if (dependsOnParentH) return; 
        }

        // Determine Top Anchor
        if (topToTop) {
            if (topToTop === 'parent') top = this.solver.padding.top;
            else {
                const t = this.solver.nodeMap.get(topTarget);
                if (t && t.solvedY) top = t.y;
            }
        } else if (topToBottom) {
            const t = this.solver.nodeMap.get(topTarget);
            if (t && t.solvedY) top = t.y + t.h;
        }

        // Determine Bottom Anchor
        if (bottomToBottom) {
            if (bottomToBottom === 'parent') bottom = this.solver.parentH - this.solver.padding.bottom;
            else {
                const t = this.solver.nodeMap.get(bottomTarget);
                if (t && t.solvedY) bottom = t.y + t.h;
            }
        } else if (bottomToTop) {
            const t = this.solver.nodeMap.get(bottomTarget);
            if (t && t.solvedY) bottom = t.y;
        }

        const mt = this.helper.getMargin(attr, 'Top', topTarget) || 0;
        const mb = this.helper.getMargin(attr, 'Bottom', bottomTarget) || 0;
        const hAttr = this.helper.getAttr(attr, 'layout_height');

        // 🔥 FIX 1: 0dp (match_constraint) and match_parent Height Logic
        if (hAttr === '0dp' || hAttr === 'match_constraint') {
            if (!hasRatio && top !== null && bottom !== null) {
                state.h = Math.max(0, bottom - top - mt - mb);
            }
        } else if (hAttr === 'match_parent') {
            state.h = this.solver.parentH - (this.solver.padding.top + this.solver.padding.bottom + mt + mb);
        }

        // 🔥 FIX 2: Positioning and Vertical Bias Logic
        if (top !== null && bottom !== null) {
            const bias = parseFloat(this.helper.getAttr(attr, 'layout_constraintVertical_bias') || '0.5');
            const availableSpace = (bottom - top) - state.h - mt - mb;
            state.y = top + mt + (availableSpace * bias);
            state.solvedY = true;
        } else if (top !== null) {
            state.y = top + mt;
            state.solvedY = true;
        } else if (bottom !== null) {
            state.y = bottom - state.h - mb;
            state.solvedY = true;
        } else {
            if (!state.solvedY) {
                state.y = this.solver.padding.top + mt;
                state.solvedY = true;
            }
        }
    }

    solveBarrier(state, attr) {
        const direction = this.helper.getAttr(attr, 'barrierDirection');
        const referencedIds = this.helper.getAttr(attr, 'constraint_referenced_ids');
        if (!referencedIds) return;
        
        if (['top', 'bottom'].includes(direction)) {
            const ids = referencedIds.split(',').map(id => id.trim());
            let maxVal = -Infinity;
            let minVal = Infinity;
            let hasTarget = false;
            
            ids.forEach(refId => {
                const refState = this.solver.nodeMap.get(refId);
                if (refState && refState.solvedY) {
                    hasTarget = true;
                    if (direction === 'bottom') {
                        const bottomEdge = refState.y + refState.h;
                        if (bottomEdge > maxVal) maxVal = bottomEdge;
                    } else {
                        if (refState.y < minVal) minVal = refState.y;
                    }
                }
            });

            if (hasTarget) {
                state.y = (direction === 'bottom') ? maxVal : minVal;
                state.h = 0;
                state.solvedY = true;
            }
        }
    }
}