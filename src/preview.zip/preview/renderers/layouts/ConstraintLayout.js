import { BaseView } from '../widgets/BaseView.js';
import { ConstraintSolver } from '../../solvers/ConstraintSolver.js';

export class ConstraintLayout extends BaseView {
    constructor(resolver) {
        super(resolver);
        this.solver = new ConstraintSolver(resolver);
    }

    render(node, renderChildCallback, parentType) {
        return this.renderWithBounds(node, 360, 640, renderChildCallback, parentType);
    }

    async renderWithBounds(node, width, height, renderChildCallback, parentType) {
        const attr = node.attributes;
        
        let baseStyle = await this.getBaseStyles(attr, parentType || 'ViewGroup'); 
        
        // Remove layout styles handled by solver
        baseStyle = baseStyle
            .replace(/padding[^;]+;/g, '')
            .replace(/border-width[^;]+;/g, '')
            .replace(/border-style[^;]+;/g, '')
            .replace(/border-color[^;]+;/g, '')
            .replace(/margin[^;]+;/g, '')
            .replace(/height:[^;]+;/g, '')
            .replace(/width:[^;]+;/g, ''); 

        const w = width || (typeof window !== 'undefined' ? window.innerWidth : 360);
        const h = height || (typeof window !== 'undefined' ? window.innerHeight : 640);

        // Detect wrap_content
        const getAttr = (name) => attr[name] || attr[`android:${name}`] || attr[`app:${name}`];
        const hAttr = getAttr('layout_height');
        const isWrapContentH = hAttr === 'wrap_content';

        const p = getAttr('padding');
        const pl = this.parsePx(getAttr('paddingLeft') || getAttr('paddingStart') || p);
        const pt = this.parsePx(getAttr('paddingTop') || p);
        const pr = this.parsePx(getAttr('paddingRight') || getAttr('paddingEnd') || p);
        const pb = this.parsePx(getAttr('paddingBottom') || p);
        
        const padding = { left: pl, top: pt, right: pr, bottom: pb };

        // Generate Auto IDs
        node.children.forEach((child, index) => {
            const hasId = child.attributes.id || child.attributes['android:id'];
            if (!hasId) {
                child.attributes.id = `__auto_id_const_${index}_${Date.now()}`;
            }
        });

        // 🏗️ STEP 1: Pre-calculate Layer Transforms & Group Visibility
        const layerTransforms = new Map(); // id -> css transform string
        const hiddenGroupIds = new Set();  // ids that should be hidden

        node.children.forEach(child => {
            const type = child.type.split('.').pop();
            const childAttr = child.attributes;
            const refIdsRaw = childAttr['app:constraint_referenced_ids'] || childAttr['constraint_referenced_ids'];

            if (!refIdsRaw) return;
            const refIds = refIdsRaw.split(',').map(id => id.trim());

            // Handle Layer Logic
            if (type === 'Layer') {
                const getVal = (name) => childAttr[name] || childAttr[`android:${name}`] || '0';
                const rot = parseFloat(getVal('rotation'));
                const scX = parseFloat(childAttr['android:scaleX'] || childAttr['scaleX'] || '1');
                const scY = parseFloat(childAttr['android:scaleY'] || childAttr['scaleY'] || '1');
                const trX = parseFloat(getVal('translationX'));
                const trY = parseFloat(getVal('translationY'));

                let transform = '';
                if (rot !== 0) transform += `rotate(${rot}deg) `;
                if (scX !== 1 || scY !== 1) transform += `scale(${scX}, ${scY}) `;
                if (trX !== 0 || trY !== 0) transform += `translate(${trX}px, ${trY}px) `;

                if (transform) {
                    refIds.forEach(id => {
                        const prev = layerTransforms.get(id) || '';
                        layerTransforms.set(id, prev + transform);
                    });
                }
            }

            // Handle Group Visibility Logic
            if (type === 'Group') {
                const visibility = childAttr['android:visibility'] || childAttr['visibility'];
                if (visibility === 'gone' || visibility === 'invisible') {
                    refIds.forEach(id => hiddenGroupIds.add(id));
                }
            }
        });
        
        // R t L
        // const isRtl = attr['android:layoutDirection'] === 'rtl' || attr['layoutDirection'] === 'rtl';
        // console.log('isRtl ::::',isRtl);
        // this.solver.isRTL = isRtl;
        
        const direction = attr['android:layoutDirection'] || attr['layoutDirection'];
        this.solver.isRTL = (direction === 'rtl'); 
        
        // Debug Log (Confirm RTL is detected)
        console.log('RTL Check:', direction, '->', this.solver.isRTL);
        
        
        

        // Run Solver
        const solvedStyles = this.solver.solve(node.children, w, h, padding, false, isWrapContentH);

        // Placeholder Logic (Post-Solve Swap)
        // সলভার ক্যালকুলেশন শেষ করার পর আমরা পজিশন সোয়াপ করব
        node.children.forEach(child => {
            const type = child.type.split('.').pop();
            
            if (type === 'Placeholder') {
                const phId = child.attributes.id?.replace(/@\+?id\//, '');
                const targetIdRaw = child.attributes['app:content'] || child.attributes['content'];
                
                if (phId && targetIdRaw) {
                    const targetId = targetIdRaw.replace(/@\+?id\//, '');
                    
                    // সলভারের রেজাল্ট ম্যাপ থেকে ডেটা নেওয়া
                    const phSolution = solvedStyles.get(phId);
                    const targetSolution = solvedStyles.get(targetId);

                    if (phSolution && targetSolution) {
                        // 🚀 Magic: Placeholder এর পজিশন এবং সাইজ টার্গেটকে দিয়ে দেওয়া
                        targetSolution.x = phSolution.x;
                        targetSolution.y = phSolution.y;
                        targetSolution.width = phSolution.width;
                        targetSolution.height = phSolution.height;
                        
                        // CSS আপডেট করা যাতে নতুন পজিশন রিফ্লেক্ট করে
                        targetSolution.css = `
                            position: absolute !important;
                            left: ${phSolution.x}px !important;
                            top: ${phSolution.y}px !important;
                            width: ${phSolution.width}px !important;
                            height: ${phSolution.height}px !important;
                            margin: 0 !important;
                            display: flex;
                        `;
                        
                        // Placeholder কে সরিয়ে ফেলা (হাইড করা)
                        phSolution.width = 0;
                        phSolution.height = 0;
                        phSolution.css += 'display: none !important;';
                    }
                }
            }
        });

        // Expose solver for Blueprint
        if (typeof window !== 'undefined') {
            window.__latestConstraintSolver = this.solver;
        }

        // Calculate Height
        let cssHeight = hAttr === 'match_parent' ? '100%' : `${h}px`;
        if (isWrapContentH) {
            cssHeight = `${this.solver.parentH}px !important`;
        }

        const layoutStyle = `
            position: relative;
            overflow: hidden; 
            width: 100%;
            height: ${cssHeight};
            display: block; 
        `;

        // 🏗️ STEP 2: Render Children with Injected Styles
        const childrenHtmlArray = await Promise.all(node.children.map(async child => {
            const type = child.type.split('.').pop();
            const rawId = child.attributes.id || child.attributes['android:id'];
            const id = rawId?.replace(/@\+?id\//, '');
            
            const solution = id ? solvedStyles.get(id) : null;

            // Handle Guidelines (Invisible but present for Blueprint)
            if (type === 'Guideline') {
                if (!solution) return '';
                return `<div id="${id}" style="position:absolute; left:${solution.x}px; top:${solution.y}px; width:0; height:0; display:none;"></div>`;
            }

            let absStyle = 'position:absolute; left:0; top:0;';
            let childW = w, childH = h;

            if (solution) {
                absStyle = solution.css;
                childW = solution.width;
                childH = solution.height;
            }

            let html = await renderChildCallback(child, 'ConstraintLayout', childW, childH); 
            
            // 🏗️ STEP 3: Inject Transform & Visibility (Layer & Group support)
            const transformCss = id ? layerTransforms.get(id) : null;
            const shouldHide = id && hiddenGroupIds.has(id);

            return html.replace(/style="([^"]*)"/, (match, existingStyle) => {
                // BaseView এর স্টাইল (width/height/margin) রিমুভ করা
                // যাতে সলভারের স্টাইল (absStyle) একমাত্র সত্য হয়।
                const cleanedStyle = existingStyle
                    .replace(/margin[^;]+;/g, '')
                    .replace(/width[^;]+;/g, '')
                    .replace(/height[^;]+;/g, '');
                
                let extraStyle = '';
                // Apply Layer Transform
                if (transformCss) {
                    extraStyle += `transform: ${transformCss}; transform-origin: center center; `;
                }
                // Apply Group Visibility
                if (shouldHide) {
                    extraStyle += `display: none !important; `;
                }

                return `style="${absStyle} ${cleanedStyle} ${extraStyle}"`;
            });
        }));

        return `
            <div class="android-layout constraint-layout" id="${node.attributes.id?.replace(/@\+?id\//, '') || ''}" style="${baseStyle} ${layoutStyle}">
                ${childrenHtmlArray.join('')}
            </div>
        `;
    }

    parsePx(val) {
        if (!val) return 0;
        if (val === 'match_parent' || val === 'wrap_content') return 0;
        return parseFloat(this.converter.parse(val));
    }
}