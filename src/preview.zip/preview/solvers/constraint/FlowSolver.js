export class FlowSolver {
    constructor(solver) {
        this.solver = solver;
        this.helper = solver.helper;
    }

    solve(children) {
        // ১. সব ফ্লো উইজেট খুঁজে বের করা
        children.forEach(node => {
            if (!node.type.includes('Flow')) return;

            const flowId = this.helper.getId(node);
            const flowState = this.solver.nodeMap.get(flowId);
            if (!flowState) return;

            const attr = node.attributes;
            const refIdsRaw = this.helper.getAttr(attr, 'constraint_referenced_ids');
            if (!refIdsRaw) return;

            const refIds = refIdsRaw.split(',').map(id => id.trim());
            const views = refIds.map(id => this.solver.nodeMap.get(id)).filter(v => v);

            if (views.length === 0) return;

            // ২. কনফিগারেশন রিড করা
            const wrapMode = this.helper.getAttr(attr, 'flow_wrapMode') || 'none';
            const hGap = this.helper.parsePx(this.helper.getAttr(attr, 'flow_horizontalGap'));
            const vGap = this.helper.parsePx(this.helper.getAttr(attr, 'flow_verticalGap'));
            const maxElementsWrap = parseInt(this.helper.getAttr(attr, 'flow_maxElementsWrap') || '0');

            // Flow এর পজিশন (Constraints অনুযায়ী)
            // আমরা ধরে নিচ্ছি Flow এর নিজস্ব Constraints (Top/Left) সলভ করা আছে বা হবে
            // আপাতত প্যারেন্ট প্যাডিং দিয়ে শুরু করছি
            let startX = this.solver.getPos(this.helper.getAttr(attr, 'layout_constraintStart_toStartOf'), 'left');
            if (startX === 0) startX = this.solver.padding.left;
            
            let startY = this.solver.getPos(this.helper.getAttr(attr, 'layout_constraintTop_toTopOf'), 'top');
            if (startY === 0) startY = this.solver.padding.top;

            // Flow Width Limit (Parent Width - Padding)
            const limitW = this.solver.parentW - this.solver.padding.right;

            // ৩. লজিক (Wrap / Chain / Aligned)
            let currentX = startX;
            let currentY = startY;
            let rowMaxH = 0;
            let flowMaxW = 0;
            
            // "aligned" mode এর জন্য গ্রিড লজিক দরকার, তবে "chain" বা "none" এর জন্য সাধারণ র‍্যাপিং যথেষ্ট
            // এখানে আমরা বেসিক র‍্যাপিং লজিক দিচ্ছি যা অধিকাংশ ক্ষেত্রে কাজ করবে
            
            views.forEach((view, index) => {
                // ভিউ এর পজিশন সেট করা
                if (wrapMode !== 'none') {
                    // যদি র‍্যাপিং দরকার হয়
                    if (currentX + view.w > limitW) {
                        currentX = startX;
                        currentY += rowMaxH + vGap;
                        rowMaxH = 0;
                    }
                }

                view.x = currentX;
                view.y = currentY;
                
                // মার্ক করা যাতে অন্য সলভার একে ওভাররাইট না করে
                view.solvedX = true;
                view.solvedY = true;

                // নেক্সট পজিশন ক্যালকুলেশন
                currentX += view.w + hGap;
                rowMaxH = Math.max(rowMaxH, view.h);
                
                // Flow এর নিজের সাইজ আপডেট রাখার জন্য
                flowMaxW = Math.max(flowMaxW, currentX - startX);
            });

            // ৪. Flow Widget এর নিজের সাইজ আপডেট করা (যাতে অন্য ভিউ এর সাথে রিলেশন ঠিক থাকে)
            flowState.w = flowMaxW;
            flowState.h = (currentY + rowMaxH) - startY;
            flowState.x = startX;
            flowState.y = startY;
            
            this.solver.logger.log('solve', `Flow: ${flowId} arranged ${views.length} views`);
        });
    }
}