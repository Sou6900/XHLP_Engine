const fs = acode.require('fs');

export class ProjectContext {
    constructor() {
        this.projectRoot = null;
        this.resPath = null;
        this.packageName = "";
        this.isDark = false; 
    }

    async initialize(activeFileUri) {
        console.log("🧠 [Context] Initializing...");
        this.projectRoot = await this._findProjectRoot(activeFileUri);
        
        if (this.projectRoot) {
            const candidates = [
                `${this.projectRoot}/app/src/main/res`,
                `${this.projectRoot}/src/main/res`,
                `${this.projectRoot}/res`
            ];

            for (const path of candidates) {
                const prefix = this.projectRoot.startsWith('/') ? 'file://' : '';
                const fullPath = `${prefix}${path}`;
                
                if (await fs(fullPath).exists().catch(() => false)) {
                    this.resPath = fullPath;
                    console.log(`📂 [Context] Resources found at: ${this.resPath}`);
                    break;
                }
            }
        } else {
            console.warn("⚠️ [Context] Could not determine project root");
        }
    }

    async _findProjectRoot(uri) {
        if (!uri) return null;
        
        // 🔥 FIX: Better path normalization logic
        let path = uri;
        
        // Convert Content URI to File Path (Acode specific hack)
        if (path.includes('primary:')) {
            const decoded = decodeURIComponent(path);
            const parts = decoded.split('primary:');
            if (parts.length > 1) {
                // Take the last part as the relative path
                const relativePath = parts.pop();
                // Map to standard Android storage path
                path = `/storage/emulated/0/${relativePath}`;
            }
        } else if (path.startsWith('file://')) {
            path = path.replace('file://', '');
        }

        let index = path.indexOf('/src/main');
        if (index === -1) index = path.indexOf('/res/layout');
        
        if (index > -1) {
            const appIndex = path.indexOf('/app/src/main');
            if (appIndex > -1) {
                return path.substring(0, appIndex); 
            }
            return path.substring(0, index); 
        }

        return null;
    }

    getResourcePath() {
        return this.resPath;
    }

    /**
     * Reads a drawable (XML or Bitmap)
     */
    async getDrawable(name) {
        if (!this.resPath) return null;

        const extensions = ['xml', 'png', 'jpg', 'jpeg', 'webp'];
        const dirs = [
            'drawable', 
            'drawable-nodpi', 
            'drawable-xxhdpi', 
            'drawable-xhdpi', 
            'drawable-hdpi', 
            'drawable-mdpi', 
            'drawable-v24'
        ];

        for (const dir of dirs) {
            for (const ext of extensions) {
                let path = `${this.resPath}/${dir}/${name}.${ext}`;
                let file = fs(path);
                
                // Existence check
                let exists = await file.exists().catch(() => false);
                if (!exists) {
                    path = `${this.resPath}/${dir}/${name}.${ext.toUpperCase()}`;
                    file = fs(path);
                    exists = await file.exists().catch(() => false);
                }

                if (exists) {
                    try {
                        if (ext === 'xml') {
                            return { type: 'xml', content: await file.readFile('utf-8') };
                        } else {
                            console.log(`🔍 [Context] Found Bitmap: ${name}.${ext}`);
                            
                            // 🛠️ Strategy 1: Convert Content URI to File Path for toInternalUrl
                            // content://...primary:Aide/app... -> file:///sdcard/Aide/app...
                            let cleanPath = path;
                            if (path.includes('primary:')) {
                                const decoded = decodeURIComponent(path);
                                const parts = decoded.split('primary:');
                                const relPath = parts.pop(); 
                                // Ensure no double slashes
                                const safeRel = relPath.startsWith('/') ? relPath.substring(1) : relPath;
                                cleanPath = `file:///storage/emulated/0/${safeRel}`;
                                console.log(`   🛠️ Normalized Path: ${cleanPath}`);
                            }

                            // 🔥 Attempt 1: toInternalUrl with Normalized Path
                            try {
                                const toInternalUrl = acode.require('toInternalUrl');
                                if (toInternalUrl) {
                                    const url = await toInternalUrl(cleanPath); 
                                    console.log(`   ✅ Generated Internal URL: ${url}`);
                                    return { type: 'bitmap', content: url };
                                }
                            } catch (e) {
                                console.warn(`   ⚠️ toInternalUrl failed (Code: ${e.code || e.message})`);
                            }

                            // 🔥 Attempt 2: fs.readFile('dataurl')
                            // This is safer than arraybuffer because conversion happens in Java layer
                            try {
                                // Re-init file object with potentially cleaner path if needed, 
                                // but usually original 'file' object is tied to the fs backend.
                                // We try reading the original content uri first.
                                const dataUrl = await file.readFile('dataurl');
                                if (dataUrl && dataUrl.startsWith('data:')) {
                                    console.log(`   ✅ Read Data URL (${dataUrl.length} chars)`);
                                    return { type: 'bitmap', content: dataUrl };
                                }
                            } catch(e) {
                                console.warn(`   ⚠️ 'dataurl' read failed: ${e.message}`);
                            }

                            // 🔥 Attempt 3: Manual Binary Fix (Last Resort)
                            // Only if above failed. We construct Blob manually.
                            try {
                                const buffer = await file.readFile('arraybuffer');
                                
                                // Determine MIME
                                let mimeType = 'image/png';
                                if (ext.toLowerCase().includes('jpg')) mimeType = 'image/jpeg';
                                else if (ext.toLowerCase().includes('webp')) mimeType = 'image/webp';

                                // Convert corrupted string to Uint8Array if necessary
                                let finalBuffer;
                                if (typeof buffer === 'string') {
                                    const len = buffer.length;
                                    const bytes = new Uint8Array(len);
                                    for (let i = 0; i < len; i++) {
                                        bytes[i] = buffer.charCodeAt(i) & 0xFF; // Mask to byte
                                    }
                                    finalBuffer = bytes;
                                } else {
                                    finalBuffer = buffer;
                                }

                                const blob = new Blob([finalBuffer], { type: mimeType });
                                const blobUrl = URL.createObjectURL(blob);
                                console.log(`   ✅ Generated Blob URL: ${blobUrl}`);
                                return { type: 'bitmap', content: blobUrl };

                            } catch(e) {
                                console.error(`   ❌ All strategies failed for ${name}`);
                            }
                        }
                    } catch (e) {
                        console.error(`❌ [Context] Error processing ${name}:`, e);
                    }
                }
            }
        }
        
        console.warn(`⚠️ [Context] Drawable not found: ${name}`);
        return null;
    }

    async getLayout(name) {
        if (!this.resPath) return null;
        const path = `${this.resPath}/layout/${name}.xml`;
        try {
            if (await fs(path).exists()) {
                return await fs(path).readFile('utf-8');
            }
        } catch (e) {
            console.warn(`⚠️ [Context] Layout not found: ${name}`);
        }
        return null;
    }
    
    setDarkMode(enabled) { this.isDark = enabled; }
    isDarkMode() { return this.isDark; }
}