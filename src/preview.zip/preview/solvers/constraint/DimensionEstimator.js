// import { TextMeasurer } from '../../text/TextMeasurer.js';

// export class DimensionEstimator {
//     constructor(solver) {
//         this.solver = solver;
//         this.helper = solver.helper;
//         this.measurer = new TextMeasurer();
//     }

//     estimateAll(children) {
//         children.forEach(node => {
//             const id = this.helper.getId(node);
//             const state = this.solver.nodeMap.get(id);
//             if (!state || state.isGuideline) return;

//             state.w = this.estimateWidth(node);
//             state.h = this.estimateHeight(node, 0); 
            
//             this.solver.logger.log('solve', `View: ${id} - Estimate: ${state.w}x${state.h}`);
//         });
//     }

//     estimateWidth(node) {
//         const type = node.type.split('.').pop();
        
//         // 🔥 Group, Barrier, Guideline - No physical size
//         if (type === 'Group' || type === 'Barrier' || type === 'Guideline' || type === 'Layer' ) {
//             return 0;
//         }

//         const attr = node.attributes;
//         if (this.helper.getAttr(attr, 'visibility') === 'gone') return 0;

//         const w = this.helper.getAttr(attr, 'layout_width');
//         if (w === '0dp' || w === 'match_parent') return 50; 
//         if (w && w !== 'wrap_content' && w !== '0dp' && w !== 'match_parent') return this.helper.parsePx(w);

//         // Container Logic (Layouts) - Preserved from original
//         if (['LinearLayout', 'ConstraintLayout', 'RelativeLayout', 'FrameLayout', 'CardView', 'ViewGroup', 'HorizontalScrollView', 'ScrollView', 'GridLayout'].includes(type)) {
//             if (node.children) {
//                 let totalW = 0;
//                 let maxW = 0;
//                 const isVertical = (this.helper.getAttr(attr, 'orientation') || 'horizontal') === 'vertical';
//                 const isStack = type === 'LinearLayout' && !isVertical;

//                 node.children.forEach(child => {
//                     if (child !== node) {
//                         const childW = this.estimateWidth(child);
//                         const ml = this.helper.parsePx(this.helper.getAttr(child.attributes, 'layout_marginStart'));
//                         const mr = this.helper.parsePx(this.helper.getAttr(child.attributes, 'layout_marginEnd'));
//                         const actualChildW = childW + ml + mr;
//                         if (isStack) totalW += actualChildW;
//                         else maxW = Math.max(maxW, actualChildW);
//                     }
//                 });

//                 const p = this.helper.parsePx(this.helper.getAttr(attr, 'padding'));
//                 const pH = this.helper.parsePx(this.helper.getAttr(attr, 'paddingHorizontal'));
//                 const cp = this.helper.parsePx(this.helper.getAttr(attr, 'contentPadding'));
//                 const pl = this.helper.parsePx(this.helper.getAttr(attr, 'paddingLeft') || this.helper.getAttr(attr, 'paddingStart')) || pH || cp || p;
//                 const pr = this.helper.parsePx(this.helper.getAttr(attr, 'paddingRight') || this.helper.getAttr(attr, 'paddingEnd')) || pH || cp || p;

//                 const contentW = (isStack || type === 'GridLayout') ? totalW : maxW;
//                 if (type === 'GridLayout') {
//                     const colCount = parseInt(this.helper.getAttr(attr, 'columnCount') || '1');
//                     return Math.max(10, (maxW * colCount) + pl + pr);
//                 }
//                 return Math.max(10, contentW + pl + pr);
//             }
//             return 100;
//         }

//         if (type === 'ProgressBar') return 50;

//         // 🔥 UPDATED: Text, Button, Switch & CheckBox Logic
//         if (type === 'TextView' || type.includes('Button') || type.includes('Switch') || type.includes('CheckBox') || type.includes('RadioButton')) {
//             let text = this._resolveText(node);
//             const isButton = type.includes('Button');

//             if (isButton || this.helper.getAttr(attr, 'textAllCaps') === 'true') {
//                 text = text ? text.toUpperCase() : '';
//             }

//             const result = this.measurer.measure(text, attr, this.solver.parentW);
//             let measuredW = result.width;

//             if (isButton) {
//                 // Button: Text width + generous padding + caps handling
//                 measuredW = (measuredW * 1.45) + 40;
//             } 
//             else if (type.includes('Switch') || type.includes('CheckBox') || type.includes('RadioButton')) {
//                 // Compound Buttons: Text Width + Toggle/Box (approx 34-40px) + Padding
//                 // We add 60px buffer to account for the graphic + gap
//                 measuredW = Math.ceil(measuredW * 1.1) + 60;
//             } 
//             else {
//                 // Standard TextView: Scale slightly for font rendering diffs + buffer
//                 measuredW = (measuredW * 1.35) + 4;
//             }

//             // Add explicit XML padding
//             const p = this.helper.parsePx(this.helper.getAttr(attr, 'padding')) || 0;
//             const ph = this.helper.parsePx(this.helper.getAttr(attr, 'paddingHorizontal')) || 0;
//             const pl = this.helper.parsePx(this.helper.getAttr(attr, 'paddingLeft') || this.helper.getAttr(attr, 'paddingStart')) || 0;
//             const pr = this.helper.parsePx(this.helper.getAttr(attr, 'paddingRight') || this.helper.getAttr(attr, 'paddingEnd')) || 0;
            
//             measuredW += (p * 2) + (ph * 2) + pl + pr;

//             return Math.min(Math.max(0, Math.ceil(measuredW)), this.solver.parentW);
//         }
//         return 100;
//     }

//     estimateHeight(node, calculatedWidth) {
//         const type = node.type.split('.').pop();
        
//         // Group, Barrier, Guideline - No size
//         if (type === 'Group' || type === 'Barrier' || type === 'Guideline' || type === 'Layer') {
//             return 0;
//         }

//         const attr = node.attributes;
//         if (this.helper.getAttr(attr, 'visibility') === 'gone') return 0;

//         const h = this.helper.getAttr(attr, 'layout_height');
//         if (h && h !== 'wrap_content' && h !== '0dp' && h !== 'match_parent') return this.helper.parsePx(h);

//         // 🔥 UPDATED: Switch/Compound Button Height
//         if (type.includes('Switch') || type.includes('CheckBox') || type.includes('RadioButton')) {
//             // Minimum touch target usually around 32-48dp
//             const minH = this.helper.parsePx(this.helper.getAttr(attr, 'minHeight')) || 0;
//             return Math.max(32, minH);
//         }

//         const isLayout = ['LinearLayout', 'ConstraintLayout', 'RelativeLayout', 'FrameLayout', 'CardView', 'ViewGroup', 'HorizontalScrollView', 'ScrollView', 'GridLayout'].includes(type);

//         if (node.children && isLayout) {
//             let totalH = 0;
//             let maxH = 0;
//             const isVertical = (this.helper.getAttr(attr, 'orientation') || 'horizontal') === 'vertical';
//             const isStack = type === 'LinearLayout' && isVertical;

//             const p = this.helper.parsePx(this.helper.getAttr(attr, 'padding'));
//             const pV = this.helper.parsePx(this.helper.getAttr(attr, 'paddingVertical'));
//             const cp = this.helper.parsePx(this.helper.getAttr(attr, 'contentPadding'));
//             const pt = this.helper.parsePx(this.helper.getAttr(attr, 'paddingTop')) || pV || cp || p;
//             const pb = this.helper.parsePx(this.helper.getAttr(attr, 'paddingBottom')) || pV || cp || p;

//             if (isVertical && type === 'LinearLayout') {
//                 node.children.forEach(child => {
//                     if (child !== node) {
//                         const childH = this.estimateHeight(child, calculatedWidth);
//                         const mt = this.helper.parsePx(this.helper.getAttr(child.attributes, 'layout_marginTop'));
//                         const mb = this.helper.parsePx(this.helper.getAttr(child.attributes, 'layout_marginBottom'));
//                         totalH += childH + mt + mb;
//                     }
//                 });
//                 return Math.max(20, totalH + pt + pb);
//             }

//             node.children.forEach(child => {
//                 if (child !== node) {
//                     const childH = this.estimateHeight(child, calculatedWidth);
//                     const mt = this.helper.parsePx(this.helper.getAttr(child.attributes, 'layout_marginTop'));
//                     const mb = this.helper.parsePx(this.helper.getAttr(child.attributes, 'layout_marginBottom'));
//                     const actualChildH = childH + mt + mb;
//                     if (isStack) totalH += actualChildH;
//                     else maxH = Math.max(maxH, actualChildH);
//                 }
//             });
//             const contentH = isStack ? totalH : maxH;
//             return Math.max(20, contentH + pt + pb);
//         }

//         if (type === 'ProgressBar') return 50;

//         if (type === 'TextView' || type.includes('Button')) {
//             const availableW = (calculatedWidth > 0) ? calculatedWidth : this.solver.parentW;
//             let text = this._resolveText(node);
//             if (type.includes('Button') || this.helper.getAttr(attr, 'textAllCaps') === 'true') {
//                 text = text ? text.toUpperCase() : '';
//             }

//             const result = this.measurer.measure(text, attr, availableW);
//             let measuredH = result.height;

//             if (type.includes('Button')) {
//                 const hasUserPadding = attr['android:padding'] || attr['padding'] ||
//                                     attr['android:paddingTop'] || attr['paddingTop'] ||
//                                     attr['android:paddingVertical'] || attr['paddingVertical'];

//                 if (!hasUserPadding) {
//                     measuredH += 12; 
//                 }
//                 measuredH += 8; 
//             }

//             const p = this.helper.parsePx(this.helper.getAttr(attr, 'padding'));
//             const pV = this.helper.parsePx(this.helper.getAttr(attr, 'paddingVertical'));
//             const pt = this.helper.parsePx(this.helper.getAttr(attr, 'paddingTop')) || pV || p;
//             const pb = this.helper.parsePx(this.helper.getAttr(attr, 'paddingBottom')) || pV || p;

//             return measuredH + pt + pb;
//         }
//         return 50;
//     }

//     _resolveText(node) {
//         const raw = this.helper.getAttr(node.attributes, 'text') || '';
//         return this.solver.resolver ? this.solver.resolver.resolveString(raw) : raw;
//     }
// }


// // // Baseline fix 
// import { TextMeasurer } from '../../text/TextMeasurer.js';

// export class DimensionEstimator {
//     constructor(solver) {
//         this.solver = solver;
//         this.helper = solver.helper;
//         this.measurer = new TextMeasurer();
//     }

//     estimateAll(children) {
//         children.forEach(node => {
//             const id = this.helper.getId(node);
//             const state = this.solver.nodeMap.get(id);
//             if (!state || state.isGuideline) return;

//             state.w = this.estimateWidth(node);
//             state.h = this.estimateHeight(node, 0); 
            
//             // 🔥 NEW: Calculate Baseline explicitly
//             state.baseline = this.estimateBaseline(node, state.h);

//             this.solver.logger.log('solve', `View: ${id} - Estimate: ${state.w}x${state.h} Baseline: ${state.baseline}`);
//         });
//     }

//     estimateBaseline(node, h) {
//         const type = node.type.split('.').pop();
        
//         // শুধু টেক্সট আছে এমন ভিউগুলোর জন্য বেইসলাইন হিসাব হবে
//         if (type === 'TextView' || type.includes('Button') || type.includes('EditText') || type.includes('RadioButton') || type.includes('CheckBox')) {
//             const attr = node.attributes;
//             const textSize = this.helper.parsePx(this.helper.getAttr(attr, 'textSize')) || 14;
            
//             // প্যাডিং বের করা
//             const p = this.helper.parsePx(this.helper.getAttr(attr, 'padding')) || 0;
//             const pV = this.helper.parsePx(this.helper.getAttr(attr, 'paddingVertical')) || 0;
//             const pt = this.helper.parsePx(this.helper.getAttr(attr, 'paddingTop')) || pV || p;

//             // গ্র্যাভিটি চেক (সেন্টার করা থাকলে বেইসলাইন নিচে নামবে)
//             const gravity = this.helper.getAttr(attr, 'gravity') || '';
//             const isButton = type.includes('Button');
//             const isCenterVertical = gravity.includes('center') || gravity.includes('center_vertical') || isButton;

//             if (isCenterVertical) {
//                 // যদি টেক্সট ভার্টিকালি সেন্টারে থাকে
//                 // Baseline ≈ Middle + half font height correction
//                 return (h / 2) + (textSize * 0.35);
//             } else {
//                 // ডিফল্ট টপ গ্র্যাভিটি (TextView)
//                 // Baseline ≈ PaddingTop + TextSize (Ascent)
//                 // Android এর স্ট্যান্ডার্ড Font Metrics অনুযায়ী এটি খুব কাছাকাছি হয়
//                 return pt + textSize * 0.9; 
//             }
//         }
        
//         // অন্য ভিউয়ের জন্য undefined রিটার্ন করি (VerticalSolver ডিফল্ট ব্যবহার করবে)
//         return undefined;
//     }

//     estimateWidth(node) {
//         const type = node.type.split('.').pop();
        
//         if (type === 'Group' || type === 'Barrier' || type === 'Guideline' || type === 'Layer' ) {
//             return 0;
//         }

//         const attr = node.attributes;
//         if (this.helper.getAttr(attr, 'visibility') === 'gone') return 0;

//         const w = this.helper.getAttr(attr, 'layout_width');
//         if (w === '0dp' || w === 'match_parent') return 50; 
//         if (w && w !== 'wrap_content' && w !== '0dp' && w !== 'match_parent') return this.helper.parsePx(w);

//         if (['LinearLayout', 'ConstraintLayout', 'RelativeLayout', 'FrameLayout', 'CardView', 'ViewGroup', 'HorizontalScrollView', 'ScrollView', 'GridLayout'].includes(type)) {
//             if (node.children) {
//                 let totalW = 0;
//                 let maxW = 0;
//                 const isVertical = (this.helper.getAttr(attr, 'orientation') || 'horizontal') === 'vertical';
//                 const isStack = type === 'LinearLayout' && !isVertical;

//                 node.children.forEach(child => {
//                     if (child !== node) {
//                         const childW = this.estimateWidth(child);
//                         const ml = this.helper.parsePx(this.helper.getAttr(child.attributes, 'layout_marginStart'));
//                         const mr = this.helper.parsePx(this.helper.getAttr(child.attributes, 'layout_marginEnd'));
//                         const actualChildW = childW + ml + mr;
//                         if (isStack) totalW += actualChildW;
//                         else maxW = Math.max(maxW, actualChildW);
//                     }
//                 });

//                 const p = this.helper.parsePx(this.helper.getAttr(attr, 'padding'));
//                 const pH = this.helper.parsePx(this.helper.getAttr(attr, 'paddingHorizontal'));
//                 const cp = this.helper.parsePx(this.helper.getAttr(attr, 'contentPadding'));
//                 const pl = this.helper.parsePx(this.helper.getAttr(attr, 'paddingLeft') || this.helper.getAttr(attr, 'paddingStart')) || pH || cp || p;
//                 const pr = this.helper.parsePx(this.helper.getAttr(attr, 'paddingRight') || this.helper.getAttr(attr, 'paddingEnd')) || pH || cp || p;

//                 const contentW = (isStack || type === 'GridLayout') ? totalW : maxW;
//                 if (type === 'GridLayout') {
//                     const colCount = parseInt(this.helper.getAttr(attr, 'columnCount') || '1');
//                     return Math.max(10, (maxW * colCount) + pl + pr);
//                 }
//                 return Math.max(10, contentW + pl + pr);
//             }
//             return 100;
//         }

//         if (type === 'ProgressBar') return 50;

//         if (type === 'TextView' || type.includes('Button') || type.includes('Switch') || type.includes('CheckBox') || type.includes('RadioButton')) {
//             let text = this._resolveText(node);
//             const isButton = type.includes('Button');

//             if (isButton || this.helper.getAttr(attr, 'textAllCaps') === 'true') {
//                 text = text ? text.toUpperCase() : '';
//             }

//             const result = this.measurer.measure(text, attr, this.solver.parentW);
//             let measuredW = result.width;

//             if (isButton) {
//                 measuredW = (measuredW * 1.45) + 40;
//             } 
//             else if (type.includes('Switch') || type.includes('CheckBox') || type.includes('RadioButton')) {
//                 measuredW = Math.ceil(measuredW * 1.1) + 60;
//             } 
//             else {
//                 measuredW = (measuredW * 1.35) + 4;
//             }

//             const p = this.helper.parsePx(this.helper.getAttr(attr, 'padding')) || 0;
//             const ph = this.helper.parsePx(this.helper.getAttr(attr, 'paddingHorizontal')) || 0;
//             const pl = this.helper.parsePx(this.helper.getAttr(attr, 'paddingLeft') || this.helper.getAttr(attr, 'paddingStart')) || 0;
//             const pr = this.helper.parsePx(this.helper.getAttr(attr, 'paddingRight') || this.helper.getAttr(attr, 'paddingEnd')) || 0;
            
//             measuredW += (p * 2) + (ph * 2) + pl + pr;

//             return Math.min(Math.max(0, Math.ceil(measuredW)), this.solver.parentW);
//         }
//         return 100;
//     }

//     estimateHeight(node, calculatedWidth) {
//         const type = node.type.split('.').pop();
        
//         if (type === 'Group' || type === 'Barrier' || type === 'Guideline' || type === 'Layer') {
//             return 0;
//         }

//         const attr = node.attributes;
//         if (this.helper.getAttr(attr, 'visibility') === 'gone') return 0;

//         const h = this.helper.getAttr(attr, 'layout_height');
//         if (h && h !== 'wrap_content' && h !== '0dp' && h !== 'match_parent') return this.helper.parsePx(h);

//         if (type.includes('Switch') || type.includes('CheckBox') || type.includes('RadioButton')) {
//             const minH = this.helper.parsePx(this.helper.getAttr(attr, 'minHeight')) || 0;
//             return Math.max(32, minH);
//         }

//         const isLayout = ['LinearLayout', 'ConstraintLayout', 'RelativeLayout', 'FrameLayout', 'CardView', 'ViewGroup', 'HorizontalScrollView', 'ScrollView', 'GridLayout'].includes(type);

//         if (node.children && isLayout) {
//             let totalH = 0;
//             let maxH = 0;
//             const isVertical = (this.helper.getAttr(attr, 'orientation') || 'horizontal') === 'vertical';
//             const isStack = type === 'LinearLayout' && isVertical;

//             const p = this.helper.parsePx(this.helper.getAttr(attr, 'padding'));
//             const pV = this.helper.parsePx(this.helper.getAttr(attr, 'paddingVertical'));
//             const cp = this.helper.parsePx(this.helper.getAttr(attr, 'contentPadding'));
//             const pt = this.helper.parsePx(this.helper.getAttr(attr, 'paddingTop')) || pV || cp || p;
//             const pb = this.helper.parsePx(this.helper.getAttr(attr, 'paddingBottom')) || pV || cp || p;

//             if (isVertical && type === 'LinearLayout') {
//                 node.children.forEach(child => {
//                     if (child !== node) {
//                         const childH = this.estimateHeight(child, calculatedWidth);
//                         const mt = this.helper.parsePx(this.helper.getAttr(child.attributes, 'layout_marginTop'));
//                         const mb = this.helper.parsePx(this.helper.getAttr(child.attributes, 'layout_marginBottom'));
//                         totalH += childH + mt + mb;
//                     }
//                 });
//                 return Math.max(20, totalH + pt + pb);
//             }

//             node.children.forEach(child => {
//                 if (child !== node) {
//                     const childH = this.estimateHeight(child, calculatedWidth);
//                     const mt = this.helper.parsePx(this.helper.getAttr(child.attributes, 'layout_marginTop'));
//                     const mb = this.helper.parsePx(this.helper.getAttr(child.attributes, 'layout_marginBottom'));
//                     const actualChildH = childH + mt + mb;
//                     if (isStack) totalH += actualChildH;
//                     else maxH = Math.max(maxH, actualChildH);
//                 }
//             });
//             const contentH = isStack ? totalH : maxH;
//             return Math.max(20, contentH + pt + pb);
//         }

//         if (type === 'ProgressBar') return 50;

//         if (type === 'TextView' || type.includes('Button')) {
//             const availableW = (calculatedWidth > 0) ? calculatedWidth : this.solver.parentW;
//             let text = this._resolveText(node);
//             if (type.includes('Button') || this.helper.getAttr(attr, 'textAllCaps') === 'true') {
//                 text = text ? text.toUpperCase() : '';
//             }

//             const result = this.measurer.measure(text, attr, availableW);
//             let measuredH = result.height;

//             if (type.includes('Button')) {
//                 const hasUserPadding = attr['android:padding'] || attr['padding'] ||
//                                     attr['android:paddingTop'] || attr['paddingTop'] ||
//                                     attr['android:paddingVertical'] || attr['paddingVertical'];

//                 if (!hasUserPadding) {
//                     measuredH += 12; 
//                 }
//                 measuredH += 8; 
//             }

//             const p = this.helper.parsePx(this.helper.getAttr(attr, 'padding'));
//             const pV = this.helper.parsePx(this.helper.getAttr(attr, 'paddingVertical'));
//             const pt = this.helper.parsePx(this.helper.getAttr(attr, 'paddingTop')) || pV || p;
//             const pb = this.helper.parsePx(this.helper.getAttr(attr, 'paddingBottom')) || pV || p;

//             return measuredH + pt + pb;
//         }
//         return 50;
//     }

//     _resolveText(node) {
//         const raw = this.helper.getAttr(node.attributes, 'text') || '';
//         return this.solver.resolver ? this.solver.resolver.resolveString(raw) : raw;
//     }
// }




// import { TextMeasurer } from '../../text/TextMeasurer.js';

// export class DimensionEstimator {
//     constructor(solver) {
//         this.solver = solver;
//         this.helper = solver.helper;
//         this.measurer = new TextMeasurer();
//     }

//     estimateAll(children) {
//         children.forEach(node => {
//             const id = this.helper.getId(node);
//             const state = this.solver.nodeMap.get(id);
//             if (!state || state.isGuideline) return;

//             state.w = this.estimateWidth(node);
//             state.h = this.estimateHeight(node, 0); 
            
//             // 🔥 NEW: Calculate Baseline explicitly
//             state.baseline = this.estimateBaseline(node, state.h);

//             this.solver.logger.log('solve', `View: ${id} - Estimate: ${state.w}x${state.h} Baseline: ${state.baseline}`);
//         });
//     }

//     estimateBaseline(node, h) {
//         const type = node.type.split('.').pop();
        
//         // শুধু টেক্সট আছে এমন ভিউগুলোর জন্য বেইসলাইন হিসাব হবে
//         if (type === 'TextView' || type.includes('Button') || type.includes('EditText') || type.includes('RadioButton') || type.includes('CheckBox')) {
//             const attr = node.attributes;
//             const textSize = this.helper.parsePx(this.helper.getAttr(attr, 'textSize')) || 14;
            
//             // প্যাডিং বের করা
//             const p = this.helper.parsePx(this.helper.getAttr(attr, 'padding')) || 0;
//             const pV = this.helper.parsePx(this.helper.getAttr(attr, 'paddingVertical')) || 0;
//             const pt = this.helper.parsePx(this.helper.getAttr(attr, 'paddingTop')) || pV || p;

//             // গ্র্যাভিটি চেক (সেন্টার করা থাকলে বেইসলাইন নিচে নামবে)
//             const gravity = this.helper.getAttr(attr, 'gravity') || '';
//             const isButton = type.includes('Button');
//             const isCenterVertical = gravity.includes('center') || gravity.includes('center_vertical') || isButton;

//             if (isCenterVertical) {
//                 // যদি টেক্সট ভার্টিকালি সেন্টারে থাকে
//                 return (h / 2) + (textSize * 0.35);
//             } else {
//                 // Standard Baseline ≈ PaddingTop + TextSize (Ascent)
//                 return pt + textSize * 0.9; 
//             }
//         }
//         return undefined;
//     }

//     estimateWidth(node) {
//         const type = node.type.split('.').pop();
        
//         if (type === 'Group' || type === 'Barrier' || type === 'Guideline' || type === 'Layer' ) {
//             return 0;
//         }

//         const attr = node.attributes;
//         if (this.helper.getAttr(attr, 'visibility') === 'gone') return 0;

//         const w = this.helper.getAttr(attr, 'layout_width');
//         if (w === '0dp' || w === 'match_parent') return 50; 
//         if (w && w !== 'wrap_content' && w !== '0dp' && w !== 'match_parent') return this.helper.parsePx(w);

//         if (['LinearLayout', 'ConstraintLayout', 'RelativeLayout', 'FrameLayout', 'CardView', 'ViewGroup', 'HorizontalScrollView', 'ScrollView', 'GridLayout'].includes(type)) {
//             if (node.children) {
//                 let totalW = 0;
//                 let maxW = 0;
//                 const isVertical = (this.helper.getAttr(attr, 'orientation') || 'horizontal') === 'vertical';
//                 const isStack = type === 'LinearLayout' && !isVertical;

//                 node.children.forEach(child => {
//                     if (child !== node) {
//                         const childW = this.estimateWidth(child);
//                         const ml = this.helper.parsePx(this.helper.getAttr(child.attributes, 'layout_marginStart'));
//                         const mr = this.helper.parsePx(this.helper.getAttr(child.attributes, 'layout_marginEnd'));
//                         const actualChildW = childW + ml + mr;
//                         if (isStack) totalW += actualChildW;
//                         else maxW = Math.max(maxW, actualChildW);
//                     }
//                 });

//                 const p = this.helper.parsePx(this.helper.getAttr(attr, 'padding'));
//                 const pH = this.helper.parsePx(this.helper.getAttr(attr, 'paddingHorizontal'));
//                 const cp = this.helper.parsePx(this.helper.getAttr(attr, 'contentPadding'));
//                 const pl = this.helper.parsePx(this.helper.getAttr(attr, 'paddingLeft') || this.helper.getAttr(attr, 'paddingStart')) || pH || cp || p;
//                 const pr = this.helper.parsePx(this.helper.getAttr(attr, 'paddingRight') || this.helper.getAttr(attr, 'paddingEnd')) || pH || cp || p;

//                 const contentW = (isStack || type === 'GridLayout') ? totalW : maxW;
//                 if (type === 'GridLayout') {
//                     const colCount = parseInt(this.helper.getAttr(attr, 'columnCount') || '1');
//                     return Math.max(10, (maxW * colCount) + pl + pr);
//                 }
//                 return Math.max(10, contentW + pl + pr);
//             }
//             return 100;
//         }

//         if (type === 'ProgressBar') return 50;

//         if (type === 'TextView' || type.includes('Button') || type.includes('Switch') || type.includes('CheckBox') || type.includes('RadioButton')) {
//             let text = this._resolveText(node);
//             const isButton = type.includes('Button');

//             if (isButton || this.helper.getAttr(attr, 'textAllCaps') === 'true') {
//                 text = text ? text.toUpperCase() : '';
//             }

//             const result = this.measurer.measure(text, attr, this.solver.parentW);
//             let measuredW = result.width;

//             if (isButton) {
//                 measuredW = (measuredW * 1.45) + 40;
//             } 
//             else if (type.includes('Switch') || type.includes('CheckBox') || type.includes('RadioButton')) {
//                 measuredW = Math.ceil(measuredW * 1.1) + 60;
//             } 
//             else {
//                 measuredW = (measuredW * 1.35) + 4;
//             }

//             const p = this.helper.parsePx(this.helper.getAttr(attr, 'padding')) || 0;
//             const ph = this.helper.parsePx(this.helper.getAttr(attr, 'paddingHorizontal')) || 0;
//             const pl = this.helper.parsePx(this.helper.getAttr(attr, 'paddingLeft') || this.helper.getAttr(attr, 'paddingStart')) || 0;
//             const pr = this.helper.parsePx(this.helper.getAttr(attr, 'paddingRight') || this.helper.getAttr(attr, 'paddingEnd')) || 0;
            
//             measuredW += (p * 2) + (ph * 2) + pl + pr;

//             return Math.min(Math.max(0, Math.ceil(measuredW)), this.solver.parentW);
//         }
//         return 100;
//     }

//     estimateHeight(node, calculatedWidth) {
//         const type = node.type.split('.').pop();
        
//         if (type === 'Group' || type === 'Barrier' || type === 'Guideline' || type === 'Layer') {
//             return 0;
//         }

//         const attr = node.attributes;
//         if (this.helper.getAttr(attr, 'visibility') === 'gone') return 0;

//         const h = this.helper.getAttr(attr, 'layout_height');
//         if (h && h !== 'wrap_content' && h !== '0dp' && h !== 'match_parent') return this.helper.parsePx(h);

//         if (type.includes('Switch') || type.includes('CheckBox') || type.includes('RadioButton')) {
//             const minH = this.helper.parsePx(this.helper.getAttr(attr, 'minHeight')) || 0;
//             return Math.max(32, minH);
//         }

//         const isLayout = ['LinearLayout', 'ConstraintLayout', 'RelativeLayout', 'FrameLayout', 'CardView', 'ViewGroup', 'HorizontalScrollView', 'ScrollView', 'GridLayout'].includes(type);

//         if (node.children && isLayout) {
//             let totalH = 0;
//             let maxH = 0;
//             const isVertical = (this.helper.getAttr(attr, 'orientation') || 'horizontal') === 'vertical';
//             const isStack = type === 'LinearLayout' && isVertical;

//             const p = this.helper.parsePx(this.helper.getAttr(attr, 'padding'));
//             const pV = this.helper.parsePx(this.helper.getAttr(attr, 'paddingVertical'));
//             const cp = this.helper.parsePx(this.helper.getAttr(attr, 'contentPadding'));
//             const pt = this.helper.parsePx(this.helper.getAttr(attr, 'paddingTop')) || pV || cp || p;
//             const pb = this.helper.parsePx(this.helper.getAttr(attr, 'paddingBottom')) || pV || cp || p;

//             if (isVertical && type === 'LinearLayout') {
//                 node.children.forEach(child => {
//                     if (child !== node) {
//                         const childH = this.estimateHeight(child, calculatedWidth);
//                         const mt = this.helper.parsePx(this.helper.getAttr(child.attributes, 'layout_marginTop'));
//                         const mb = this.helper.parsePx(this.helper.getAttr(child.attributes, 'layout_marginBottom'));
//                         totalH += childH + mt + mb;
//                     }
//                 });
//                 return Math.max(20, totalH + pt + pb);
//             }

//             node.children.forEach(child => {
//                 if (child !== node) {
//                     const childH = this.estimateHeight(child, calculatedWidth);
//                     const mt = this.helper.parsePx(this.helper.getAttr(child.attributes, 'layout_marginTop'));
//                     const mb = this.helper.parsePx(this.helper.getAttr(child.attributes, 'layout_marginBottom'));
//                     const actualChildH = childH + mt + mb;
//                     if (isStack) totalH += actualChildH;
//                     else maxH = Math.max(maxH, actualChildH);
//                 }
//             });
//             const contentH = isStack ? totalH : maxH;
//             return Math.max(20, contentH + pt + pb);
//         }

//         if (type === 'ProgressBar') return 50;

//         if (type === 'TextView' || type.includes('Button')) {
//             const availableW = (calculatedWidth > 0) ? calculatedWidth : this.solver.parentW;
//             let text = this._resolveText(node);
//             if (type.includes('Button') || this.helper.getAttr(attr, 'textAllCaps') === 'true') {
//                 text = text ? text.toUpperCase() : '';
//             }

//             const result = this.measurer.measure(text, attr, availableW);
//             let measuredH = result.height;

//             if (type.includes('Button')) {
//                 const hasUserPadding = attr['android:padding'] || attr['padding'] ||
//                                     attr['android:paddingTop'] || attr['paddingTop'] ||
//                                     attr['android:paddingVertical'] || attr['paddingVertical'];

//                 if (!hasUserPadding) {
//                     measuredH += 12; 
//                 }
//                 measuredH += 8; 
//             }

//             const p = this.helper.parsePx(this.helper.getAttr(attr, 'padding'));
//             const pV = this.helper.parsePx(this.helper.getAttr(attr, 'paddingVertical'));
//             const pt = this.helper.parsePx(this.helper.getAttr(attr, 'paddingTop')) || pV || p;
//             const pb = this.helper.parsePx(this.helper.getAttr(attr, 'paddingBottom')) || pV || p;

//             return measuredH + pt + pb;
//         }
//         return 50;
//     }

//     _resolveText(node) {
//         const raw = this.helper.getAttr(node.attributes, 'text') || '';
//         return this.solver.resolver ? this.solver.resolver.resolveString(raw) : raw;
//     }
// }


// // // nested basement fix 
// import { TextMeasurer } from '../../text/TextMeasurer.js';

// export class DimensionEstimator {
//     constructor(solver) {
//         this.solver = solver;
//         this.helper = solver.helper;
//         this.measurer = new TextMeasurer();
//     }

//     estimateAll(children) {
//         children.forEach(node => {
//             const id = this.helper.getId(node);
//             const state = this.solver.nodeMap.get(id);
//             if (!state || state.isGuideline) return;

//             state.w = this.estimateWidth(node);
//             state.h = this.estimateHeight(node, 0); 
            
//             // 🔥 Calculate Baseline (Now supports nested containers)
//             state.baseline = this.estimateBaseline(node, state.h);

//             this.solver.logger.log('solve', `View: ${id} - Estimate: ${state.w}x${state.h} Baseline: ${state.baseline}`);
//         });
//     }

//     // estimateBaseline(node, h) {
//     //     const type = node.type.split('.').pop();
//     //     const attr = node.attributes;
        
//     //     // 1. Text View Logic
//     //     if (type === 'TextView' || type.includes('Button') || type.includes('EditText') || type.includes('RadioButton') || type.includes('CheckBox')) {
//     //         const textSize = this.helper.parsePx(this.helper.getAttr(attr, 'textSize')) || 14;
            
//     //         const p = this.helper.parsePx(this.helper.getAttr(attr, 'padding')) || 0;
//     //         const pV = this.helper.parsePx(this.helper.getAttr(attr, 'paddingVertical')) || 0;
//     //         const pt = this.helper.parsePx(this.helper.getAttr(attr, 'paddingTop')) || pV || p;

//     //         const gravity = this.helper.getAttr(attr, 'gravity') || '';
//     //         const isButton = type.includes('Button');
//     //         const isCenterVertical = gravity.includes('center') || gravity.includes('center_vertical') || isButton;

//     //         if (isCenterVertical) {
//     //             return (h / 2) + (textSize * 0.35);
//     //         } else {
//     //             return pt + textSize * 0.9; 
//     //         }
//     //     }
        
//     //     // 🔥 2. Container Logic (Fix for Nested Baseline)
//     //     // কন্টেইনারের বেইসলাইন = প্রথম ভিজিবল চাইল্ডের বেইসলাইন + প্যাডিং/মার্জিন
//     //     if (['ConstraintLayout', 'LinearLayout', 'FrameLayout', 'RelativeLayout'].includes(type)) {
//     //         if (node.children && node.children.length > 0) {
//     //             const p = this.helper.parsePx(this.helper.getAttr(attr, 'padding'));
//     //             const pV = this.helper.parsePx(this.helper.getAttr(attr, 'paddingVertical'));
//     //             const pt = this.helper.parsePx(this.helper.getAttr(attr, 'paddingTop')) || pV || p || 0;

//     //             // প্রথম ভিজিবল চাইল্ড খুঁজছি
//     //             for (let child of node.children) {
//     //                 if (child === node) continue;
//     //                 if (this.helper.getAttr(child.attributes, 'visibility') === 'gone') continue;

//     //                 const mt = this.helper.parsePx(this.helper.getAttr(child.attributes, 'layout_marginTop')) || 0;
//     //                 const childH = this.estimateHeight(child, 0); 
                     
//     //                 // রিকার্সিভলি চাইল্ডের বেইসলাইন আনছি
//     //                 let childBase = this.estimateBaseline(child, childH);
                     
//     //                 // যদি চাইল্ডের বেইসলাইন না থাকে (যেমন সাধারণ View), তবে তার Top (0) কেই বেইসলাইন ধরব
//     //                 if (childBase === undefined) {
//     //                     childBase = 0; 
//     //                 }
                     
//     //                 // Container Baseline = PaddingTop + MarginTop + ChildBaseline
//     //                 return pt + mt + childBase;
//     //             }
//     //         }
//     //     }

//     //     return undefined;
//     // }
    
//     estimateBaseline(node, containerH) {
//         const type = node.type.split('.').pop();
//         const attr = node.attributes;
        
//         // 1. Text View / Button Logic
//         if (type === 'TextView' || type.includes('Button') || type.includes('EditText') || type.includes('RadioButton') || type.includes('CheckBox')) {
//             const textSize = this.helper.parsePx(this.helper.getAttr(attr, 'textSize')) || 14;
            
//             const p = this.helper.parsePx(this.helper.getAttr(attr, 'padding')) || 0;
//             const pV = this.helper.parsePx(this.helper.getAttr(attr, 'paddingVertical')) || 0;
//             const pt = this.helper.parsePx(this.helper.getAttr(attr, 'paddingTop')) || pV || p;

//             const gravity = this.helper.getAttr(attr, 'gravity') || '';
//             const isButton = type.includes('Button');
//             const isCenterVertical = gravity.includes('center') || gravity.includes('center_vertical') || isButton;

//             if (isCenterVertical) {
//                 return (containerH / 2) + (textSize * 0.35);
//             } else {
//                 return pt + textSize * 0.9; 
//             }
//         }
        
//         // 🔥 2. Container Logic (Improved for Centered Children)
//         if (['ConstraintLayout', 'LinearLayout', 'FrameLayout', 'RelativeLayout'].includes(type)) {
//             if (node.children && node.children.length > 0) {
//                 const pt = this.helper.parsePx(this.helper.getAttr(attr, 'paddingTop')) || 
//                             this.helper.parsePx(this.helper.getAttr(attr, 'paddingVertical')) || 
//                             this.helper.parsePx(this.helper.getAttr(attr, 'padding')) || 0;

//                 // Find the first visible child to determine baseline
//                 for (let child of node.children) {
//                     if (child === node) continue;
//                     if (this.helper.getAttr(child.attributes, 'visibility') === 'gone') continue;

//                     const childAttr = child.attributes;
//                     const mt = this.helper.parsePx(this.helper.getAttr(childAttr, 'layout_marginTop')) || 0;
//                     const childH = this.estimateHeight(child, 0); 
                     
//                     let childBase = this.estimateBaseline(child, childH);
//                     if (childBase === undefined) {
//                         childBase = 0; // Default View baseline is top
//                     }

//                     // 🔥 CHECK: Is the child vertically centered?
//                     // ConstraintLayout Centering Logic
//                     const topToTop = this.helper.getAttr(childAttr, 'layout_constraintTop_toTopOf');
//                     const bottomToBottom = this.helper.getAttr(childAttr, 'layout_constraintBottom_toBottomOf');
                     
//                     // LinearLayout Gravity Logic
//                     const layoutGravity = this.helper.getAttr(childAttr, 'layout_gravity') || '';
//                     const isLinearCenter = layoutGravity.includes('center') || layoutGravity.includes('center_vertical');

//                     if ((topToTop === 'parent' && bottomToBottom === 'parent') || isLinearCenter) {
//                         // Child is centered!
//                         // Baseline = (ContainerHalf - ChildHalf) + ChildBaseline
//                         const childY = (containerH - childH) / 2;
//                         return childY + childBase;
//                     } else {
//                         // Child is top-aligned (standard)
//                         return pt + mt + childBase;
//                     }
//                 }
//             }
//         }

//         return undefined;
//     }

//     estimateWidth(node) {
//         const type = node.type.split('.').pop();
        
//         if (type === 'Group' || type === 'Barrier' || type === 'Guideline' || type === 'Layer' ) {
//             return 0;
//         }

//         const attr = node.attributes;
//         if (this.helper.getAttr(attr, 'visibility') === 'gone') return 0;

//         const w = this.helper.getAttr(attr, 'layout_width');
//         if (w === '0dp' || w === 'match_parent') return 50; 
//         if (w && w !== 'wrap_content' && w !== '0dp' && w !== 'match_parent') return this.helper.parsePx(w);

//         if (['LinearLayout', 'ConstraintLayout', 'RelativeLayout', 'FrameLayout', 'CardView', 'ViewGroup', 'HorizontalScrollView', 'ScrollView', 'GridLayout'].includes(type)) {
//             if (node.children) {
//                 let totalW = 0;
//                 let maxW = 0;
//                 const isVertical = (this.helper.getAttr(attr, 'orientation') || 'horizontal') === 'vertical';
//                 const isStack = type === 'LinearLayout' && !isVertical;

//                 node.children.forEach(child => {
//                     if (child !== node) {
//                         const childW = this.estimateWidth(child);
//                         const ml = this.helper.parsePx(this.helper.getAttr(child.attributes, 'layout_marginStart'));
//                         const mr = this.helper.parsePx(this.helper.getAttr(child.attributes, 'layout_marginEnd'));
//                         const actualChildW = childW + ml + mr;
//                         if (isStack) totalW += actualChildW;
//                         else maxW = Math.max(maxW, actualChildW);
//                     }
//                 });

//                 const p = this.helper.parsePx(this.helper.getAttr(attr, 'padding'));
//                 const pH = this.helper.parsePx(this.helper.getAttr(attr, 'paddingHorizontal'));
//                 const cp = this.helper.parsePx(this.helper.getAttr(attr, 'contentPadding'));
//                 const pl = this.helper.parsePx(this.helper.getAttr(attr, 'paddingLeft') || this.helper.getAttr(attr, 'paddingStart')) || pH || cp || p;
//                 const pr = this.helper.parsePx(this.helper.getAttr(attr, 'paddingRight') || this.helper.getAttr(attr, 'paddingEnd')) || pH || cp || p;

//                 const contentW = (isStack || type === 'GridLayout') ? totalW : maxW;
//                 if (type === 'GridLayout') {
//                     const colCount = parseInt(this.helper.getAttr(attr, 'columnCount') || '1');
//                     return Math.max(10, (maxW * colCount) + pl + pr);
//                 }
//                 return Math.max(10, contentW + pl + pr);
//             }
//             return 100;
//         }

//         if (type === 'ProgressBar') return 50;

//         if (type === 'TextView' || type.includes('Button') || type.includes('Switch') || type.includes('CheckBox') || type.includes('RadioButton')) {
//             let text = this._resolveText(node);
//             const isButton = type.includes('Button');

//             if (isButton || this.helper.getAttr(attr, 'textAllCaps') === 'true') {
//                 text = text ? text.toUpperCase() : '';
//             }

//             const result = this.measurer.measure(text, attr, this.solver.parentW);
//             let measuredW = result.width;

//             if (isButton) {
//                 measuredW = (measuredW * 1.45) + 40;
//             } 
//             else if (type.includes('Switch') || type.includes('CheckBox') || type.includes('RadioButton')) {
//                 measuredW = Math.ceil(measuredW * 1.1) + 60;
//             } 
//             else {
//                 measuredW = (measuredW * 1.35) + 4;
//             }

//             const p = this.helper.parsePx(this.helper.getAttr(attr, 'padding')) || 0;
//             const ph = this.helper.parsePx(this.helper.getAttr(attr, 'paddingHorizontal')) || 0;
//             const pl = this.helper.parsePx(this.helper.getAttr(attr, 'paddingLeft') || this.helper.getAttr(attr, 'paddingStart')) || 0;
//             const pr = this.helper.parsePx(this.helper.getAttr(attr, 'paddingRight') || this.helper.getAttr(attr, 'paddingEnd')) || 0;
            
//             measuredW += (p * 2) + (ph * 2) + pl + pr;

//             return Math.min(Math.max(0, Math.ceil(measuredW)), this.solver.parentW);
//         }
//         return 100;
//     }

//     estimateHeight(node, calculatedWidth) {
//         const type = node.type.split('.').pop();
        
//         if (type === 'Group' || type === 'Barrier' || type === 'Guideline' || type === 'Layer') {
//             return 0;
//         }

//         const attr = node.attributes;
//         if (this.helper.getAttr(attr, 'visibility') === 'gone') return 0;

//         const h = this.helper.getAttr(attr, 'layout_height');
//         if (h && h !== 'wrap_content' && h !== '0dp' && h !== 'match_parent') return this.helper.parsePx(h);

//         if (type.includes('Switch') || type.includes('CheckBox') || type.includes('RadioButton')) {
//             const minH = this.helper.parsePx(this.helper.getAttr(attr, 'minHeight')) || 0;
//             return Math.max(32, minH);
//         }

//         const isLayout = ['LinearLayout', 'ConstraintLayout', 'RelativeLayout', 'FrameLayout', 'CardView', 'ViewGroup', 'HorizontalScrollView', 'ScrollView', 'GridLayout'].includes(type);

//         if (node.children && isLayout) {
//             let totalH = 0;
//             let maxH = 0;
//             const isVertical = (this.helper.getAttr(attr, 'orientation') || 'horizontal') === 'vertical';
//             const isStack = type === 'LinearLayout' && isVertical;

//             const p = this.helper.parsePx(this.helper.getAttr(attr, 'padding'));
//             const pV = this.helper.parsePx(this.helper.getAttr(attr, 'paddingVertical'));
//             const cp = this.helper.parsePx(this.helper.getAttr(attr, 'contentPadding'));
//             const pt = this.helper.parsePx(this.helper.getAttr(attr, 'paddingTop')) || pV || cp || p;
//             const pb = this.helper.parsePx(this.helper.getAttr(attr, 'paddingBottom')) || pV || cp || p;

//             if (isVertical && type === 'LinearLayout') {
//                 node.children.forEach(child => {
//                     if (child !== node) {
//                         const childH = this.estimateHeight(child, calculatedWidth);
//                         const mt = this.helper.parsePx(this.helper.getAttr(child.attributes, 'layout_marginTop'));
//                         const mb = this.helper.parsePx(this.helper.getAttr(child.attributes, 'layout_marginBottom'));
//                         totalH += childH + mt + mb;
//                     }
//                 });
//                 return Math.max(20, totalH + pt + pb);
//             }

//             node.children.forEach(child => {
//                 if (child !== node) {
//                     const childH = this.estimateHeight(child, calculatedWidth);
//                     const mt = this.helper.parsePx(this.helper.getAttr(child.attributes, 'layout_marginTop'));
//                     const mb = this.helper.parsePx(this.helper.getAttr(child.attributes, 'layout_marginBottom'));
//                     const actualChildH = childH + mt + mb;
//                     if (isStack) totalH += actualChildH;
//                     else maxH = Math.max(maxH, actualChildH);
//                 }
//             });
//             const contentH = isStack ? totalH : maxH;
//             return Math.max(20, contentH + pt + pb);
//         }

//         if (type === 'ProgressBar') return 50;

//         if (type === 'TextView' || type.includes('Button')) {
//             const availableW = (calculatedWidth > 0) ? calculatedWidth : this.solver.parentW;
//             let text = this._resolveText(node);
//             if (type.includes('Button') || this.helper.getAttr(attr, 'textAllCaps') === 'true') {
//                 text = text ? text.toUpperCase() : '';
//             }

//             const result = this.measurer.measure(text, attr, availableW);
//             let measuredH = result.height;

//             if (type.includes('Button')) {
//                 const hasUserPadding = attr['android:padding'] || attr['padding'] ||
//                                     attr['android:paddingTop'] || attr['paddingTop'] ||
//                                     attr['android:paddingVertical'] || attr['paddingVertical'];

//                 if (!hasUserPadding) {
//                     measuredH += 12; 
//                 }
//                 measuredH += 8; 
//             }

//             const p = this.helper.parsePx(this.helper.getAttr(attr, 'padding'));
//             const pV = this.helper.parsePx(this.helper.getAttr(attr, 'paddingVertical'));
//             const pt = this.helper.parsePx(this.helper.getAttr(attr, 'paddingTop')) || pV || p;
//             const pb = this.helper.parsePx(this.helper.getAttr(attr, 'paddingBottom')) || pV || p;

//             return measuredH + pt + pb;
//         }
//         return 50;
//     }

//     _resolveText(node) {
//         const raw = this.helper.getAttr(node.attributes, 'text') || '';
//         return this.solver.resolver ? this.solver.resolver.resolveString(raw) : raw;
//     }
// }


// text gap fix
// import { TextMeasurer } from '../../text/TextMeasurer.js';

// export class DimensionEstimator {
//     constructor(solver) {
//         this.solver = solver;
//         this.helper = solver.helper;
//         this.measurer = new TextMeasurer();
//     }

//     estimateAll(children) {
//         children.forEach(node => {
//             const id = this.helper.getId(node);
//             const state = this.solver.nodeMap.get(id);
//             if (!state || state.isGuideline) return;

//             state.w = this.estimateWidth(node);
//             state.h = this.estimateHeight(node, 0); 
            
//             // Calculate Baseline
//             state.baseline = this.estimateBaseline(node, state.h);

//             this.solver.logger.log('solve', `View: ${id} - Estimate: ${state.w}x${state.h} Baseline: ${state.baseline}`);
//         });
//     }

//     estimateBaseline(node, containerH) {
//         const type = node.type.split('.').pop();
//         const attr = node.attributes;
        
//         if (type === 'TextView' || type.includes('Button') || type.includes('EditText') || type.includes('RadioButton') || type.includes('CheckBox')) {
//             const textSize = this.helper.parsePx(this.helper.getAttr(attr, 'textSize')) || 14;
//             const p = this.helper.parsePx(this.helper.getAttr(attr, 'padding')) || 0;
//             const pV = this.helper.parsePx(this.helper.getAttr(attr, 'paddingVertical')) || 0;
//             const pt = this.helper.parsePx(this.helper.getAttr(attr, 'paddingTop')) || pV || p;

//             const gravity = this.helper.getAttr(attr, 'gravity') || '';
//             const isButton = type.includes('Button');
//             const isCenterVertical = gravity.includes('center') || gravity.includes('center_vertical') || isButton;

//             if (isCenterVertical) {
//                 return (containerH / 2) + (textSize * 0.35);
//             } else {
//                 return pt + textSize * 0.9; 
//             }
//         }
        
//         // Container Logic (Improved for Centered Children)
//         if (['ConstraintLayout', 'LinearLayout', 'FrameLayout', 'RelativeLayout'].includes(type)) {
//             if (node.children && node.children.length > 0) {
//                 const pt = this.helper.parsePx(this.helper.getAttr(attr, 'paddingTop')) || 
//                             this.helper.parsePx(this.helper.getAttr(attr, 'paddingVertical')) || 
//                             this.helper.parsePx(this.helper.getAttr(attr, 'padding')) || 0;

//                 for (let child of node.children) {
//                     if (child === node) continue;
//                     if (this.helper.getAttr(child.attributes, 'visibility') === 'gone') continue;

//                     const childAttr = child.attributes;
//                     const mt = this.helper.parsePx(this.helper.getAttr(childAttr, 'layout_marginTop')) || 0;
//                     const childH = this.estimateHeight(child, 0); 
                     
//                     let childBase = this.estimateBaseline(child, childH);
//                     if (childBase === undefined) childBase = 0;

//                     const topToTop = this.helper.getAttr(childAttr, 'layout_constraintTop_toTopOf');
//                     const bottomToBottom = this.helper.getAttr(childAttr, 'layout_constraintBottom_toBottomOf');
//                     const layoutGravity = this.helper.getAttr(childAttr, 'layout_gravity') || '';
//                     const isLinearCenter = layoutGravity.includes('center') || layoutGravity.includes('center_vertical');

//                     if ((topToTop === 'parent' && bottomToBottom === 'parent') || isLinearCenter) {
//                         const childY = (containerH - childH) / 2;
//                         return childY + childBase;
//                     } else {
//                         return pt + mt + childBase;
//                     }
//                 }
//             }
//         }
//         return undefined;
//     }

//     estimateWidth(node) {
//         const type = node.type.split('.').pop();
//         if (type === 'Group' || type === 'Barrier' || type === 'Guideline' || type === 'Layer' ) return 0;

//         const attr = node.attributes;
//         if (this.helper.getAttr(attr, 'visibility') === 'gone') return 0;

//         const w = this.helper.getAttr(attr, 'layout_width');
//         if (w === '0dp' || w === 'match_parent') return 50; 
//         if (w && w !== 'wrap_content' && w !== '0dp' && w !== 'match_parent') return this.helper.parsePx(w);

//         // Layout Containers
//         if (['LinearLayout', 'ConstraintLayout', 'RelativeLayout', 'FrameLayout', 'CardView', 'ViewGroup', 'HorizontalScrollView', 'ScrollView', 'GridLayout'].includes(type)) {
//             if (node.children) {
//                 let totalW = 0;
//                 let maxW = 0;
//                 const isVertical = (this.helper.getAttr(attr, 'orientation') || 'horizontal') === 'vertical';
//                 const isStack = type === 'LinearLayout' && !isVertical;

//                 node.children.forEach(child => {
//                     if (child !== node) {
//                         const childW = this.estimateWidth(child);
//                         const ml = this.helper.parsePx(this.helper.getAttr(child.attributes, 'layout_marginStart'));
//                         const mr = this.helper.parsePx(this.helper.getAttr(child.attributes, 'layout_marginEnd'));
//                         const actualChildW = childW + ml + mr;
//                         if (isStack) totalW += actualChildW;
//                         else maxW = Math.max(maxW, actualChildW);
//                     }
//                 });

//                 const p = this.helper.parsePx(this.helper.getAttr(attr, 'padding'));
//                 const pH = this.helper.parsePx(this.helper.getAttr(attr, 'paddingHorizontal'));
//                 const cp = this.helper.parsePx(this.helper.getAttr(attr, 'contentPadding'));
//                 const pl = this.helper.parsePx(this.helper.getAttr(attr, 'paddingLeft') || this.helper.getAttr(attr, 'paddingStart')) || pH || cp || p;
//                 const pr = this.helper.parsePx(this.helper.getAttr(attr, 'paddingRight') || this.helper.getAttr(attr, 'paddingEnd')) || pH || cp || p;

//                 const contentW = (isStack || type === 'GridLayout') ? totalW : maxW;
//                 if (type === 'GridLayout') {
//                     const colCount = parseInt(this.helper.getAttr(attr, 'columnCount') || '1');
//                     return Math.max(10, (maxW * colCount) + pl + pr);
//                 }
//                 return Math.max(10, contentW + pl + pr);
//             }
//             return 100;
//         }

//         if (type === 'ProgressBar') return 50;

//         // 🔥 FIX: Clean TextView/Button Logic
//         if (type === 'TextView' || type.includes('Button') || type.includes('Switch') || type.includes('CheckBox') || type.includes('RadioButton')) {
//             let text = this._resolveText(node);
//             const isButton = type.includes('Button');

//             if (isButton || this.helper.getAttr(attr, 'textAllCaps') === 'true') {
//                 text = text ? text.toUpperCase() : '';
//             }

//             // TextMeasurer now returns exact width including padding
//             const result = this.measurer.measure(text, attr, this.solver.parentW);
//             let measuredW = result.width;

//             // Minimal safety buffer for Buttons/Compound views
//             if (isButton) {
//                 measuredW += 24; 
//             } else if (type.includes('Switch') || type.includes('CheckBox') || type.includes('RadioButton')) {
//                 measuredW += 48; // Space for toggle/checkbox graphic
//             }

//             return Math.min(Math.max(0, Math.ceil(measuredW)), this.solver.parentW);
//         }
//         return 100;
//     }

//     estimateHeight(node, calculatedWidth) {
//         const type = node.type.split('.').pop();
//         if (type === 'Group' || type === 'Barrier' || type === 'Guideline' || type === 'Layer') return 0;

//         const attr = node.attributes;
//         if (this.helper.getAttr(attr, 'visibility') === 'gone') return 0;

//         const h = this.helper.getAttr(attr, 'layout_height');
//         if (h && h !== 'wrap_content' && h !== '0dp' && h !== 'match_parent') return this.helper.parsePx(h);

//         if (type.includes('Switch') || type.includes('CheckBox') || type.includes('RadioButton')) {
//             const minH = this.helper.parsePx(this.helper.getAttr(attr, 'minHeight')) || 0;
//             return Math.max(32, minH);
//         }

//         // Layout Containers Logic (Standard)
//         if (node.children && ['LinearLayout', 'ConstraintLayout', 'RelativeLayout', 'FrameLayout', 'CardView', 'ViewGroup', 'HorizontalScrollView', 'ScrollView', 'GridLayout'].includes(type)) {
//             let totalH = 0;
//             let maxH = 0;
//             const isVertical = (this.helper.getAttr(attr, 'orientation') || 'horizontal') === 'vertical';
//             const isStack = type === 'LinearLayout' && isVertical;

//             const p = this.helper.parsePx(this.helper.getAttr(attr, 'padding'));
//             const pV = this.helper.parsePx(this.helper.getAttr(attr, 'paddingVertical'));
//             const cp = this.helper.parsePx(this.helper.getAttr(attr, 'contentPadding'));
//             const pt = this.helper.parsePx(this.helper.getAttr(attr, 'paddingTop')) || pV || cp || p;
//             const pb = this.helper.parsePx(this.helper.getAttr(attr, 'paddingBottom')) || pV || cp || p;

//             if (isVertical && type === 'LinearLayout') {
//                 node.children.forEach(child => {
//                     if (child !== node) {
//                         const childH = this.estimateHeight(child, calculatedWidth);
//                         const mt = this.helper.parsePx(this.helper.getAttr(child.attributes, 'layout_marginTop'));
//                         const mb = this.helper.parsePx(this.helper.getAttr(child.attributes, 'layout_marginBottom'));
//                         totalH += childH + mt + mb;
//                     }
//                 });
//                 return Math.max(20, totalH + pt + pb);
//             }

//             node.children.forEach(child => {
//                 if (child !== node) {
//                     const childH = this.estimateHeight(child, calculatedWidth);
//                     const mt = this.helper.parsePx(this.helper.getAttr(child.attributes, 'layout_marginTop'));
//                     const mb = this.helper.parsePx(this.helper.getAttr(child.attributes, 'layout_marginBottom'));
//                     const actualChildH = childH + mt + mb;
//                     if (isStack) totalH += actualChildH;
//                     else maxH = Math.max(maxH, actualChildH);
//                 }
//             });
//             const contentH = isStack ? totalH : maxH;
//             return Math.max(20, contentH + pt + pb);
//         }

//         if (type === 'ProgressBar') return 50;

//         // 🔥 FIX: Clean TextView/Button Height Logic
//         if (type === 'TextView' || type.includes('Button')) {
//             const availableW = (calculatedWidth > 0) ? calculatedWidth : this.solver.parentW;
//             let text = this._resolveText(node);
//             if (type.includes('Button') || this.helper.getAttr(attr, 'textAllCaps') === 'true') {
//                 text = text ? text.toUpperCase() : '';
//             }

//             // TextMeasurer now returns exact height including padding
//             const result = this.measurer.measure(text, attr, availableW);
//             return result.height;
//         }
//         return 50;
//     }

//     _resolveText(node) {
//         const raw = this.helper.getAttr(node.attributes, 'text') || '';
//         return this.solver.resolver ? this.solver.resolver.resolveString(raw) : raw;
//     }
// }

// width mismatch two three 
import { TextMeasurer } from '../../text/TextMeasurer.js';

export class DimensionEstimator {
    constructor(solver) {
        this.solver = solver;
        this.helper = solver.helper;
        this.measurer = new TextMeasurer();
    }

    estimateAll(children) {
        children.forEach(node => {
            const id = this.helper.getId(node);
            const state = this.solver.nodeMap.get(id);
            if (!state || state.isGuideline) return;

            state.w = this.estimateWidth(node);
            state.h = this.estimateHeight(node, 0); 
            state.baseline = this.estimateBaseline(node, state.h);

            this.solver.logger.log('solve', `View: ${id} - Estimate: ${state.w}x${state.h} Baseline: ${state.baseline}`);
        });
    }

    // ... estimateBaseline মেথডটি আগের মতোই থাকবে ...
    estimateBaseline(node, containerH) {
        const type = node.type.split('.').pop();
        const attr = node.attributes;
        
        if (type === 'TextView' || type.includes('Button') || type.includes('EditText') || type.includes('RadioButton') || type.includes('CheckBox')) {
            const textSize = this.helper.parsePx(this.helper.getAttr(attr, 'textSize')) || 14;
            const p = this.helper.parsePx(this.helper.getAttr(attr, 'padding')) || 0;
            const pV = this.helper.parsePx(this.helper.getAttr(attr, 'paddingVertical')) || 0;
            const pt = this.helper.parsePx(this.helper.getAttr(attr, 'paddingTop')) || pV || p;

            const gravity = this.helper.getAttr(attr, 'gravity') || '';
            const isButton = type.includes('Button');
            const isCenterVertical = gravity.includes('center') || gravity.includes('center_vertical') || isButton;

            if (isCenterVertical) {
                return (containerH / 2) + (textSize * 0.35);
            } else {
                return pt + textSize * 0.9; 
            }
        }
        
        if (['ConstraintLayout', 'LinearLayout', 'FrameLayout', 'RelativeLayout'].includes(type)) {
            if (node.children && node.children.length > 0) {
                 const pt = this.helper.parsePx(this.helper.getAttr(attr, 'paddingTop')) || 
                            this.helper.parsePx(this.helper.getAttr(attr, 'paddingVertical')) || 
                            this.helper.parsePx(this.helper.getAttr(attr, 'padding')) || 0;

                 for (let child of node.children) {
                     if (child === node) continue;
                     if (this.helper.getAttr(child.attributes, 'visibility') === 'gone') continue;

                     const childAttr = child.attributes;
                     const mt = this.helper.parsePx(this.helper.getAttr(childAttr, 'layout_marginTop')) || 0;
                     const childH = this.estimateHeight(child, 0); 
                     
                     let childBase = this.estimateBaseline(child, childH);
                     if (childBase === undefined) childBase = 0;

                     const topToTop = this.helper.getAttr(childAttr, 'layout_constraintTop_toTopOf');
                     const bottomToBottom = this.helper.getAttr(childAttr, 'layout_constraintBottom_toBottomOf');
                     const layoutGravity = this.helper.getAttr(childAttr, 'layout_gravity') || '';
                     const isLinearCenter = layoutGravity.includes('center') || layoutGravity.includes('center_vertical');

                     if ((topToTop === 'parent' && bottomToBottom === 'parent') || isLinearCenter) {
                         const childY = (containerH - childH) / 2;
                         return childY + childBase;
                     } else {
                         return pt + mt + childBase;
                     }
                 }
            }
        }
        return undefined;
    }

    estimateWidth(node) {
        const type = node.type.split('.').pop();
        if (type === 'Group' || type === 'Barrier' || type === 'Guideline' || type === 'Layer' ) return 0;

        const attr = node.attributes;
        if (this.helper.getAttr(attr, 'visibility') === 'gone') return 0;

        const w = this.helper.getAttr(attr, 'layout_width');
        if (w === '0dp' || w === 'match_parent') return 50; 
        if (w && w !== 'wrap_content' && w !== '0dp' && w !== 'match_parent') return this.helper.parsePx(w);

        // Layout Containers
        if (['LinearLayout', 'ConstraintLayout', 'RelativeLayout', 'FrameLayout', 'CardView', 'ViewGroup', 'HorizontalScrollView', 'ScrollView', 'GridLayout'].includes(type)) {
            if (node.children) {
                let totalW = 0;
                let maxW = 0;
                const isVertical = (this.helper.getAttr(attr, 'orientation') || 'horizontal') === 'vertical';
                
                // 🔥 FIX: Detect Horizontal Chains in ConstraintLayout
                // যদি কোনো চাইল্ড অন্য চাইল্ডের ডানে বা বামে থাকে, তবে এটি হরাইজন্টাল চেইন
                let isConstraintHorizontal = false;
                if (type === 'ConstraintLayout') {
                    isConstraintHorizontal = node.children.some(child => 
                        this.helper.getAttr(child.attributes, 'layout_constraintStart_toEndOf') || 
                        this.helper.getAttr(child.attributes, 'layout_constraintEnd_toStartOf') ||
                        this.helper.getAttr(child.attributes, 'layout_constraintLeft_toRightOf') ||
                        this.helper.getAttr(child.attributes, 'layout_constraintRight_toLeftOf')
                    );
                }

                // এখন LinearLayout (Horizontal) অথবা ConstraintLayout (Horizontal Chain) হলে আমরা উইডথ যোগ (Sum) করব
                const isStack = (type === 'LinearLayout' && !isVertical) || isConstraintHorizontal;

                node.children.forEach(child => {
                    if (child !== node) {
                        const childW = this.estimateWidth(child);
                        const ml = this.helper.parsePx(this.helper.getAttr(child.attributes, 'layout_marginStart'));
                        const mr = this.helper.parsePx(this.helper.getAttr(child.attributes, 'layout_marginEnd'));
                        const actualChildW = childW + ml + mr;
                        
                        if (isStack) totalW += actualChildW; // Sum widths
                        else maxW = Math.max(maxW, actualChildW); // Max width
                    }
                });

                const p = this.helper.parsePx(this.helper.getAttr(attr, 'padding'));
                const pH = this.helper.parsePx(this.helper.getAttr(attr, 'paddingHorizontal'));
                const cp = this.helper.parsePx(this.helper.getAttr(attr, 'contentPadding'));
                const pl = this.helper.parsePx(this.helper.getAttr(attr, 'paddingLeft') || this.helper.getAttr(attr, 'paddingStart')) || pH || cp || p;
                const pr = this.helper.parsePx(this.helper.getAttr(attr, 'paddingRight') || this.helper.getAttr(attr, 'paddingEnd')) || pH || cp || p;

                const contentW = (isStack || type === 'GridLayout') ? totalW : maxW;
                if (type === 'GridLayout') {
                    const colCount = parseInt(this.helper.getAttr(attr, 'columnCount') || '1');
                    return Math.max(10, (maxW * colCount) + pl + pr);
                }
                return Math.max(10, contentW + pl + pr);
            }
            return 100;
        }

        if (type === 'ProgressBar') return 50;

        if (type === 'TextView' || type.includes('Button') || type.includes('Switch') || type.includes('CheckBox') || type.includes('RadioButton')) {
            let text = this._resolveText(node);
            const isButton = type.includes('Button');

            if (isButton || this.helper.getAttr(attr, 'textAllCaps') === 'true') {
                text = text ? text.toUpperCase() : '';
            }

            const result = this.measurer.measure(text, attr, this.solver.parentW);
            let measuredW = result.width;

            if (isButton) {
                measuredW += 24; 
            } else if (type.includes('Switch') || type.includes('CheckBox') || type.includes('RadioButton')) {
                measuredW += 48; 
            }

            return Math.min(Math.max(0, Math.ceil(measuredW)), this.solver.parentW);
        }
        return 100;
    }

    estimateHeight(node, calculatedWidth) {
        // ... (Height estimation logic remains same) ...
        const type = node.type.split('.').pop();
        if (type === 'Group' || type === 'Barrier' || type === 'Guideline' || type === 'Layer') return 0;

        const attr = node.attributes;
        if (this.helper.getAttr(attr, 'visibility') === 'gone') return 0;

        const h = this.helper.getAttr(attr, 'layout_height');
        if (h && h !== 'wrap_content' && h !== 'match_parent' && h !== '0dp') return this.helper.parsePx(h);

        if (type.includes('Switch') || type.includes('CheckBox') || type.includes('RadioButton')) {
            const minH = this.helper.parsePx(this.helper.getAttr(attr, 'minHeight')) || 0;
            return Math.max(32, minH);
        }

        if (node.children && ['LinearLayout', 'ConstraintLayout', 'RelativeLayout', 'FrameLayout', 'CardView', 'ViewGroup', 'HorizontalScrollView', 'ScrollView', 'GridLayout'].includes(type)) {
            let totalH = 0;
            let maxH = 0;
            const isVertical = (this.helper.getAttr(attr, 'orientation') || 'horizontal') === 'vertical';
            const isStack = type === 'LinearLayout' && isVertical;

            const p = this.helper.parsePx(this.helper.getAttr(attr, 'padding'));
            const pV = this.helper.parsePx(this.helper.getAttr(attr, 'paddingVertical'));
            const cp = this.helper.parsePx(this.helper.getAttr(attr, 'contentPadding'));
            const pt = this.helper.parsePx(this.helper.getAttr(attr, 'paddingTop')) || pV || cp || p;
            const pb = this.helper.parsePx(this.helper.getAttr(attr, 'paddingBottom')) || pV || cp || p;

            if (isVertical && type === 'LinearLayout') {
                node.children.forEach(child => {
                    if (child !== node) {
                        const childH = this.estimateHeight(child, calculatedWidth);
                        const mt = this.helper.parsePx(this.helper.getAttr(child.attributes, 'layout_marginTop'));
                        const mb = this.helper.parsePx(this.helper.getAttr(child.attributes, 'layout_marginBottom'));
                        totalH += childH + mt + mb;
                    }
                });
                return Math.max(20, totalH + pt + pb);
            }

            node.children.forEach(child => {
                if (child !== node) {
                    const childH = this.estimateHeight(child, calculatedWidth);
                    const mt = this.helper.parsePx(this.helper.getAttr(child.attributes, 'layout_marginTop'));
                    const mb = this.helper.parsePx(this.helper.getAttr(child.attributes, 'layout_marginBottom'));
                    const actualChildH = childH + mt + mb;
                    if (isStack) totalH += actualChildH;
                    else maxH = Math.max(maxH, actualChildH);
                }
            });
            const contentH = isStack ? totalH : maxH;
            return Math.max(20, contentH + pt + pb);
        }

        if (type === 'ProgressBar') return 50;

        if (type === 'TextView' || type.includes('Button')) {
            const availableW = (calculatedWidth > 0) ? calculatedWidth : this.solver.parentW;
            let text = this._resolveText(node);
            if (type.includes('Button') || this.helper.getAttr(attr, 'textAllCaps') === 'true') {
                 text = text ? text.toUpperCase() : '';
            }
            const result = this.measurer.measure(text, attr, availableW);
            return result.height;
        }
        return 50;
    }

    _resolveText(node) {
        const raw = this.helper.getAttr(node.attributes, 'text') || '';
        return this.solver.resolver ? this.solver.resolver.resolveString(raw) : raw;
    }
}