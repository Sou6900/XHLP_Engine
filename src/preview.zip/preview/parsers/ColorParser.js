// colors.xml

export class ColorParser {

    /**
     * Parse colors.xml content
     * @param {Document} xmlDoc 
     * @returns {Map<string, string>} Map of color names to hex codes
     */
    parse(xmlDoc) {
        const colors = new Map();
        if (!xmlDoc) return colors;

        const colorElements = xmlDoc.getElementsByTagName('color');
        
        for (let i = 0; i < colorElements.length; i++) {
            const el = colorElements[i];
            const name = el.getAttribute('name');
            const value = el.textContent.trim();
            
            if (name && value) {
                colors.set(name, value);
            }
        }
        return colors;
    }
}