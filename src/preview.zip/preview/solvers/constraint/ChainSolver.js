// // rtl fixing ...
// export class ChainSolver {
//     constructor(solver) {
//         this.solver = solver;
//         this.helper = solver.helper;
//     }

//     detectChains(children) {
//         const processedH = new Set();
//         const processedV = new Set();

//         children.forEach(node => {
//             const id = this.helper.getId(node);
//             if (!id) return;

//             if (!processedH.has(id)) {
//                 this.detectChain(id, children, 'horizontal', processedH);
//             }
//             if (!processedV.has(id)) {
//                 this.detectChain(id, children, 'vertical', processedV);
//             }
//         });
//     }

//     detectChain(headId, children, orientation, processedSet) {
//         const members = this.collectChainMembers(headId, children, orientation);
//         if (members.length < 2) return;

//         const headNode = members[0].node;
//         const tailNode = members[members.length - 1].node;
//         const headAttr = headNode.attributes;
//         const tailAttr = tailNode.attributes;

//         let headHasAnchor, tailHasAnchor;

//         if (orientation === 'horizontal') {
//             headHasAnchor =
//                 this.helper.getAttr(headAttr, 'layout_constraintStart_toStartOf') ||
//                 this.helper.getAttr(headAttr, 'layout_constraintStart_toEndOf') ||
//                 this.helper.getAttr(headAttr, 'layout_constraintLeft_toLeftOf');

//             tailHasAnchor =
//                 this.helper.getAttr(tailAttr, 'layout_constraintEnd_toEndOf') ||
//                 this.helper.getAttr(tailAttr, 'layout_constraintEnd_toStartOf') ||
//                 this.helper.getAttr(tailAttr, 'layout_constraintRight_toRightOf');
//         } else {
//             headHasAnchor =
//                 this.helper.getAttr(headAttr, 'layout_constraintTop_toTopOf') ||
//                 this.helper.getAttr(headAttr, 'layout_constraintTop_toBottomOf');

//             tailHasAnchor =
//                 this.helper.getAttr(tailAttr, 'layout_constraintBottom_toBottomOf') ||
//                 this.helper.getAttr(tailAttr, 'layout_constraintBottom_toTopOf');
//         }

//         if (headHasAnchor && tailHasAnchor) {
//             const styleAttr = orientation === 'horizontal' ? 'layout_constraintHorizontal_chainStyle' : 'layout_constraintVertical_chainStyle';
//             const biasAttr = orientation === 'horizontal' ? 'layout_constraintHorizontal_bias' : 'layout_constraintVertical_bias';

//             const style = this.helper.getAttr(headAttr, styleAttr) || 'spread';
//             const bias = parseFloat(this.helper.getAttr(headAttr, biasAttr) || '0.5');

//             members.forEach(m => {
//                 const state = this.solver.nodeMap.get(m.id);
//                 if (orientation === 'horizontal') state.inHorizontalChain = true;
//                 else state.inVerticalChain = true;
//                 processedSet.add(m.id);
//             });

//             const headState = this.solver.nodeMap.get(members[0].id);
//             if (orientation === 'horizontal') {
//                 headState.horizontalChain = { members, style, bias };
//             } else {
//                 headState.verticalChain = { members, style, bias };
//             }
//         }
//     }

//     collectChainMembers(headId, children, orientation) {
//         const members = [];
//         let currentId = headId;
//         const visited = new Set();
//         const isHorizontal = orientation === 'horizontal';

//         while (currentId && !visited.has(currentId)) {
//             visited.add(currentId);
//             const node = children.find(c => this.helper.getId(c) === currentId);
//             if (!node) break;

//             const state = this.solver.nodeMap.get(currentId);
//             members.push({ id: currentId, node, state });

//             let next = null;
//             let nextIdAttr;

//             if (isHorizontal) {
//                 nextIdAttr = this.helper.getAttr(node.attributes, 'layout_constraintEnd_toStartOf') ||
//                             this.helper.getAttr(node.attributes, 'layout_constraintRight_toLeftOf');
//             } else {
//                 nextIdAttr = this.helper.getAttr(node.attributes, 'layout_constraintBottom_toTopOf');
//             }

//             if (nextIdAttr) {
//                 const potentialNextId = nextIdAttr.replace(/@\+?id\//, '');
//                 const nextNode = children.find(c => this.helper.getId(c) === potentialNextId);

//                 if (nextNode) {
//                     let prevIdAttr;
//                     if (isHorizontal) {
//                         prevIdAttr = this.helper.getAttr(nextNode.attributes, 'layout_constraintStart_toEndOf') ||
//                                     this.helper.getAttr(nextNode.attributes, 'layout_constraintLeft_toRightOf');
//                     } else {
//                         prevIdAttr = this.helper.getAttr(nextNode.attributes, 'layout_constraintTop_toBottomOf');
//                     }

//                     if (prevIdAttr && prevIdAttr.includes(currentId)) {
//                         next = potentialNextId;
//                     }
//                 }
//             }
//             currentId = next;
//         }
        
//         return members;
//     }

//     solveChainHorizontal(headState) {
//         if (!headState.horizontalChain) return;
//         const { members, style, bias } = headState.horizontalChain;
//         this.distributeChain(members, style, bias, 'horizontal');
//     }

//     solveChainVertical(headState) {
//         if (!headState.verticalChain) return;
//         const { members, style, bias } = headState.verticalChain;
//         this.distributeChain(members, style, bias, 'vertical');
//     }

//     distributeChain(members, style, bias, orientation) {
//         const visibleMembers = members.filter(m => this.helper.getAttr(m.node.attributes, 'visibility') !== 'gone');
//         if (visibleMembers.length === 0) return;

//         const isHorizontal = orientation === 'horizontal';
        
//         console.log('isHorizontal :::',isHorizontal);
//         console.log('this.solver.isRTL :::',this.solver.isRTL);
        
//         // RTL Bias Inversion Logic
//         if (isHorizontal && this.solver.isRTL) {
//             bias = 1.0 - bias;
//             console.log('after substracting 1.0 - bias ::::',bias);
//         }

//         const headNode = members[0].node;
//         const tailNode = members[members.length - 1].node;

//         let startAnchor = 0;
//         let endAnchor = isHorizontal ? this.solver.parentW : this.solver.parentH;

//         // Find Start Anchor Position
//         if (isHorizontal) {
//             const startToStart = this.helper.getAttr(headNode.attributes, 'layout_constraintStart_toStartOf');
//             const startToEnd = this.helper.getAttr(headNode.attributes, 'layout_constraintStart_toEndOf');
            
//             if (startToStart) {
//                 const t = startToStart.replace(/@\+?id\//, '');
//                 startAnchor = (t === 'parent') ? this.solver.padding.left : this.solver.getPos(t, 'left');
//             } else if (startToEnd) {
//                 const t = startToEnd.replace(/@\+?id\//, '');
//                 startAnchor = this.solver.getPos(t, 'right');
//             }

//             const endToEnd = this.helper.getAttr(tailNode.attributes, 'layout_constraintEnd_toEndOf');
//             const endToStart = this.helper.getAttr(tailNode.attributes, 'layout_constraintEnd_toStartOf');
            
//             if (endToEnd) {
//                 const t = endToEnd.replace(/@\+?id\//, '');
//                 endAnchor = (t === 'parent') ? (this.solver.parentW - this.solver.padding.right) : this.solver.getPos(t, 'right');
//             } else if (endToStart) {
//                 const t = endToStart.replace(/@\+?id\//, '');
//                 endAnchor = this.solver.getPos(t, 'left');
//             }
//         } else {
//             const topToTop = this.helper.getAttr(headNode.attributes, 'layout_constraintTop_toTopOf');
//             const topToBottom = this.helper.getAttr(headNode.attributes, 'layout_constraintTop_toBottomOf');
            
//             if (topToTop) {
//                 const t = topToTop.replace(/@\+?id\//, '');
//                 startAnchor = (t === 'parent') ? this.solver.padding.top : this.solver.getPos(t, 'top');
//             } else if (topToBottom) {
//                 const t = topToBottom.replace(/@\+?id\//, '');
//                 startAnchor = this.solver.getPos(t, 'bottom');
//             }

//             const bottomToBottom = this.helper.getAttr(tailNode.attributes, 'layout_constraintBottom_toBottomOf');
//             const bottomToTop = this.helper.getAttr(tailNode.attributes, 'layout_constraintBottom_toTopOf');
            
//             if (bottomToBottom) {
//                 const t = bottomToBottom.replace(/@\+?id\//, '');
//                 endAnchor = (t === 'parent') ? (this.solver.parentH - this.solver.padding.bottom) : this.solver.getPos(t, 'bottom');
//             } else if (bottomToTop) {
//                 const t = bottomToTop.replace(/@\+?id\//, '');
//                 endAnchor = this.solver.getPos(t, 'top');
//             }
//         }

//         startAnchor += this.helper.parsePx(this.helper.getAttr(headNode.attributes, isHorizontal ? 'layout_marginStart' : 'layout_marginTop'));
//         endAnchor -= this.helper.parsePx(this.helper.getAttr(tailNode.attributes, isHorizontal ? 'layout_marginEnd' : 'layout_marginBottom'));

//         let totalFixedSize = 0;
//         let weightedMembers = [];

//         visibleMembers.forEach((m, i) => {
//             let m1 = 0, m2 = 0;
//             if (i > 0) {
//                 m1 = this.helper.parsePx(this.helper.getAttr(m.node.attributes, isHorizontal ? 'layout_marginStart' : 'layout_marginTop'));
//             }
//             if (i < visibleMembers.length - 1) {
//                 m2 = this.helper.parsePx(this.helper.getAttr(m.node.attributes, isHorizontal ? 'layout_marginEnd' : 'layout_marginBottom'));
//             }

//             const sizeAttr = this.helper.getAttr(m.node.attributes, isHorizontal ? 'layout_width' : 'layout_height');
//             if (sizeAttr === '0dp' || sizeAttr === 'match_constraint') {
//                 weightedMembers.push(m);
//                 totalFixedSize += m1 + m2;
//             } else {
//                 const currentSize = isHorizontal ? m.state.w : m.state.h;
//                 totalFixedSize += currentSize + m1 + m2;
//             }
//         });

//         const availableSpace = endAnchor - startAnchor;
//         const remainingSpace = Math.max(0, availableSpace - totalFixedSize);

//         if (weightedMembers.length > 0) {
//             const sizePerNode = remainingSpace / weightedMembers.length;
//             weightedMembers.forEach(m => {
//                 if (isHorizontal) m.state.w = sizePerNode;
//                 else m.state.h = sizePerNode;
//             });
//         }

//         let currentPos = startAnchor;
//         let gap = 0;

//         if (weightedMembers.length === 0) {
//             if (style === 'spread') {
//                 gap = remainingSpace / (visibleMembers.length + 1);
//                 currentPos += gap;
//             } else if (style === 'spread_inside') {
//                 gap = remainingSpace / (visibleMembers.length - 1);
//             } else if (style === 'packed') {
//                 gap = 0;
//                 currentPos += remainingSpace * bias;
//             }
//         }

//         visibleMembers.forEach((m, i) => {
//             if (i > 0) {
//                 currentPos += this.helper.parsePx(this.helper.getAttr(m.node.attributes, isHorizontal ? 'layout_marginStart' : 'layout_marginTop'));
//             }

//             const snappedPos = Math.round(currentPos);
//             if (isHorizontal) {
//                 m.state.x = snappedPos;
//                 m.state.alignment = 'start'; 
//             } else {
//                 m.state.y = snappedPos;
//                 m.state.solvedY = true;
//             }

//             const size = isHorizontal ? m.state.w : m.state.h;
//             currentPos += size;

//             if (i < visibleMembers.length - 1) {
//                 currentPos += this.helper.parsePx(this.helper.getAttr(m.node.attributes, isHorizontal ? 'layout_marginEnd' : 'layout_marginBottom'));
//             }

//             if (style === 'spread') currentPos += gap;
//             else if (style === 'spread_inside' && i < visibleMembers.length - 1) currentPos += gap;
//         });
//     }
// }


// rtl fix 
// export class ChainSolver {
//     constructor(solver) {
//         this.solver = solver;
//         this.helper = solver.helper;
//     }

//     detectChains(children) {
//         const processedH = new Set();
//         const processedV = new Set();

//         children.forEach(node => {
//             const id = this.helper.getId(node);
//             if (!id) return;

//             if (!processedH.has(id)) {
//                 this.detectChain(id, children, 'horizontal', processedH);
//             }
//             if (!processedV.has(id)) {
//                 this.detectChain(id, children, 'vertical', processedV);
//             }
//         });
//     }

//     detectChain(headId, children, orientation, processedSet) {
//         const members = this.collectChainMembers(headId, children, orientation);
//         if (members.length < 2) return;

//         const headNode = members[0].node;
//         const tailNode = members[members.length - 1].node;
//         const headAttr = headNode.attributes;
//         const tailAttr = tailNode.attributes;

//         let headHasAnchor, tailHasAnchor;

//         if (orientation === 'horizontal') {
//             headHasAnchor =
//                 this.helper.getAttr(headAttr, 'layout_constraintStart_toStartOf') ||
//                 this.helper.getAttr(headAttr, 'layout_constraintStart_toEndOf') ||
//                 this.helper.getAttr(headAttr, 'layout_constraintLeft_toLeftOf');

//             tailHasAnchor =
//                 this.helper.getAttr(tailAttr, 'layout_constraintEnd_toEndOf') ||
//                 this.helper.getAttr(tailAttr, 'layout_constraintEnd_toStartOf') ||
//                 this.helper.getAttr(tailAttr, 'layout_constraintRight_toRightOf');
//         } else {
//             headHasAnchor =
//                 this.helper.getAttr(headAttr, 'layout_constraintTop_toTopOf') ||
//                 this.helper.getAttr(headAttr, 'layout_constraintTop_toBottomOf');

//             tailHasAnchor =
//                 this.helper.getAttr(tailAttr, 'layout_constraintBottom_toBottomOf') ||
//                 this.helper.getAttr(tailAttr, 'layout_constraintBottom_toTopOf');
//         }

//         if (headHasAnchor && tailHasAnchor) {
//             const styleAttr = orientation === 'horizontal' ? 'layout_constraintHorizontal_chainStyle' : 'layout_constraintVertical_chainStyle';
//             const biasAttr = orientation === 'horizontal' ? 'layout_constraintHorizontal_bias' : 'layout_constraintVertical_bias';

//             const style = this.helper.getAttr(headAttr, styleAttr) || 'spread';
//             const bias = parseFloat(this.helper.getAttr(headAttr, biasAttr) || '0.5');

//             members.forEach(m => {
//                 const state = this.solver.nodeMap.get(m.id);
//                 if (orientation === 'horizontal') state.inHorizontalChain = true;
//                 else state.inVerticalChain = true;
//                 processedSet.add(m.id);
//             });

//             const headState = this.solver.nodeMap.get(members[0].id);
//             if (orientation === 'horizontal') {
//                 headState.horizontalChain = { members, style, bias };
//             } else {
//                 headState.verticalChain = { members, style, bias };
//             }
//         }
//     }

//     collectChainMembers(headId, children, orientation) {
//         const members = [];
//         let currentId = headId;
//         const visited = new Set();
//         const isHorizontal = orientation === 'horizontal';

//         while (currentId && !visited.has(currentId)) {
//             visited.add(currentId);
//             const node = children.find(c => this.helper.getId(c) === currentId);
//             if (!node) break;

//             const state = this.solver.nodeMap.get(currentId);
//             members.push({ id: currentId, node, state });

//             let next = null;
//             let nextIdAttr;

//             if (isHorizontal) {
//                 nextIdAttr = this.helper.getAttr(node.attributes, 'layout_constraintEnd_toStartOf') ||
//                             this.helper.getAttr(node.attributes, 'layout_constraintRight_toLeftOf');
//             } else {
//                 nextIdAttr = this.helper.getAttr(node.attributes, 'layout_constraintBottom_toTopOf');
//             }

//             if (nextIdAttr) {
//                 const potentialNextId = nextIdAttr.replace(/@\+?id\//, '');
//                 const nextNode = children.find(c => this.helper.getId(c) === potentialNextId);

//                 if (nextNode) {
//                     let prevIdAttr;
//                     if (isHorizontal) {
//                         prevIdAttr = this.helper.getAttr(nextNode.attributes, 'layout_constraintStart_toEndOf') ||
//                                     this.helper.getAttr(nextNode.attributes, 'layout_constraintLeft_toRightOf');
//                     } else {
//                         prevIdAttr = this.helper.getAttr(nextNode.attributes, 'layout_constraintTop_toBottomOf');
//                     }

//                     if (prevIdAttr && prevIdAttr.includes(currentId)) {
//                         next = potentialNextId;
//                     }
//                 }
//             }
//             currentId = next;
//         }
//         return members;
//     }

//     solveChainHorizontal(headState) {
//         if (!headState.horizontalChain) return;
//         const { members, style, bias } = headState.horizontalChain;
//         this.distributeChain(members, style, bias, 'horizontal');
//     }

//     solveChainVertical(headState) {
//         if (!headState.verticalChain) return;
//         const { members, style, bias } = headState.verticalChain;
//         this.distributeChain(members, style, bias, 'vertical');
//     }

//     distributeChain(members, style, bias, orientation) {
//         let visibleMembers = members.filter(m => this.helper.getAttr(m.node.attributes, 'visibility') !== 'gone');
//         if (visibleMembers.length === 0) return;

//         const isHorizontal = orientation === 'horizontal';
        
//         // 🔥 FIX 1: RTL Logic (Reverse Order + Invert Bias)
//         if (isHorizontal && this.solver.isRTL) {
//             visibleMembers = visibleMembers.reverse(); // RTL means Right-to-Left order
//             bias = 1.0 - bias; // Invert bias
//         }

//         // Note: Anchor logic still needs to find min/max boundaries correctly
//         // For simplicity, assuming anchors are correctly set at layout edges
//         // In a real engine, we'd swap startAnchor/endAnchor logic based on RTL too
        
//         // However, since we reversed the members, 'startAnchor' is now logically the 'right' edge in RTL
//         // But physically, we calculate positions from Left (0) to Right (W) in CSS
//         // So we keep the calculation LTR-based but with swapped members and bias.

//         const headNode = members[0].node; // Original Head (Leftmost in LTR)
//         const tailNode = members[members.length - 1].node; // Original Tail (Rightmost in LTR)

//         // Standard LTR Anchor Calculation (Physical Coordinates)
//         let startAnchor = 0;
//         let endAnchor = isHorizontal ? this.solver.parentW : this.solver.parentH;

//         if (isHorizontal) {
//             const startToStart = this.helper.getAttr(headNode.attributes, 'layout_constraintStart_toStartOf');
//             const startToEnd = this.helper.getAttr(headNode.attributes, 'layout_constraintStart_toEndOf');
            
//             if (startToStart) {
//                 const t = startToStart.replace(/@\+?id\//, '');
//                 startAnchor = (t === 'parent') ? this.solver.padding.left : this.solver.getPos(t, 'left');
//             } else if (startToEnd) {
//                 const t = startToEnd.replace(/@\+?id\//, '');
//                 startAnchor = this.solver.getPos(t, 'right');
//             }

//             const endToEnd = this.helper.getAttr(tailNode.attributes, 'layout_constraintEnd_toEndOf');
//             const endToStart = this.helper.getAttr(tailNode.attributes, 'layout_constraintEnd_toStartOf');
            
//             if (endToEnd) {
//                 const t = endToEnd.replace(/@\+?id\//, '');
//                 endAnchor = (t === 'parent') ? (this.solver.parentW - this.solver.padding.right) : this.solver.getPos(t, 'right');
//             } else if (endToStart) {
//                 const t = endToStart.replace(/@\+?id\//, '');
//                 endAnchor = this.solver.getPos(t, 'left');
//             }
//         } else {
//             // Vertical Anchors (Same as before)
//             const topToTop = this.helper.getAttr(headNode.attributes, 'layout_constraintTop_toTopOf');
//             const topToBottom = this.helper.getAttr(headNode.attributes, 'layout_constraintTop_toBottomOf');
            
//             if (topToTop) {
//                 const t = topToTop.replace(/@\+?id\//, '');
//                 startAnchor = (t === 'parent') ? this.solver.padding.top : this.solver.getPos(t, 'top');
//             } else if (topToBottom) {
//                 const t = topToBottom.replace(/@\+?id\//, '');
//                 startAnchor = this.solver.getPos(t, 'bottom');
//             }

//             const bottomToBottom = this.helper.getAttr(tailNode.attributes, 'layout_constraintBottom_toBottomOf');
//             const bottomToTop = this.helper.getAttr(tailNode.attributes, 'layout_constraintBottom_toTopOf');
            
//             if (bottomToBottom) {
//                 const t = bottomToBottom.replace(/@\+?id\//, '');
//                 endAnchor = (t === 'parent') ? (this.solver.parentH - this.solver.padding.bottom) : this.solver.getPos(t, 'bottom');
//             } else if (bottomToTop) {
//                 const t = bottomToTop.replace(/@\+?id\//, '');
//                 endAnchor = this.solver.getPos(t, 'top');
//             }
//         }

//         // Apply Margins
//         startAnchor += this.helper.parsePx(this.helper.getAttr(headNode.attributes, isHorizontal ? 'layout_marginStart' : 'layout_marginTop'));
//         endAnchor -= this.helper.parsePx(this.helper.getAttr(tailNode.attributes, isHorizontal ? 'layout_marginEnd' : 'layout_marginBottom'));

//         let totalFixedSize = 0;
//         let weightedMembers = [];

//         // 1. Calculate Sizes
//         visibleMembers.forEach((m, i) => {
//             let m1 = 0, m2 = 0;
//             if (i > 0) {
//                 m1 = this.helper.parsePx(this.helper.getAttr(m.node.attributes, isHorizontal ? 'layout_marginStart' : 'layout_marginTop'));
//             }
//             if (i < visibleMembers.length - 1) {
//                 m2 = this.helper.parsePx(this.helper.getAttr(m.node.attributes, isHorizontal ? 'layout_marginEnd' : 'layout_marginBottom'));
//             }

//             const sizeAttr = this.helper.getAttr(m.node.attributes, isHorizontal ? 'layout_width' : 'layout_height');
//             if (sizeAttr === '0dp' || sizeAttr === 'match_constraint') {
//                 weightedMembers.push(m);
//                 totalFixedSize += m1 + m2;
//             } else {
//                 const currentSize = isHorizontal ? m.state.w : m.state.h;
//                 totalFixedSize += currentSize + m1 + m2;
//             }
//         });

//         const availableSpace = endAnchor - startAnchor;
//         const remainingSpace = Math.max(0, availableSpace - totalFixedSize);

//         if (weightedMembers.length > 0) {
//             const sizePerNode = remainingSpace / weightedMembers.length;
//             weightedMembers.forEach(m => {
//                 if (isHorizontal) m.state.w = sizePerNode;
//                 else m.state.h = sizePerNode;
//             });
//         }

//         let currentPos = startAnchor;
//         let gap = 0;

//         if (weightedMembers.length === 0) {
//             if (style === 'spread') {
//                 gap = remainingSpace / (visibleMembers.length + 1);
//                 currentPos += gap;
//             } else if (style === 'spread_inside') {
//                 gap = remainingSpace / (visibleMembers.length - 1);
//             } else if (style === 'packed') {
//                 gap = 0;
//                 currentPos += remainingSpace * bias;
//             }
//         }

//         // 5. Apply Positions (Standard Loop)
//         // Since we reversed 'visibleMembers' for RTL, this loop will place:
//         // RTL: Item3 -> Item2 -> Item1 (Left to Right physically)
//         // Which visually looks like Item1 <- Item2 <- Item3
//         visibleMembers.forEach((m, i) => {
//             if (i > 0) {
//                 currentPos += this.helper.parsePx(this.helper.getAttr(m.node.attributes, isHorizontal ? 'layout_marginStart' : 'layout_marginTop'));
//             }

//             const snappedPos = Math.round(currentPos);
//             if (isHorizontal) {
//                 m.state.x = snappedPos;
//                 m.state.alignment = 'start'; 
//             } else {
//                 m.state.y = snappedPos;
//                 m.state.solvedY = true;
//             }

//             const size = isHorizontal ? m.state.w : m.state.h;
//             currentPos += size;

//             if (i < visibleMembers.length - 1) {
//                 currentPos += this.helper.parsePx(this.helper.getAttr(m.node.attributes, isHorizontal ? 'layout_marginEnd' : 'layout_marginBottom'));
//             }

//             if (style === 'spread') currentPos += gap;
//             else if (style === 'spread_inside' && i < visibleMembers.length - 1) currentPos += gap;
//         });
//     }
// }




export class ChainSolver {
    constructor(solver) {
        this.solver = solver;
        this.helper = solver.helper;
    }

    detectChains(children) {
        const processedH = new Set();
        const processedV = new Set();

        children.forEach(node => {
            const id = this.helper.getId(node);
            if (!id) return;

            if (!processedH.has(id)) {
                this.detectChain(id, children, 'horizontal', processedH);
            }
            if (!processedV.has(id)) {
                this.detectChain(id, children, 'vertical', processedV);
            }
        });
    }

    detectChain(headId, children, orientation, processedSet) {
        const members = this.collectChainMembers(headId, children, orientation);
        if (members.length < 2) return;

        const headNode = members[0].node;
        const tailNode = members[members.length - 1].node;
        const headAttr = headNode.attributes;
        const tailAttr = tailNode.attributes;

        let headHasAnchor, tailHasAnchor;

        if (orientation === 'horizontal') {
            headHasAnchor =
                this.helper.getAttr(headAttr, 'layout_constraintStart_toStartOf') ||
                this.helper.getAttr(headAttr, 'layout_constraintStart_toEndOf') ||
                this.helper.getAttr(headAttr, 'layout_constraintLeft_toLeftOf');

            tailHasAnchor =
                this.helper.getAttr(tailAttr, 'layout_constraintEnd_toEndOf') ||
                this.helper.getAttr(tailAttr, 'layout_constraintEnd_toStartOf') ||
                this.helper.getAttr(tailAttr, 'layout_constraintRight_toRightOf');
        } else {
            headHasAnchor =
                this.helper.getAttr(headAttr, 'layout_constraintTop_toTopOf') ||
                this.helper.getAttr(headAttr, 'layout_constraintTop_toBottomOf');

            tailHasAnchor =
                this.helper.getAttr(tailAttr, 'layout_constraintBottom_toBottomOf') ||
                this.helper.getAttr(tailAttr, 'layout_constraintBottom_toTopOf');
        }

        if (headHasAnchor && tailHasAnchor) {
            const styleAttr = orientation === 'horizontal' ? 'layout_constraintHorizontal_chainStyle' : 'layout_constraintVertical_chainStyle';
            const biasAttr = orientation === 'horizontal' ? 'layout_constraintHorizontal_bias' : 'layout_constraintVertical_bias';

            const style = this.helper.getAttr(headAttr, styleAttr) || 'spread';
            const bias = parseFloat(this.helper.getAttr(headAttr, biasAttr) || '0.5');

            members.forEach(m => {
                const state = this.solver.nodeMap.get(m.id);
                if (orientation === 'horizontal') state.inHorizontalChain = true;
                else state.inVerticalChain = true;
                processedSet.add(m.id);
            });

            const headState = this.solver.nodeMap.get(members[0].id);
            if (orientation === 'horizontal') {
                headState.horizontalChain = { members, style, bias };
            } else {
                headState.verticalChain = { members, style, bias };
            }
        }
    }

    collectChainMembers(headId, children, orientation) {
        const members = [];
        let currentId = headId;
        const visited = new Set();
        const isHorizontal = orientation === 'horizontal';

        while (currentId && !visited.has(currentId)) {
            visited.add(currentId);
            const node = children.find(c => this.helper.getId(c) === currentId);
            if (!node) break;

            const state = this.solver.nodeMap.get(currentId);
            members.push({ id: currentId, node, state });

            let next = null;
            let nextIdAttr;

            if (isHorizontal) {
                nextIdAttr = this.helper.getAttr(node.attributes, 'layout_constraintEnd_toStartOf') ||
                             this.helper.getAttr(node.attributes, 'layout_constraintRight_toLeftOf');
            } else {
                nextIdAttr = this.helper.getAttr(node.attributes, 'layout_constraintBottom_toTopOf');
            }

            if (nextIdAttr) {
                const potentialNextId = nextIdAttr.replace(/@\+?id\//, '');
                const nextNode = children.find(c => this.helper.getId(c) === potentialNextId);

                if (nextNode) {
                    let prevIdAttr;
                    if (isHorizontal) {
                        prevIdAttr = this.helper.getAttr(nextNode.attributes, 'layout_constraintStart_toEndOf') ||
                                     this.helper.getAttr(nextNode.attributes, 'layout_constraintLeft_toRightOf');
                    } else {
                        prevIdAttr = this.helper.getAttr(nextNode.attributes, 'layout_constraintTop_toBottomOf');
                    }

                    if (prevIdAttr && prevIdAttr.includes(currentId)) {
                        next = potentialNextId;
                    }
                }
            }
            currentId = next;
        }
        return members;
    }

    solveChainHorizontal(headState) {
        if (!headState.horizontalChain) return;
        const { members, style, bias } = headState.horizontalChain;
        this.distributeChain(members, style, bias, 'horizontal');
    }

    solveChainVertical(headState) {
        if (!headState.verticalChain) return;
        const { members, style, bias } = headState.verticalChain;
        this.distributeChain(members, style, bias, 'vertical');
    }

    distributeChain(members, style, bias, orientation) {
        let visibleMembers = members.filter(m => this.helper.getAttr(m.node.attributes, 'visibility') !== 'gone');
        if (visibleMembers.length === 0) return;

        const isHorizontal = orientation === 'horizontal';
        
        // RTL Support (Reverse list, Invert Bias)
        if (isHorizontal && this.solver.isRTL) {
            visibleMembers = visibleMembers.reverse();
            bias = 1.0 - bias;
        }

        const headNode = members[0].node;
        const tailNode = members[members.length - 1].node;

        // 1. Anchor Calculation
        let startAnchor = 0;
        let endAnchor = isHorizontal ? this.solver.parentW : this.solver.parentH;

        if (isHorizontal) {
            const startToStart = this.helper.getAttr(headNode.attributes, 'layout_constraintStart_toStartOf');
            const startToEnd = this.helper.getAttr(headNode.attributes, 'layout_constraintStart_toEndOf');
            
            if (startToStart) {
                const t = startToStart.replace(/@\+?id\//, '');
                startAnchor = (t === 'parent') ? this.solver.padding.left : this.solver.getPos(t, 'left');
            } else if (startToEnd) {
                const t = startToEnd.replace(/@\+?id\//, '');
                startAnchor = this.solver.getPos(t, 'right');
            }

            const endToEnd = this.helper.getAttr(tailNode.attributes, 'layout_constraintEnd_toEndOf');
            const endToStart = this.helper.getAttr(tailNode.attributes, 'layout_constraintEnd_toStartOf');
            
            if (endToEnd) {
                const t = endToEnd.replace(/@\+?id\//, '');
                endAnchor = (t === 'parent') ? (this.solver.parentW - this.solver.padding.right) : this.solver.getPos(t, 'right');
            } else if (endToStart) {
                const t = endToStart.replace(/@\+?id\//, '');
                endAnchor = this.solver.getPos(t, 'left');
            }
        } else {
            const topToTop = this.helper.getAttr(headNode.attributes, 'layout_constraintTop_toTopOf');
            const topToBottom = this.helper.getAttr(headNode.attributes, 'layout_constraintTop_toBottomOf');
            
            if (topToTop) {
                const t = topToTop.replace(/@\+?id\//, '');
                startAnchor = (t === 'parent') ? this.solver.padding.top : this.solver.getPos(t, 'top');
            } else if (topToBottom) {
                const t = topToBottom.replace(/@\+?id\//, '');
                startAnchor = this.solver.getPos(t, 'bottom');
            }

            const bottomToBottom = this.helper.getAttr(tailNode.attributes, 'layout_constraintBottom_toBottomOf');
            const bottomToTop = this.helper.getAttr(tailNode.attributes, 'layout_constraintBottom_toTopOf');
            
            if (bottomToBottom) {
                const t = bottomToBottom.replace(/@\+?id\//, '');
                endAnchor = (t === 'parent') ? (this.solver.parentH - this.solver.padding.bottom) : this.solver.getPos(t, 'bottom');
            } else if (bottomToTop) {
                const t = bottomToTop.replace(/@\+?id\//, '');
                endAnchor = this.solver.getPos(t, 'top');
            }
        }

        // Apply Head/Tail Margins
        startAnchor += this.helper.parsePx(this.helper.getAttr(headNode.attributes, isHorizontal ? 'layout_marginStart' : 'layout_marginTop'));
        endAnchor -= this.helper.parsePx(this.helper.getAttr(tailNode.attributes, isHorizontal ? 'layout_marginEnd' : 'layout_marginBottom'));

        let totalFixedSize = 0;
        let weightedMembers = [];
        
        // 🔥 FIX: Weight Calculation Variables
        let totalWeight = 0;
        let useWeights = false;

        // 2. Size Calculation Loop
        visibleMembers.forEach((m, i) => {
            let m1 = 0, m2 = 0;
            if (i > 0) {
                m1 = this.helper.parsePx(this.helper.getAttr(m.node.attributes, isHorizontal ? 'layout_marginStart' : 'layout_marginTop'));
            }
            if (i < visibleMembers.length - 1) {
                m2 = this.helper.parsePx(this.helper.getAttr(m.node.attributes, isHorizontal ? 'layout_marginEnd' : 'layout_marginBottom'));
            }

            const sizeAttr = this.helper.getAttr(m.node.attributes, isHorizontal ? 'layout_width' : 'layout_height');
            
            // Check for match_constraint (0dp)
            if (sizeAttr === '0dp' || sizeAttr === 'match_constraint') {
                weightedMembers.push(m);
                totalFixedSize += m1 + m2;

                // 🔥 Check for weight attribute
                const weightAttr = isHorizontal ? 'layout_constraintHorizontal_weight' : 'layout_constraintVertical_weight';
                const weight = parseFloat(this.helper.getAttr(m.node.attributes, weightAttr) || '0');
                
                m.weight = weight; // Store temporarily
                if (weight > 0) {
                    totalWeight += weight;
                    useWeights = true;
                }
            } else {
                const currentSize = isHorizontal ? m.state.w : m.state.h;
                totalFixedSize += currentSize + m1 + m2;
            }
        });

        const availableSpace = endAnchor - startAnchor;
        const remainingSpace = Math.max(0, availableSpace - totalFixedSize);

        // 3. Apply Sizes (Weighted vs Spread)
        if (weightedMembers.length > 0) {
            if (useWeights && totalWeight > 0) {
                // 🔥 Weighted Distribution
                weightedMembers.forEach(m => {
                    const share = (m.weight / totalWeight) * remainingSpace;
                    if (isHorizontal) m.state.w = share;
                    else m.state.h = share;
                });
            } else {
                // ⚖️ Spread Distribution (Default for 0dp with no weight)
                const sizePerNode = remainingSpace / weightedMembers.length;
                weightedMembers.forEach(m => {
                    if (isHorizontal) m.state.w = sizePerNode;
                    else m.state.h = sizePerNode;
                });
            }
        }

        // 4. Positioning Logic
        let currentPos = startAnchor;
        let gap = 0;

        // Gap শুধুমাত্র তখনই দরকার যখন কোনো 0dp মেম্বার নেই (সব ফিক্সড সাইজ)
        // অথবা সব 0dp মেম্বারকে সাইজ দিয়ে দেওয়া হয়েছে (Weighted/Spread)
        if (weightedMembers.length === 0) {
            if (style === 'spread') {
                gap = remainingSpace / (visibleMembers.length + 1);
                currentPos += gap;
            } else if (style === 'spread_inside') {
                gap = remainingSpace / (visibleMembers.length - 1);
            } else if (style === 'packed') {
                gap = 0;
                currentPos += remainingSpace * bias;
            }
        }

        // 5. Apply Final Positions
        visibleMembers.forEach((m, i) => {
            if (i > 0) {
                currentPos += this.helper.parsePx(this.helper.getAttr(m.node.attributes, isHorizontal ? 'layout_marginStart' : 'layout_marginTop'));
            }

            const snappedPos = Math.round(currentPos);
            if (isHorizontal) {
                m.state.x = snappedPos;
                m.state.alignment = 'start'; 
            } else {
                m.state.y = snappedPos;
                m.state.solvedY = true;
            }

            const size = isHorizontal ? m.state.w : m.state.h;
            currentPos += size;

            if (i < visibleMembers.length - 1) {
                currentPos += this.helper.parsePx(this.helper.getAttr(m.node.attributes, isHorizontal ? 'layout_marginEnd' : 'layout_marginBottom'));
            }

            // Gap অ্যাপ্লাই করুন যদি আমরা Flexible Mode এ না থাকি
            if (weightedMembers.length === 0) {
                if (style === 'spread') currentPos += gap;
                else if (style === 'spread_inside' && i < visibleMembers.length - 1) currentPos += gap;
            }
        });
    }
}