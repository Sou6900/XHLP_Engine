import html2canvas from 'html2canvas';
import { svgs } from '../../assets/icons/svg/svg.js';
import { DeviceConfig } from '../device/DeviceConfig.js';

export class ToolbarControls {
    constructor(uiInstance) {
        this.ui = uiInstance;
        
        // 🔥 LOAD STATE FROM LOCALSTORAGE
        this.scale = parseFloat(localStorage.getItem('aid_preview_scale')) || 0.8;
        
        const savedRuler = localStorage.getItem('aid_preview_ruler');
        this.showRulers = savedRuler !== null ? savedRuler === 'true' : true; 

        this.showGrid = localStorage.getItem('aid_preview_grid') === 'true';

        this.isDark = localStorage.getItem('aid_preview_theme') === 'true';
        this.orientation = localStorage.getItem('aid_preview_orientation') || 'portrait';
        
        // 🔥 Blueprint Mode State load
        this.showBlueprint = localStorage.getItem('aid_preview_blueprint') === 'true';
        
        this.themeBtn = null;
        this.menuOpen = false;
        
        // Will be assigned by LayoutPreviewUI
        this.blueprintRenderer = null;
    }

    render() {
        const themeIcon = this.isDark ? svgs.day : svgs.night;
        
        // Use icons from svgs object
        const minusIcon = svgs.minus;
        const plusIcon = svgs.plus;
        const menuIcon = svgs.menuIcon; // Hamburger for drawer
        const moreIcon = svgs.moreIcon || svgs.more; // Kebab for toolbar menu
        const rotateIcon = svgs.rotateIcon || svgs.rotate; 
        const deviceIcon = svgs.deviceIcon || svgs.phone;
        const screenshotIcon = svgs.screenshotIcon || svgs.image;
        const exportIcon = svgs.exportIcon || svgs.upload || svgs.export;
        const settingsIcon = svgs.settingsIcon;
        const gridIcon = svgs.gridIcon || svgs.grid;
        const refreshIcon = svgs.refreshIcon;
        const copyIcon = svgs.copy || svgs.content_copy;
        const helpIcon = svgs.help || svgs.info;
        const rulerIcon = svgs.rulerIcon || svgs.ruler || '<svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor"><path d="M16 6l2.29 2.29-4.88 4.88-4-4L2 16.59 3.41 18l6-6 4 4 6.3-6.29L22 12V6z"/></svg>';
        
        // Blueprint Icon
        const blueprintIcon = '<svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor"><path d="M3 5v14h18V5H3zm16 12H5V7h14v10zm-4-9h-2v2h2V8zm-4 4h-2v2h2v-2z"/></svg>';

        return `
            <div class="toolbar-group" style="display:flex; gap:6px; align-items:center; position: relative; color: var(--primary-text-color);">
                <!-- Menu Button -->
                <button id="btn-menu" class="aid-icon-btn" title="Menu (More Options)" 
                    style="border:none; background:transparent; cursor:pointer; padding:6px; border-radius:4px; display:flex; align-items:center; justify-content:center; color:var(--primary-text-color);">
                    ${moreIcon}
                </button>

                <!-- Dropdown Menu -->
                <div id="toolbar-menu" style="
                    display: none;
                    position: absolute;
                    top: 100%;
                    left: 0;
                    margin-top: 4px;
                    background: var(--popup-background-color);
                    border: 1px solid var(--popup-border-color);
                    border-radius: 6px;
                    box-shadow: 0 4px 12px var(--box-shadow-color);
                    min-width: 220px;
                    z-index: 10000;
                    overflow: hidden;
                    color: var(--popup-text-color);
                ">
                    <div style="padding: 8px 12px; border-bottom: 1px solid var(--border-color); font-size: 11px; color: var(--secondary-text-color); font-weight: 600; text-transform: uppercase;">
                        Device
                    </div>
                    <div class="menu-item" data-action="device-pixel5" style="padding: 8px 12px; cursor: pointer; font-size: 13px; display: flex; align-items: center; gap: 8px;">
                        <div style="width:18px;height:18px;fill:var(--popup-icon-color);">${deviceIcon}</div>
                        <span>Pixel 5 (393 × 851)</span>
                    </div>
                    <div class="menu-item" data-action="device-pixel7" style="padding: 8px 12px; cursor: pointer; font-size: 13px; display: flex; align-items: center; gap: 8px;">
                        <div style="width:18px;height:18px;fill:var(--popup-icon-color);">${deviceIcon}</div>
                        <span>Pixel 7 (412 × 915)</span>
                    </div>
                    
                    <div style="height: 1px; background: var(--border-color); margin: 4px 0;"></div>
                    
                    <!-- View Options -->
                    <div style="padding: 8px 12px; border-bottom: 1px solid var(--border-color); font-size: 11px; color: var(--secondary-text-color); font-weight: 600; text-transform: uppercase;">
                        View
                    </div>
                    <div class="menu-item" data-action="rotate" style="padding: 8px 12px; cursor: pointer; font-size: 13px; display: flex; align-items: center; gap: 8px;">
                        <div style="width:18px;height:18px;fill:var(--popup-icon-color);">${rotateIcon}</div>
                        <span>Rotate Device</span>
                        <span style="margin-left: auto; font-size: 11px; color: var(--secondary-text-color);">Ctrl+R</span>
                    </div>
                    <div class="menu-item" data-action="toggle-grid" style="padding: 8px 12px; cursor: pointer; font-size: 13px; display: flex; align-items: center; gap: 8px;">
                        <div style="width:18px;height:18px;fill:var(--popup-icon-color);">${gridIcon}</div>
                        <span>Show Grid</span>
                    </div>
                    <div class="menu-item" data-action="toggle-rulers" style="padding: 8px 12px; cursor: pointer; font-size: 13px; display: flex; align-items: center; gap: 8px;">
                        <div style="width:18px;height:18px;fill:var(--popup-icon-color);">${rulerIcon}</div>
                        <span>Show Rulers</span>
                    </div>
                    <!-- Blueprint Item -->
                    <div class="menu-item" data-action="toggle-blueprint" style="padding: 8px 12px; cursor: pointer; font-size: 13px; display: flex; align-items: center; gap: 8px;">
                         <div style="width:18px;height:18px;fill:var(--popup-icon-color);">${blueprintIcon}</div>
                         <span>Blueprint Mode <sup style="color:#3e711f;">experimental</sup></span>
                         <span id="blueprint-indicator" style="margin-left:auto; font-size:14px; color: ${this.showBlueprint ? '#64C8FF' : 'var(--secondary-text-color)'}">${this.showBlueprint ? '●' : '○'}</span>
                    </div>
                    
                    <div style="height: 1px; background: var(--border-color); margin: 4px 0;"></div>
                    
                    <!-- Actions -->
                    <div style="padding: 8px 12px; border-bottom: 1px solid var(--border-color); font-size: 11px; color: var(--secondary-text-color); font-weight: 600; text-transform: uppercase;">
                        Actions
                    </div>
                    <div class="menu-item" data-action="screenshot" style="padding: 8px 12px; cursor: pointer; font-size: 13px; display: none; align-items: center; gap: 8px;">
                        <div style="width:18px;height:18px;fill:var(--popup-icon-color);">${screenshotIcon}</div>
                        <span>Take Screenshot</span>
                    </div>
                    <div class="menu-item" data-action="export-html" style="padding: 8px 12px; cursor: pointer; font-size: 13px; display: flex; align-items: center; gap: 8px;">
                        <div style="width:18px;height:18px;fill:var(--popup-icon-color);">${exportIcon}</div>
                        <span>Export as HTML</span>
                    </div>
                    <div class="menu-item" data-action="copy-xml" style="padding: 8px 12px; cursor: pointer; font-size: 13px; display: flex; align-items: center; gap: 8px;">
                        <div style="width:18px;height:18px;fill:var(--popup-icon-color);">${copyIcon}</div>
                        <span>Copy XML</span>
                    </div>
                    
                    <div style="height: 1px; background: var(--border-color); margin: 4px 0;"></div>
                    
                    <!-- Settings -->
                    <div class="menu-item" data-action="settings" style="padding: 8px 12px; cursor: pointer; font-size: 13px; display: flex; align-items: center; gap: 8px;">
                        <div style="width:18px;height:18px;fill:var(--popup-icon-color);">${settingsIcon}</div>
                        <span>Settings</span>
                    </div>
                    <div class="menu-item" data-action="help" style="padding: 8px 12px; cursor: pointer; font-size: 13px; display: flex; align-items: center; gap: 8px;">
                        <div style="width:18px;height:18px;fill:var(--popup-icon-color);">${helpIcon}</div>
                        <span>Help & Shortcuts</span>
                    </div>
                </div>

                <div style="width:1px; height:18px; background:var(--border-color); margin:0 4px;"></div>

                <!-- Drawer Toggle -->
                <button id="btn-toggle-drawer" class="aid-icon-btn" title="Toggle Navigation Drawer" 
                    style="border:none; background:transparent; cursor:pointer; padding:6px; border-radius:4px; display:flex; align-items:center; justify-content:center; color:var(--primary-text-color);">
                    ${menuIcon}
                </button>

                <!-- Refresh -->
                <button id="btn-refresh" class="aid-icon-btn" title="Refresh Layout (F5)" 
                    style="border:none; background:transparent; cursor:pointer; padding:6px; border-radius:4px; display:flex; align-items:center; justify-content:center; color:var(--primary-text-color);">
                    ${refreshIcon}
                </button>

                <div style="width:1px; height:18px; background:var(--border-color); margin:0 4px;"></div>

                <!-- Zoom Controls -->
                <button id="btn-zoom-out" class="aid-icon-btn" title="Zoom Out (Ctrl + -)" 
                    style="border:none; background:transparent; cursor:pointer; padding:6px; border-radius:4px; display:flex; align-items:center; justify-content:center; color:var(--primary-text-color);">
                    ${minusIcon}
                </button>
                
                <span id="zoom-level" style="font-size:12px; min-width:40px; text-align:center; font-weight:500; font-variant-numeric: tabular-nums; user-select:none; color:var(--primary-text-color);">
                    100%
                </span>
                
                <button id="btn-zoom-in" class="aid-icon-btn" title="Zoom In (Ctrl + +)" 
                    style="border:none; background:transparent; cursor:pointer; padding:6px; border-radius:4px; display:flex; align-items:center; justify-content:center; color:var(--primary-text-color);">
                    ${plusIcon}
                </button>
                
                <div style="width:1px; height:18px; background:var(--border-color); margin:0 6px;"></div>
                
                <!-- Theme Toggle -->
                <button id="btn-theme" class="aid-icon-btn" title="Toggle Theme (Ctrl + T)" 
                    style="outline:none; border:none; background:transparent; cursor:pointer; padding:6px; border-radius:4px; display:flex; align-items:center; justify-content:center; color:var(--primary-text-color);">
                    ${themeIcon}
                </button>
                
                <!-- Orientation Quick Toggle -->
                <button id="btn-rotate" class="aid-icon-btn" title="Rotate Device (Ctrl + R)" 
                    style="border:none; background:transparent; cursor:pointer; padding:6px; border-radius:4px; display:flex; align-items:center; justify-content:center; color:var(--primary-text-color);">
                    ${rotateIcon}
                </button>
                
                <button id="btn-blueprint" class="aid-icon-btn" title="Toggle Blueprint Mode" 
                style="border:none; background:transparent; cursor:pointer; padding:6px; border-radius:4px; display:flex; align-items:center; justify-content:center; color:${this.showBlueprint ? '#64C8FF' : 'var(--primary-text-color)'};">
                ${blueprintIcon}
            </button>

                <!-- Screenshot -->
                <button id="btn-screenshot" class="aid-icon-btn" title="Screenshot (Ctrl + S)" 
                    style="border:none; background:transparent; cursor:pointer; padding:6px; border-radius:4px; display:none; align-items: center; justify-content:center; color:var(--primary-text-color);">
                    ${screenshotIcon}
                </button>
            </div>
        `;
    }

    bindEvents(domRoot, onThemeChange) {
        this.themeBtn = domRoot.querySelector('#btn-theme');
        const zoomInBtn = domRoot.querySelector('#btn-zoom-in');
        const zoomOutBtn = domRoot.querySelector('#btn-zoom-out');
        const drawerBtn = domRoot.querySelector('#btn-toggle-drawer');
        const refreshBtn = domRoot.querySelector('#btn-refresh');
        const rotateBtn = domRoot.querySelector('#btn-rotate');
        const blueprintBtn = domRoot.querySelector('#btn-blueprint');
        const screenshotBtn = domRoot.querySelector('#btn-screenshot');
        const menuBtn = domRoot.querySelector('#btn-menu');
        const menu = domRoot.querySelector('#toolbar-menu');
        
        this.zoomLabel = domRoot.querySelector('#zoom-level');
        this.menuElement = menu;
        
        setTimeout(() => {
            this.updateZoom(0);
            if (this.showRulers) { this.showRulers = false; this.toggleRulers(); }
            if (this.showGrid) { this.showGrid = false; this.toggleGrid(); }
            if (this.orientation === 'landscape') { this.orientation = 'portrait'; this.rotateDevice(); }
            
            // 🔥 Auto Apply Blueprint on Load
            if (this.showBlueprint) {
                // Ensure UI is ready
                if(this.ui && this.ui.$root) {
                    this.toggleBlueprint(true); // Force enable without toggling state
                }
            }
        }, 100);

        // Zoom
        if (zoomInBtn) zoomInBtn.onclick = () => this.updateZoom(0.1);
        if (zoomOutBtn) zoomOutBtn.onclick = () => this.updateZoom(-0.1);
        
        // Drawer
        if (drawerBtn) drawerBtn.onclick = () => this.ui && this.ui.toggleDrawer?.();

        // Refresh
        if (refreshBtn) refreshBtn.onclick = () => this.ui && this.ui.manualRefresh?.();

        // Rotate
        if (rotateBtn) rotateBtn.onclick = () => this.rotateDevice();
        
        // Blueprint 
        
        if (blueprintBtn) blueprintBtn.onclick = () => this.toggleBlueprint();
        
        // Screenshot
        if (screenshotBtn) screenshotBtn.onclick = () => this.takeScreenshot();
        
        // Theme
        if (this.themeBtn) {
            this.themeBtn.onclick = () => {
                this.toggleTheme();
                if (onThemeChange) onThemeChange(this.isDark); 
            };
        }

        // Menu toggle
        if (menuBtn) {
            menuBtn.onclick = (e) => {
                e.stopPropagation();
                this.toggleMenu();
            };
        }

        // Menu items
        if (menu) {
            menu.querySelectorAll('.menu-item').forEach(item => {
                item.onclick = (e) => {
                    e.stopPropagation();
                    const action = item.dataset.action;
                    this.handleMenuAction(action);
                    this.closeMenu();
                };
                item.onmouseenter = () => item.style.background = 'var(--popup-active-color)';
                item.onmouseleave = () => item.style.background = 'transparent';
            });
        }

        // Close menu when clicking outside
        document.addEventListener('click', (e) => {
            if (this.menuOpen && !menu.contains(e.target) && e.target !== menuBtn) {
                this.closeMenu();
            }
        });

        // Keyboard shortcuts
        document.addEventListener('keydown', (e) => {
            if (e.ctrlKey && e.key === 'r') { e.preventDefault(); this.rotateDevice(); }
            if (e.ctrlKey && e.key === 't') { e.preventDefault(); this.themeBtn.click(); }
            if (e.ctrlKey && e.key === 's') { e.preventDefault(); this.takeScreenshot(); }
            if (e.ctrlKey && e.key === 'c' && !['INPUT', 'TEXTAREA'].includes(e.target.tagName)) { e.preventDefault(); this.copyXML(); }
            if (e.key === 'F5') { e.preventDefault(); this.ui?.manualRefresh?.(); }
            if (e.ctrlKey && (e.key === '=' || e.key === '+')) { e.preventDefault(); this.updateZoom(0.1); }
            if (e.ctrlKey && (e.key === '-' || e.key === '_')) { e.preventDefault(); this.updateZoom(-0.1); }
        });
    }
    
    _save(key, value) {
        localStorage.setItem(key, value);
    }

    toggleMenu() {
        this.menuOpen = !this.menuOpen;
        if (this.menuElement) this.menuElement.style.display = this.menuOpen ? 'block' : 'none';
    }

    closeMenu() {
        this.menuOpen = false;
        if (this.menuElement) this.menuElement.style.display = 'none';
    }

    handleMenuAction(action) {
        switch (action) {
            case 'device-pixel5': this.setDevice(393, 851, 'Pixel 5'); break;
            case 'device-pixel7': this.setDevice(412, 915, 'Pixel 7'); break;
            case 'device-nexus5': this.setDevice(360, 640, 'Nexus 5'); break;
            case 'device-tablet': this.setDevice(800, 1280, 'Tablet'); break;
            case 'rotate': this.rotateDevice(); break;
            case 'toggle-grid': this.toggleGrid(); break;
            case 'toggle-rulers': this.toggleRulers(); break;
            case 'toggle-blueprint': this.toggleBlueprint(); break;
            case 'screenshot': this.takeScreenshot(); break;
            case 'export-html': this.exportHTML(); break;
            case 'copy-xml': this.copyXML(); break;
            case 'settings': this.openSettings(); break;
            case 'help': this.showHelp(); break;
        }
    }

    setDevice(width, height, name) {
        if (this.orientation === 'landscape') {
            [width, height] = [height, width];
        }
        DeviceConfig.width = width;
        DeviceConfig.height = height;
        const frame = this.ui.$root ? this.ui.$root.closest('.device-frame') : null;
        if (frame) {
            frame.style.width = width + 'px';
            frame.style.height = height + 'px';
        }
        this.ui?.manualRefresh?.();
        window.toast(`📱 Device: ${name} (${width}×${height})`, 2000);
    }

    rotateDevice() {
        this.orientation = this.orientation === 'portrait' ? 'landscape' : 'portrait';
        this._save('aid_preview_orientation', this.orientation);
        const temp = DeviceConfig.width;
        DeviceConfig.width = DeviceConfig.height;
        DeviceConfig.height = temp;
        const frame = this.ui.$root?.closest('.device-frame');
        if (frame) {
            frame.style.width = DeviceConfig.width + 'px';
            frame.style.height = DeviceConfig.height + 'px';
            this.orientation === 'landscape' ? frame.classList.add('landscape') : frame.classList.remove('landscape');
        }
        this.ui?.manualRefresh?.();
    }

    toggleGrid() {
        this.showGrid = !this.showGrid;
        this._save('aid_preview_grid', this.showGrid);
        const root = this.ui.$root;
        if (this.showGrid) {
            if (!root.querySelector('.grid-overlay')) {
                const gridColor = 'var(--border-color)'; 
                const grid = document.createElement('div');
                grid.className = 'grid-overlay';
                grid.style.cssText = `position: absolute; top: 0; left: 0; width: 100%; height: 100%; background-image: linear-gradient(${gridColor} 1px, transparent 1px), linear-gradient(90deg, ${gridColor} 1px, transparent 1px); background-size: 20px 20px; pointer-events: none; z-index: 9999; opacity: 0.5;`;
                root.appendChild(grid);
            }
        } else {
            root.querySelector('.grid-overlay')?.remove();
        }
    }

    
    toggleRulers() {
        this.showRulers = !this.showRulers;
        this._save('aid_preview_ruler', this.showRulers);
        const wrapper = this.ui.$root ? this.ui.$root.closest('.frame-wrapper') : null;
        if (!wrapper) return;
        const parent = wrapper.parentElement; 
        const toolbar = parent.querySelector('.preview-toolbar');

        if (this.showRulers) {
            if (!parent.querySelector('.ruler-container')) {
                // Use CSS variables for ruler theming
                const rulerBg = 'var(--popup-background-color)';
                const tickColor = 'var(--border-color)';
                const textColor = 'var(--secondary-text-color)';
                
                const topOffset = toolbar ? toolbar.offsetHeight : 0;
                const container = document.createElement('div');
                container.className = 'ruler-container';
                container.style.cssText = `position: absolute; top: ${topOffset}px; left: 0; width: 100%; height: calc(100% - ${topOffset}px); pointer-events: none; z-index: 100; overflow: hidden;`;
                const hRuler = document.createElement('div');
                hRuler.style.cssText = `position: absolute; top: 0; left: 15px; width: calc(100% - 15px); height: 15px; background-color: ${rulerBg}; border-bottom: 1px solid ${tickColor}; background-image: repeating-linear-gradient(90deg, ${tickColor} 0, ${tickColor} 1px, transparent 1px, transparent 10px), repeating-linear-gradient(90deg, ${tickColor} 0, ${tickColor} 1px, transparent 1px, transparent 50px); background-size: 100% 4px, 100% 8px; background-repeat: repeat-x; background-position: bottom; font-family: 'Roboto Mono', monospace; font-size: 8px; color: ${textColor};`;
                hRuler.innerHTML = `<span style="position:absolute; left:2px; top:2px;">0</span><span style="position:absolute; left:52px; top:2px;">50</span><span style="position:absolute; left:102px; top:2px;">100</span><span style="position:absolute; left:202px; top:2px;">200</span><span style="position:absolute; left:302px; top:2px;">300</span>`;
                const vRuler = document.createElement('div');
                vRuler.style.cssText = `position: absolute; top: 15px; left: 0; width: 15px; height: calc(100% - 15px); background-color: ${rulerBg}; border-right: 1px solid ${tickColor}; background-image: repeating-linear-gradient(0deg, ${tickColor} 0, ${tickColor} 1px, transparent 1px, transparent 10px), repeating-linear-gradient(0deg, ${tickColor} 0, ${tickColor} 1px, transparent 1px, transparent 50px); background-size: 4px 100%, 8px 100%; background-repeat: repeat-y; background-position: right; font-family: 'Roboto Mono', monospace; font-size: 8px; color: ${textColor};`;
                vRuler.innerHTML = `<span style="position:absolute; top:2px; right:2px;">0</span><span style="position:absolute; top:52px; right:2px;">50</span><span style="position:absolute; top:102px; right:2px;">100</span><span style="position:absolute; top:202px; right:2px;">200</span><span style="position:absolute; top:402px; right:2px;">400</span>`;
                const corner = document.createElement('div');
                corner.style.cssText = `position: absolute; top: 0; left: 0; width: 15px; height: 15px; background-color: ${rulerBg}; border-right: 1px solid ${tickColor}; border-bottom: 1px solid ${tickColor}; z-index: 101;`;
                container.appendChild(hRuler); container.appendChild(vRuler); container.appendChild(corner);
                parent.appendChild(container);
            }
        } else {
            parent.querySelector('.ruler-container')?.remove();
        }
    }

    // Toggle Blueprint Mode
    // toggleBlueprint(forceState = null) {
    //     if (forceState !== null) {
    //         // Just apply styling without toggling logic if forced (e.g. on load)
    //     } else {
    //         this.showBlueprint = !this.showBlueprint;
    //         this._save('aid_preview_blueprint', this.showBlueprint);
    //     }

    //     const indicator = document.getElementById('blueprint-indicator');
    //     if (indicator) {
    //         indicator.textContent = this.showBlueprint ? '●' : '○';
    //         indicator.style.color = this.showBlueprint ? '#64C8FF' : 'var(--secondary-text-color)';
    //     }

    //     if (this.showBlueprint) {
    //         // Logic to enable handled by Renderer mostly, but we trigger the visual change here too
    //         if (this.blueprintRenderer && this.ui.$root) {
    //             // We need the solver. Since we can't easily get it here, we rely on LayoutPreviewUI
    //             // to call enableBlueprint on refresh. But for immediate toggle:
    //             const solver = window.__latestConstraintSolver; 
    //             this.blueprintRenderer.enableBlueprint(this.ui.$root, solver);
    //         }
    //         window.toast('🟦 Blueprint Mode: ON', 2000);
    //     } else {
    //         if (this.blueprintRenderer && this.ui.$root) {
    //             this.blueprintRenderer.disableBlueprint(this.ui.$root);
    //         }
    //         window.toast('🎨 Design Mode: ON', 2000);
    //     }
    // }
    
    // ToolbarControls.js - toggleBlueprint() মেথড

toggleBlueprint(forceState = null) {
    if (forceState !== null) {
         // Force state logic
    } else {
        this.showBlueprint = !this.showBlueprint;
        this._save('aid_preview_blueprint', this.showBlueprint);
    }

    // মেনু ইন্ডিকেটর আপডেট (আগের কোড)
    const indicator = document.getElementById('blueprint-indicator');
    if (indicator) {
        indicator.textContent = this.showBlueprint ? '●' : '○';
        indicator.style.color = this.showBlueprint ? '#64C8FF' : 'var(--secondary-text-color)';
    }

    // 🔥 NEW: টুলবার বাটনের কালার আপডেট করা
    const toolbarBtn = document.getElementById('btn-blueprint');
    if (toolbarBtn) {
        toolbarBtn.style.color = this.showBlueprint ? '#64C8FF' : 'var(--primary-text-color)';
    }

    // বাকি লজিক (Renderer Enable/Disable)
    if (this.showBlueprint) {
        if (this.blueprintRenderer && this.ui.$root) {
            const solver = window.__latestConstraintSolver; 
            this.blueprintRenderer.enableBlueprint(this.ui.$root, solver);
        }
        window.toast('🟦 Blueprint Mode: ON', 2000);
    } else {
        if (this.blueprintRenderer && this.ui.$root) {
            this.blueprintRenderer.disableBlueprint(this.ui.$root);
        }
        window.toast('🎨 Design Mode: ON', 2000);
    }
}

    // async takeScreenshot() {
    //     const frame = this.ui.$root ? this.ui.$root.closest('.device-frame') : null;
    //     if (!frame) return;
    //     try {
    //         if (window.html2canvas) {
    //             const canvas = await html2canvas(frame);
    //             canvas.toBlob((blob) => {
    //                 const url = URL.createObjectURL(blob);
    //                 const a = document.createElement('a');
    //                 a.href = url;
    //                 a.download = `screenshot-${Date.now()}.png`;
    //                 a.click();
    //                 URL.revokeObjectURL(url);
    //             });
    //             window.toast('📸 Screenshot saved!', 2000);
    //         } else {
    //             window.toast('⚠️ Screenshot feature requires html2canvas library', 3000);
    //         }
    //     } catch (e) {
    //         window.toast('❌ Screenshot failed: ' + e.message, 3000);
    //     }
    // }
    
    async takeScreenshot() {
        const frame = this.ui.$root ? this.ui.$root.closest('.device-frame') : null;
        if (!frame) {
            window.toast('⚠️ Nothing to capture!', 2000);
            return;
        }
        
        try {
            window.toast('📸 Capturing...', 1000);

            const canvas = await html2canvas(frame, {
                useCORS: true,       // বাইরের ইমেজ লোড করার অনুমতি
                allowTaint: true,    // Tainted ক্যানভাস হ্যান্ডেল করার চেষ্টা
                backgroundColor: null, // ট্রান্সপারেন্ট ব্যাকগ্রাউন্ড সাপোর্ট
                scale: 2,            // ভালো কোয়ালিটি
                logging: false,      // কনসোল লগ বন্ধ রাখা

                // 🔥 CRITICAL FIX: সমস্যা তৈরি করা ক্যানভাসগুলো বাদ দেওয়া
                ignoreElements: (element) => {
                    // Acode বা ডিবাগিং টুলের ক্যানভাস ইগনোর করা
                    if (element.tagName === 'CANVAS') {
                        if (element.id === 'monitor-timeline' || 
                            element.classList.contains('metric-canvas')) {
                            return true; // একে রেন্ডার করবে না
                        }
                    }
                    // টুলবার বা অন্য পপআপ ইগনোর করতে চাইলে
                    if (element.id === 'toolbar-menu' || element.classList.contains('aid-icon-btn')) {
                        return true;
                    }
                    return false;
                }
            });

            // ক্যানভাস তৈরি হওয়ার পর সেভ করা
            canvas.toBlob((blob) => {
                if (!blob) {
                    throw new Error('Canvas is empty or tainted');
                }
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `android-preview-${Date.now()}.png`;
                document.body.appendChild(a); // Firefox/Mobile সাপোর্ট এর জন্য বডিতে অ্যাড করা
                a.click();
                document.body.removeChild(a); // কাজ শেষে রিমুভ
                URL.revokeObjectURL(url);
                
                window.toast('✅ Screenshot Saved!', 2000);
            }, 'image/png'); // PNG ফরম্যাট নিশ্চিত করা
            
        } catch (e) {
            console.error('Screenshot Error:', e);
            window.toast('❌ Screenshot Failed: Check Console', 3000);
        }
    }

    exportHTML() {
        const html = this.ui.$root ? this.ui.$root.innerHTML : '';
        const blob = new Blob([html], { type: 'text/html' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `export-${Date.now()}.html`;
        a.click();
        URL.revokeObjectURL(url);
        window.toast('✅ HTML exported!', 2000);
    }

    copyXML() {
        const xml = editorManager.editor.getValue();
        navigator.clipboard.writeText(xml).then(() => {
            window.toast('📋 XML copied to clipboard!', 2000);
        });
    }

    openSettings() {
        window.toast('⚙️ Settings panel coming soon!', 2000);
    }

    showHelp() {
        const helpText = `
Keyboard Shortcuts:
• Ctrl+R - Rotate device
• Ctrl+T - Toggle theme
• Ctrl+S - Screenshot
• Ctrl+C - Copy XML
• Ctrl+\` - Toggle Logcat
• F5 - Refresh layout
• Ctrl+ +/- - Zoom in/out
        `.trim();
        alert(helpText);
    }

    updateZoom(delta) {
        this.scale = Math.max(0.4, Math.min(3.0, this.scale + delta)); 
        this._save('aid_preview_scale', this.scale);
        const frame = this.ui.$root ? this.ui.$root.closest('.device-frame') : null;
        if(frame) {
            frame.style.transform = `scale(${this.scale})`;
            frame.style.transformOrigin = 'top center';
          frame.style.transition = 'transform 0.2s cubic-bezier(0.25, 0.46, 0.45, 0.94)';
        }
        if (this.zoomLabel) this.zoomLabel.innerText = `${Math.round(this.scale * 100)}%`;
    }

    toggleTheme() {
        this.isDark = !this.isDark;
        if (this.themeBtn) {
            this.themeBtn.innerHTML = this.isDark ? svgs.day : svgs.night;
        }
    }
}