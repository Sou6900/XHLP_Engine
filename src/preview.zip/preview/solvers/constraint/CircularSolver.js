export class CircularSolver {
    constructor(solver) {
        this.solver = solver;
        this.helper = solver.helper;
    }

    solve(state, attr) {
        const targetIdRaw = this.helper.getAttr(attr, 'layout_constraintCircle');
        if (!targetIdRaw) return;

        const targetId = targetIdRaw.replace(/@\+?id\//, '');
        const targetState = this.solver.nodeMap.get(targetId);

        if (!targetState) {
            // টার্গেট যদি খুঁজে না পাওয়া যায়, তবে কিছু করার নেই
            return;
        }

        const radius = this.helper.parsePx(this.helper.getAttr(attr, 'layout_constraintCircleRadius')) || 0;
        let angle = parseFloat(this.helper.getAttr(attr, 'layout_constraintCircleAngle')) || 0;

        // Android Angle Logic:
        // 0 degrees = Top (12 o'clock)
        // Increases Clockwise (0 -> 90 -> 180 -> 270)
        
        // Math Logic:
        // Radian conversion
        const rad = angle * (Math.PI / 180);

        // Target Center Calculation
        const targetCenterX = targetState.x + (targetState.w / 2);
        const targetCenterY = targetState.y + (targetState.h / 2);

        // Calculate Center Position of the Satellite View
        // X = r * sin(theta)  (For 0 at top, clockwise)
        // Y = -r * cos(theta) (For 0 at top, clockwise, noting Y is down-positive)
        
        const myCenterX = targetCenterX + (radius * Math.sin(rad));
        const myCenterY = targetCenterY - (radius * Math.cos(rad));

        // Set Top-Left Position based on calculated Center
        state.x = myCenterX - (state.w / 2);
        state.y = myCenterY - (state.h / 2);
        
        // Mark as solved so other solvers don't overwrite it roughly
        // (Though standard constraints are usually ignored if circle is present)
        state.solvedX = true;
        state.solvedY = true;

        this.solver.logger.log('solve', `Circular: ${state.id} around ${targetId} -> (${state.x.toFixed(1)}, ${state.y.toFixed(1)})`);
    }
}