import { BaseView } from './BaseView.js';

export class Placeholder extends BaseView {
    async render(node) {
        const attr = node.attributes;
        const idStr = attr.id ? `id="${attr.id.replace('@+id/', '')}"` : '';
        const contentId = attr['app:content'] || attr['content'] || '';

        // Placeholder এর নিজস্ব ভিজ্যুয়াল দরকার নেই, এটি শুধু জায়গা দখল করে
        // data-content এ টার্গেট আইডি রেখে দিচ্ছি
        return `<div class="android-view android-placeholder" ${idStr} 
                    data-content="${contentId.replace('@+id/', '').replace('@id/', '')}"
                    style="visibility: hidden;">
                </div>`;
    }
}