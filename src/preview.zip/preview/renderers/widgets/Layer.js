import { BaseView } from './BaseView.js';

export class Layer extends BaseView {
    async render(node) {
        const attr = node.attributes;
        const idStr = attr.id ? `id="${attr.id.replace('@+id/', '')}"` : '';
        const refIds = attr['app:constraint_referenced_ids'] || attr['constraint_referenced_ids'] || '';

        // 🔥 FIX: Read attributes explicitly with fallbacks
        // Note: Attribute names can be with or without namespace prefix
        const getAttr = (name) => attr[name] || attr[`android:${name}`] || '0';

        const rotation = getAttr('rotation');
        const scaleX = attr['android:scaleX'] || attr['scaleX'] || '1'; // Default scale is 1
        const scaleY = attr['android:scaleY'] || attr['scaleY'] || '1';
        const transX = getAttr('translationX');
        const transY = getAttr('translationY');

        return `<div class="android-view android-layer" ${idStr} 
                    data-referenced-ids="${refIds}"
                    data-rotation="${rotation}"
                    data-scale-x="${scaleX}"
                    data-scale-y="${scaleY}"
                    data-translation-x="${transX}"
                    data-translation-y="${transY}"
                    style="display: none !important; width: 0px; height: 0px;">
                </div>`;
    }
}