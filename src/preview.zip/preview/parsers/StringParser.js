// strings.xml
export class StringParser {
    
    /**
     * Parse strings.xml content
     * @param {Document} xmlDoc - The DOM object of strings.xml
     * @returns {Map<string, string>} Map of string names to values
     */
    parse(xmlDoc) {
        const strings = new Map();
        if (!xmlDoc) return strings;

        const stringElements = xmlDoc.getElementsByTagName('string');
        
        for (let i = 0; i < stringElements.length; i++) {
            const el = stringElements[i];
            const name = el.getAttribute('name');
            const value = el.textContent;
            
            if (name) {
                strings.set(name, value);
            }
        }
        return strings;
    }
}