// Resolves ?attr/colorPrimary, Parent Inheritance

export class ThemeResolver {
    constructor(styleParser, resourceResolver) {
        this.styleParser = styleParser;
        this.resourceResolver = resourceResolver; // Needed to resolve values inside styles
        this.currentThemeStyles = {}; // Flattened theme
    }

    // Called when app starts to set the global theme
    setTheme(themeName) {
        console.log(`🎨 [ThemeResolver] Setting active theme: ${themeName}`);
        this.currentThemeStyles = this.resolveStyleHierarchy(themeName);
    }

    // Resolves ?attr/colorPrimary
    resolveAttribute(attrReference) {
        if (!attrReference.startsWith('?attr/') && !attrReference.startsWith('?')) {
            return attrReference;
        }

        const attrName = attrReference.replace('?attr/', '').replace('?', '');
        const val = this.currentThemeStyles[attrName];
        
        if (val) {
             // The value in the theme might be a reference (@color/purple)
             // So we ask ResourceResolver to resolve that too
             return this.resourceResolver.resolveColor(val) || val;
        }
        
        console.warn(`⚠️ [Theme] Attribute ?attr/${attrName} not found in current theme`);
        // return '#FF00FF'; // Magenta debug color
        return null; // Magenta debug color
    }

    // Merges a style with all its parents recursively
    resolveStyleHierarchy(styleName) {
        if (!styleName) return {};

        const styleDef = this.styleParser.getStyle(styleName);
        if (!styleDef) return {};

        // 1. Get Parent Attributes first (Recursion)
        let finalAttributes = {};
        if (styleDef.parent) {
            finalAttributes = this.resolveStyleHierarchy(styleDef.parent);
        }

        // 2. Override with Current Attributes
        Object.assign(finalAttributes, styleDef.items);

        return finalAttributes;
    }
}