// // Main loader
// import { ShapeDrawable } from './ShapeDrawable.js';
// import { VectorDrawable } from './VectorDrawable.js';

// export class DrawableLoader {
//     constructor() {
//         this.shapeDrawable = new ShapeDrawable();
//         this.vectorDrawable = new VectorDrawable();
//     }

//     /**
//     * Processes a parsed XML node and returns the CSS style or SVG content
//     * @param {Object} node - The parsed XML node
//     * @returns {Object} { type: 'css' | 'svg', value: string }
//     */
//     process(node) {
//         if (!node) return null;

//         if (node.type === 'shape') {
//             return {
//                 type: 'css',
//                 value: this.shapeDrawable.createStyle(node)
//             };
//         } 
        
//         if (node.type === 'vector') {
//             return {
//                 type: 'svg',
//                 value: this.vectorDrawable.createSVG(node)
//             };
//         }

//         // Future: Add 'selector', 'layer-list' here
//         console.warn(`Drawable type '${node.type}' not fully supported yet.`);
//         return null;
//     }
// }



import { ShapeDrawable } from './ShapeDrawable.js';
import { VectorDrawable } from './VectorDrawable.js';
import { StateListDrawable } from './StateListDrawable.js'; // ✅ Import

export class DrawableLoader {
    constructor(resourceResolver) {
        this.shapeDrawable = new ShapeDrawable();
        this.vectorDrawable = new VectorDrawable();
        // যেহেতু DrawableLoader কনস্ট্রাক্টর এ resolver পায় না সাধারণত, 
        // তাই আমরা process মেথডে resolver পাস করব অথবা সেটার ব্যবস্থা করব।
        // তবে আমাদের আর্কিটেকচারে ResourceResolver নিজেই DrawableLoader কল করে।
        // তাই আমরা StateListDrawable কে পরে ইনিশিয়ালাইজ করব বা রেজলভার পাস করব।
    }

    // 🔥 Fix: We need resolver here. Let's assume process() receives it or we inject it.
    // For simplicity, let's instantiate StateListDrawable inside process with the context if available,
    // OR pass resolver in constructor. 
    // Let's modify ResourceResolver to pass 'this' when creating DrawableLoader.
    
    // BETTER: Modify ResourceResolver.js first to pass 'this' to DrawableLoader constructor.
    // But assuming you might not want to edit Resolver heavily, let's patch it.
    
    process(ast, resolver) { // ✅ Added 'resolver' param
        if (!ast) return null;

        if (ast.type === 'vector') {
            const svg = this.vectorDrawable.createSVG(ast);
            return { type: 'svg', value: svg };
        } 
        else if (ast.type === 'shape') {
            const css = this.shapeDrawable.createStyle(ast);
            return { type: 'css', value: css };
        }
        else if (ast.type === 'selector') {
            // ✅ Handle Selector
            // Note: Since process is async inside StateList, we need to handle async here.
            // But process() was synchronous before.
            // We need to change logic slightly. 
            // Let's return a Promise for selector or handle it in Resolver.
            
            // For now, let's assume ResourceResolver handles the async part.
            // We will return a special object that Resolver will handle.
            return { type: 'selector_ast', ast, resolver }; 
        }
        return null;
    }
}