import { BaseView } from './BaseView.js';

export class Guideline extends BaseView {
    async render(node, parentType) {
        const attr = node.attributes;
        const idStr = attr.id ? `id="${attr.id.replace('@+id/', '')}"` : '';
        return `<div class="android-view android-guideline" ${idStr} style="display: none !important; width: 0px; height: 0px;"></div>`;
    }
}