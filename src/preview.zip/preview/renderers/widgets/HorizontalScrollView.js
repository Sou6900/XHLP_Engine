import { BaseView } from './BaseView.js';

export class HorizontalScrollView extends BaseView {
    
    async render(node, renderChildCallback) {
        // We pass 'null' as width to indicate unconstrained horizontal space
        return this.renderWithBounds(node, null, null, renderChildCallback, 'ViewGroup');
    }

    async renderWithBounds(node, width, height, renderChildCallback, parentType) {
        const attr = node.attributes;
        const baseStyle = await this.getBaseStyles(attr, parentType || 'ViewGroup');

        // Padding Parsing
        const p = attr.padding;
        const pl = this._parsePx(attr.paddingLeft || attr.paddingStart || p);
        const pr = this._parsePx(attr.paddingRight || attr.paddingEnd || p);
        const pt = this._parsePx(attr.paddingTop || p);
        const pb = this._parsePx(attr.paddingBottom || p);

        // Height Constraint (Vertical is still constrained)
        // If height is provided by parent (e.g. ConstraintLayout solved it), use it minus padding
        const innerHeight = height ? (height - pt - pb) : null; 

        // Overscroll Logic
        const overScroll = attr.overScrollMode || attr['android:overScrollMode'];
        let cssOverscroll = 'auto';
        if (overScroll === 'never') cssOverscroll = 'none';

        const layoutStyle = `
            display: block;
            overflow-x: auto;       /* Enable Horizontal Scroll */
            overflow-y: hidden;     /* Hide Vertical Scroll */
            white-space: nowrap;    /* Keep content inline */
            overscroll-behavior-x: ${cssOverscroll};
            -webkit-overflow-scrolling: touch;
            scrollbar-width: thin;
            max-width: 100%;        /* Contain within parent width */
        `;

        const childrenHtmlArray = await Promise.all(node.children.map(async child => {
            // 🔥 CRITICAL: Pass 'null' for width so the child (LinearLayout) calculates its own width based on content
            return await renderChildCallback(child, 'HorizontalScrollView', null, innerHeight);
        }));

        return `
            <div class="android-view horizontal-scroll-view" style="${baseStyle} ${layoutStyle}">
                ${childrenHtmlArray.join('')}
            </div>
        `;
    }

    _parsePx(val) {
        if (!val) return 0;
        return parseFloat(this.converter.parse(val));
    }
}