import { BaseView } from './BaseView.js';

export class View extends BaseView {
    async render(node, parentType) {
        const baseStyle = await this.getBaseStyles(node.attributes, parentType);
        
        // ID যোগ করা হয়েছে যাতে HTML এ দেখা যায় এবং ConstraintLayout সিলেক্ট করতে পারে
        const idStr = node.attributes.id ? `id="${node.attributes.id.replace('@+id/', '')}"` : '';

        return `<div class="android-view generic-view" ${idStr} style="${baseStyle}"></div>`;
    }
}