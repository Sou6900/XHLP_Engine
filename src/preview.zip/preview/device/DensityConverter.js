// // dp/sp to px calculator

import { DeviceConfig } from './DeviceConfig.js';

export class DensityConverter {
    constructor() {
        this.density = DeviceConfig.density;
    }

    parse(value) {
        if (!value) return '0px';
        if (typeof value !== 'string') return `${value}px`;
        if (value === 'match_parent' || value === 'fill_parent') return '100%';
        if (value === 'wrap_content') return 'max-content';

        const match = value.match(/^([-\d.]+)(dp|dip|sp|px)?$/);
        if (!match) return value;

        const num = parseFloat(match[1]);
        const unit = match[2];

        switch (unit) {
            case 'dp':
            case 'dip':
                return `${num * this.density}px`;
            case 'sp':
                return `${num * this.density}px`; // Simplified for preview
            default:
                return `${num}px`;
        }
    }
}