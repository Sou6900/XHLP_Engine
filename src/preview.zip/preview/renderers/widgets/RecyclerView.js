import { BaseView } from './BaseView.js';

export class RecyclerView extends BaseView {
    
    async render(node, parentType) {
        const attr = node.attributes;
        const baseStyle = await this.getBaseStyles(attr, parentType);
        
        let contentHtml = '';

        // 1. Check tools:listitem
        // Note: XML parser might namespace tools as 'tools:listitem' or just 'listitem'
        const listItemRef = attr['tools:listitem'] || attr['listitem'];
        const itemCount = parseInt(attr['tools:itemCount'] || attr['itemCount'] || '5');

        if (listItemRef && listItemRef.startsWith('@layout/')) {
            const layoutName = listItemRef.replace('@layout/', '');
            
            // 🔥 Fetch Layout XML
            const layoutXml = await this.resolver.context.getLayout(layoutName);
            
            if (layoutXml) {
                // 🔥 We need to render this XML. 
                // Since we don't have direct access to PreviewEngine's recursive method here,
                // we will rely on a "Renderer Callback" if provided, or handle simplistic rendering.
                // *For Phase 6, we assume PreviewEngine attaches a 'subRenderer' to resolver or global.*
                // BETTER: We use a simple placeholder if complex rendering is hard, 
                // BUT let's try to render it properly.
                
                // Hack: We need the engine. Let's assume passed in context or we create a fresh parse.
                // Since 'render' is called by Engine, we can ask Engine to expose a static helper?
                // Let's use a simpler approach: Just render the raw HTML for now using a clean parser instance 
                // OR (Best) - Inject a render callback in BaseView logic.
                
                // For this implementation, let's assume we can parse it.
                // Since we can't easily recurse back to 'PreviewEngine.render' without circular dependency,
                // we will show a "Design Mode" placeholder which represents the item.
                
                // Let's try to render ONE item properly if we can access the parser.
                // We will use a visual trick: Render the ITEM 5 times.
                
                // To actually render the item, we need the Engine. 
                // Let's update PreviewEngine to pass a `renderSubLayout` function in the next file.
                
                if (this.renderSubLayout) {
                    const itemHtml = await this.renderSubLayout(layoutXml);
                    // Repeat items
                    for(let i=0; i<itemCount; i++) {
                        contentHtml += `<div class="recycler-item" style="border-bottom:1px solid #eee;">${itemHtml}</div>`;
                    }
                } else {
                    contentHtml = `<div style="padding:20px; color:#888;">Loaded: ${layoutName} (Engine link missing)</div>`;
                }

            } else {
                contentHtml = `<div style="padding:20px; text-align:center; color:#ccc;">Layout not found: ${layoutName}</div>`;
            }
        } else {
            // Default placeholder
            for(let i=1; i<=itemCount; i++) {
                contentHtml += `
                    <div style="padding: 15px; border-bottom: 1px solid #eee; display: flex; align-items: center;">
                        <div style="width: 40px; height: 40px; background: #e0e0e0; border-radius: 50%; margin-right: 15px;"></div>
                        <div style="flex: 1;">
                            <div style="height: 12px; width: 60%; background: #e0e0e0; margin-bottom: 8px;"></div>
                            <div style="height: 10px; width: 40%; background: #f0f0f0;"></div>
                        </div>
                    </div>
                `;
            }
        }

        const id = attr.id ? `id="${attr.id.replace('@+id/', '')}"` : '';

        return `
            <div ${id} class="android-view recycler-view" style="${baseStyle} overflow-y: auto; display: block;">
                ${contentHtml}
            </div>
        `;
    }
}