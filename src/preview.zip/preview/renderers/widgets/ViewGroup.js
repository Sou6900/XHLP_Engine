import { BaseView } from './BaseView.js';

export class ViewGroup extends BaseView {
    constructor(resolver) {
        super(resolver);
    }

    //  Accept 'parentType' argument
    async render(node, renderChildCallback, parentType) {
        const attr = node.attributes;
        
        // Use passed parentType (or default to 'ViewGroup' if root)
        const pType = parentType || 'ViewGroup';
        const baseStyle = await this.getBaseStyles(attr, pType);
        
        const currentType = this.constructor.name; 

        let childrenHtml = '';
        if (node.children && node.children.length > 0) {
            const promises = node.children.map(child => renderChildCallback(child, currentType));
            const results = await Promise.all(promises);
            childrenHtml = results.join('');
        }

        return `
            <div class="android-view view-group" style="${baseStyle}">
                ${childrenHtml}
            </div>
        `;
    }
}