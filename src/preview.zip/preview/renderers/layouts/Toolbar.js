// // layouts/Toolbar.js
// import { BaseView } from '../widgets/BaseView.js';
// import { LinearSolver } from '../../solvers/LinearSolver.js';
// import { ActionMenuItemView } from '../widgets/ActionMenuItemView.js';

// export class Toolbar extends BaseView {
//     constructor(resolver) {
//         super(resolver);
//         this.solver = new LinearSolver();
//         this.menuItemRenderer = new ActionMenuItemView(resolver);
//     }

//     async render(node, renderChildCallback, parentType) {
//         const attr = node.attributes;
//         const baseStyle = await this.getBaseStyles(attr, parentType);
//         const get = (name) => attr[name] || attr[`android:${name}`] || attr[`app:${name}`];

//         // 1. Toolbar Properties
//         const title = get('title') || 'Toolbar';
//         const subtitle = get('subtitle');
//         const navIcon = get('navigationIcon');
//         const titleTextColor = get('titleTextColor') || '#FFFFFF';
        
//         // Default Material Toolbar Height is 56dp (mobile)
//         let minHeight = this.converter.parse(get('minHeight') || '56dp');
//         let height = this.converter.parse(get('layout_height'));
//         if (get('layout_height') === 'wrap_content') height = minHeight;

//         // Background (Default Primary Color usually)
//         if (!baseStyle.includes('background-color') && !baseStyle.includes('background:')) {
//             // Default to a material purple if no background set
//             baseStyle += 'background-color: #6200EE; ';
//         }

//         // 2. Render Navigation Icon (Hamburger/Back)
//         let navHtml = '';
//         if (navIcon) {
//             const iconDrawable = await this.resolver.resolveDrawable(navIcon);
//             // Defaulting to "Menu" icon if logic fails, for visualization
//             let src = iconDrawable ? iconDrawable.value : ''; 
            
//             // Fix SVG Rendering
//             if (src && src.includes('<svg')) {
//                 src = `data:image/svg+xml;utf8,${encodeURIComponent(src)}`;
//             }
            
//             navHtml = `
//                 <div class="toolbar-nav-icon" style="
//                     width: 24px; height: 24px; margin-inline-start: 16px; margin-inline-end: 16px;
//                     display: flex; align-items: center; justify-content: center; cursor: pointer;">
//                     <img src="${src}" style="width: 24px; height: 24px; filter: brightness(0) invert(1);" />
//                 </div>
//             `;
//         }

//         // 3. Render Title Area
//         const titleHtml = `
//             <div class="toolbar-title-content" style="display: flex; flex-direction: column; justify-content: center; flex: 1; margin-left: ${navIcon ? '0' : '16px'};">
//                 <span style="color: ${titleTextColor}; font-size: 20px; font-weight: 500; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
//                     ${title}
//                 </span>
//                 ${subtitle ? `<span style="color: ${titleTextColor}; opacity: 0.7; font-size: 14px;">${subtitle}</span>` : ''}
//             </div>
//         `;

// // 4. Render Menu Items (Action Buttons)
//         let actionsHtml = '';
//         const menuItems = node.menuItems || []; 
        
//         const childrenHtmlArray = await Promise.all(node.children.map(async child => {
//             return await renderChildCallback(child, 'Toolbar', null, null);
//         }));

//         // 🔥 FIX: Limit visible action items to prevent overflow
//         // In a real Android app, this is calculated dynamically based on width.
//         // For preview, we limit to 2 items + overflow icon if there are more.
        
//         const maxActions = 2; // Show max 2 actions directly
//         let visibleItems = [];
//         let overflowItems = [];

//         if (menuItems.length > 0) {
//             // Simple logic: Prioritize 'always' > 'ifRoom' > 'never'
//             // But since XML order usually implies priority, we take the first few 'ifRoom'/'always' items.
            
//             menuItems.forEach(item => {
//                 const showAsAction = item.attributes['app:showAsAction'] || '';
//                 if (visibleItems.length < maxActions && (showAsAction.includes('ifRoom') || showAsAction.includes('always'))) {
//                     visibleItems.push(item);
//                 } else {
//                     overflowItems.push(item);
//                 }
//             });

//             // If we have items but none set to show, or all are 'never', they go to overflow.
//             // If overflow is needed, we ensure we have space for the 3-dots.
            
//             const actionHtmls = await Promise.all(visibleItems.map(async item => {
//                 return await this.menuItemRenderer.render(item, 'Toolbar');
//             }));
//             actionsHtml = actionHtmls.join('');
//         }

//         // Check if we need the overflow icon
//         // Either we have explicit overflow items OR we have items but none were shown
//         const hasOverflow = overflowItems.length > 0 || (menuItems.length > 0 && visibleItems.length === 0);

//         const overflowHtml = `
//             <div class="toolbar-overflow" style="padding: 12px; cursor: pointer; display: flex; align-items: center;" title="More options">
//                 <svg width="4" height="16" viewBox="0 0 4 16">
//                     <path d="M2 2a2 2 0 1 1 0 4 2 2 0 0 1 0-4zm0 6a2 2 0 1 1 0 4 2 2 0 0 1 0-4zm0 6a2 2 0 1 1 0 4 2 2 0 0 1 0-4z" fill="${titleTextColor}"/>
//                 </svg>
//             </div>
//         `;

//         const layoutStyle = `
//             display: flex;
//             align-items: center;
//             width: 100%;
//             height: ${height};
//             min-height: ${minHeight};
//             box-shadow: 0 2px 4px rgba(0,0,0,0.2);
//             z-index: 10; /* Toolbar usually sits above */
//         `;

//         return `
//             <div class="android-view android-toolbar" style="${baseStyle} ${layoutStyle}">
//                 ${navHtml}
//                 ${titleHtml}
//                 ${childrenHtmlArray.join('')}
//                 <div class="toolbar-actions" style="display: flex; align-items: center; margin-inline-end: 8px;">
//                     ${actionsHtml}
//                     ${hasOverflow ? overflowHtml : ''} 
//                 </div>
//             </div>
//         `;
//     }
// }


import { BaseView } from '../widgets/BaseView.js';
import { LinearSolver } from '../../solvers/LinearSolver.js';
import { ActionMenuItemView } from '../widgets/ActionMenuItemView.js';

export class Toolbar extends BaseView {
    constructor(resolver) {
        super(resolver);
        this.solver = new LinearSolver();
        this.menuItemRenderer = new ActionMenuItemView(resolver);
    }

    async render(node, renderChildCallback, parentType) {
        const attr = node.attributes;
        const baseStyle = await this.getBaseStyles(attr, parentType);
        const get = (name) => attr[name] || attr[`android:${name}`] || attr[`app:${name}`];

        // 1. Toolbar Properties
        const title = get('title') || 'Toolbar';
        const subtitle = get('subtitle');
        const navIcon = get('navigationIcon');
        const titleTextColor = this.resolver.resolveColor(get('titleTextColor') || '#FFFFFF');
        
        let minHeight = this.converter.parse(get('minHeight') || '56dp');
        let height = this.converter.parse(get('layout_height'));
        if (get('layout_height') === 'wrap_content') height = minHeight;

        if (!baseStyle.includes('background-color') && !baseStyle.includes('background:')) {
            baseStyle += 'background-color: #6200EE; ';
        }

        // 2. Render Navigation Icon
        let navHtml = '';
        if (navIcon) {
            const iconDrawable = await this.resolver.resolveDrawable(navIcon);
            let src = iconDrawable ? iconDrawable.value : ''; 
            if (src && src.includes('<svg')) {
                src = `data:image/svg+xml;utf8,${encodeURIComponent(src)}`;
            }
            navHtml = `
                <div class="toolbar-nav-icon" style="width: 24px; height: 24px; margin-inline-start: 16px; margin-inline-end: 16px; display: flex; align-items: center; justify-content: center; cursor: pointer;">
                    <img src="${src}" style="width: 24px; height: 24px; filter: brightness(0) invert(1);" />
                </div>
            `;
        }

        // 3. Render Title Area
        const titleHtml = `
            <div class="toolbar-title-content" style="display: flex; flex-direction: column; justify-content: center; flex: 1; margin-left: ${navIcon ? '0' : '16px'};">
                <span style="color: ${titleTextColor}; font-size: 20px; font-weight: 500; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">${title}</span>
                ${subtitle ? `<span style="color: ${titleTextColor}; opacity: 0.7; font-size: 14px;">${subtitle}</span>` : ''}
            </div>
        `;

        // 4. Render Menu Items (Fixed Logic 🔥)
        let actionsHtml = '';
        const menuItems = node.menuItems || []; 
        
        const childrenHtmlArray = await Promise.all(node.children.map(async child => {
            return await renderChildCallback(child, 'Toolbar', null, null);
        }));

        const maxActions = 2;
        let visibleItems = [];
        let overflowItems = [];

        if (menuItems.length > 0) {
            menuItems.forEach(item => {
                // 🔥 FIX: Check all possible attribute variations
                const a = item.attributes;
                const showAsAction = (a['app:showAsAction'] || a['android:showAsAction'] || a['showAsAction'] || '').toLowerCase();
                
                if (visibleItems.length < maxActions && (showAsAction.includes('ifroom') || showAsAction.includes('always'))) {
                    visibleItems.push(item);
                } else {
                    overflowItems.push(item);
                }
            });

            const actionHtmls = await Promise.all(visibleItems.map(async item => {
                return await this.menuItemRenderer.render(item, 'Toolbar');
            }));
            actionsHtml = actionHtmls.join('');
        }

        const hasOverflow = overflowItems.length > 0 || (menuItems.length > 0 && visibleItems.length === 0);

        // Overflow Icon Color should match Title Color
        const overflowHtml = `
            <div class="toolbar-overflow" style="padding: 12px; cursor: pointer; display: flex; align-items: center;" title="More options">
                <svg width="4" height="16" viewBox="0 0 4 16">
                    <path d="M2 2a2 2 0 1 1 0 4 2 2 0 0 1 0-4zm0 6a2 2 0 1 1 0 4 2 2 0 0 1 0-4zm0 6a2 2 0 1 1 0 4 2 2 0 0 1 0-4z" fill="${titleTextColor}"/>
                </svg>
            </div>
        `;

        const layoutStyle = `
            display: flex;
            align-items: center;
            width: 100%;
            height: ${height};
            min-height: ${minHeight};
            box-shadow: 0 2px 4px rgba(0,0,0,0.2);
            z-index: 10;
        `;

        return `
            <div class="android-view android-toolbar" style="${baseStyle} ${layoutStyle}">
                ${navHtml}
                ${titleHtml}
                ${childrenHtmlArray.join('')}
                <div class="toolbar-actions" style="display: flex; align-items: center; margin-inline-end: 8px;">
                    ${actionsHtml}
                    ${hasOverflow ? overflowHtml : ''}
                </div>
            </div>
        `;
    }
}