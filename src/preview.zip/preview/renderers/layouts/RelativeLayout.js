// last stable 95%
// import { ViewGroup } from '../widgets/ViewGroup.js';
// import { RelativeSolver } from '../../solvers/RelativeSolver.js';

// export class RelativeLayout extends ViewGroup {
//     constructor(resolver) {
//         super(resolver);
//         this.solver = new RelativeSolver();
//     }

//     render(node, renderChildCallback, parentType) {
//         return this.renderWithBounds(node, 360, 640, renderChildCallback, parentType);
//     }

//     _getAttr(attr, name) {
//         if (!attr) return null;
//         return attr[name] || attr[`android:${name}`] || attr[`app:${name}`];
//     }

//     async renderWithBounds(node, width, height, renderChildCallback, parentType) {
//         const attr = node.attributes;
//         const id = this._getAttr(attr, 'id') || 'unknown';

//         // 🔍 DEBUG LOG: Start
//         console.group(`[RelativeLayout Debug] ID: ${id}`);
//         console.log(`Input Bounds -> Width: ${width}, Height: ${height}`);

//         const rawStyle = await this.getBaseStyles(attr, parentType || 'ViewGroup');
        
//         // const cleanStyle = rawStyle.split(';').filter(part => {
//         //     const key = part.split(':')[0]?.trim();
//         //     if (!key) return false;
//         //     return !key.startsWith('padding') && 
//         //           !key.startsWith('margin') && 
//         //           !key.startsWith('height') && 
//         //           !key.startsWith('border'); 
//         // }).join('; ') + ';';
        
//         // We need border-radius, border-style, border-color for shapes to work!
//         const cleanStyle = rawStyle.split(';').filter(part => {
//             const key = part.split(':')[0]?.trim();
//             if (!key) return false;
//             return !key.startsWith('padding') && 
//                   !key.startsWith('margin') && 
//                   !key.startsWith('height') && 
//                   // Allow border-radius and other border props, only filter if strictly needed
//                   // (Usually BaseView handles borders correctly via __raw_css__)
//                   (!key.startsWith('border') || key.includes('radius') || key.includes('style') || key.includes('color') || key.includes('image')); 
//         }).join('; ') + ';';
        

//         // --- 🔥 FIX START: Respect Fixed Dimensions (50dp issue) ---
//         let w = width || 360;
//         let h = height || 640;

//         const wAttr = this._getAttr(attr, 'layout_width');
//         const hAttr = this._getAttr(attr, 'layout_height');

//         console.log(`Attributes -> layout_width: ${wAttr}, layout_height: ${hAttr}`);

//         // যদি layout_width ফিক্সড হয় (যেমন 300dp), তবে প্যারেন্টের width ওভাররাইড হবে
//         if (wAttr && wAttr !== 'match_parent' && wAttr !== 'wrap_content' && wAttr !== 'fill_parent') {
//             const parsedW = parseFloat(this.converter.parse(wAttr));
//             if (!isNaN(parsedW)) {
//                 console.log(`⚠️ Fixed Width Override: ${w} -> ${parsedW} (${wAttr})`);
//                 w = parsedW;
//             }
//         }

//         // যদি layout_height ফিক্সড হয় (যেমন 50dp), তবে প্যারেন্টের height ওভাররাইড হবে
//         // এইখানেই আপনার সমস্যা ছিল। আগে এটি প্যারেন্টের হাইট (অনেক বড়) ব্যবহার করছিল।
//         if (hAttr && hAttr !== 'match_parent' && hAttr !== 'wrap_content' && hAttr !== 'fill_parent') {
//             const parsedH = parseFloat(this.converter.parse(hAttr));
//             if (!isNaN(parsedH)) {
//                 console.log(`⚠️ Fixed Height Override: ${h} -> ${parsedH} (${hAttr})`);
//                 h = parsedH;
//             }
//         }
//         // --- 🔥 FIX END ---

//         const p = this._getAttr(attr, 'padding');
//         const pl = this.parsePx(this._getAttr(attr, 'paddingLeft') || this._getAttr(attr, 'paddingStart') || p);
//         const pt = this.parsePx(this._getAttr(attr, 'paddingTop') || p);
//         const pr = this.parsePx(this._getAttr(attr, 'paddingRight') || this._getAttr(attr, 'paddingEnd') || p);
//         const pb = this.parsePx(this._getAttr(attr, 'paddingBottom') || p);

//         const padding = { left: pl, top: pt, right: pr, bottom: pb };

//         // Auto IDs generation
//         node.children.forEach((child, index) => {
//             const hasId = child.attributes.id || child.attributes['android:id'];
//             if (!hasId) {
//                 child.attributes.id = `__auto_id_rel_${index}_${Date.now()}`;
//             }
//         });

//         // Detect wrap_content
//         const isWrapContent = hAttr === 'wrap_content';

//         console.log(`Solver Params -> W: ${w}, H: ${h}, isWrapContent: ${isWrapContent}`);

//         // SOLVE POSITIONS
//         // এখানে এখন কারেক্ট 'h' (50dp এর parsed value) পাস হবে
//         const solvedStyles = this.solver.solve(node.children, w, h, padding, isWrapContent);

//         // 🔥 FIX: Height Logic Update
//         let cssHeight = '100%';
        
//         if (isWrapContent) {
//             let maxBottom = 0;
//             solvedStyles.forEach(s => {
//                 const styleTop = s.css.match(/top:\s*([\d.]+)px/);
//                 const topVal = styleTop ? parseFloat(styleTop[1]) : 0;
//                 const bottom = topVal + s.height;
//                 if (bottom > maxBottom) maxBottom = bottom;
//             });
//             console.log(`Calculated Wrap Height: ${maxBottom + pb}`);
//             cssHeight = `${maxBottom + pb}px !important`;
//         } 
//         else if (hAttr !== 'match_parent' && hAttr !== 'fill_parent') {
//             // If exact height is provided (e.g. 50dp), use it!
//             if (h > 0) cssHeight = `${h}px`;
//         }

//         console.log(`Final CSS Height: ${cssHeight}`);
//         console.groupEnd(); // End Debug Log

//         const layoutStyle = `
//             position: relative;
//             overflow: hidden;
//             width: 100%;
//             height: ${cssHeight};
//         `;

//         const childrenHtmlArray = await Promise.all(node.children.map(async child => {
//             const rawId = this._getAttr(child.attributes, 'id');
//             const id = rawId?.replace(/@\+?id\//, '');
            
//             let absStyle = 'position:absolute; left:0; top:0;';
//             let childW = w; 
//             let childH = h;

//             if (id && solvedStyles.has(id)) {
//                 const solution = solvedStyles.get(id);
//                 absStyle = solution.css;
//                 childW = solution.width;
//                 childH = solution.height;
//             }

//             // চাইল্ড রেন্ডার করার সময় কারেক্ট বাউন্ডস পাস করা হচ্ছে
//             let html = await renderChildCallback(child, 'RelativeLayout', childW, childH); 
            
//             return html.replace(/style="([^"]*)"/, (match, existingStyle) => {
//                 const cleanedStyle = existingStyle.replace(/margin[^;]+;/g, '');
//                 return `style="${absStyle} ${cleanedStyle}"`;
//             });
//         }));

//         return `
//             <div class="android-layout relative-layout" style="${cleanStyle} ${layoutStyle}">
//                 ${childrenHtmlArray.join('')}
//             </div>
//         `;
//     }

//     parsePx(val) {
//         if (!val) return 0;
//         return parseFloat(this.converter.parse(val)) || 0;
//     }
// }



// verticale height fix   center problem 
import { ViewGroup } from '../widgets/ViewGroup.js';
import { RelativeSolver } from '../../solvers/RelativeSolver.js';

export class RelativeLayout extends ViewGroup {
    constructor(resolver) {
        super(resolver);
        this.solver = new RelativeSolver();
    }

    render(node, renderChildCallback, parentType) {
        return this.renderWithBounds(node, 360, 640, renderChildCallback, parentType);
    }

    _getAttr(attr, name) {
        if (!attr) return null;
        return attr[name] || attr[`android:${name}`] || attr[`app:${name}`];
    }

    async renderWithBounds(node, width, height, renderChildCallback, parentType) {
        const attr = node.attributes;
        const rawStyle = await this.getBaseStyles(attr, parentType || 'ViewGroup');
        
        // 🔥 FIX: Remove 'padding' from CSS. 
        // We want the Solver to handle all positioning (x, y) including padding.
        // If we keep CSS padding, it might shift absolute children incorrectly or cause double padding.
        const cleanStyle = rawStyle.split(';').filter(part => {
            const key = part.split(':')[0]?.trim();
            if (!key) return false;
            return !key.startsWith('padding') && // 🔥 STRIP CSS PADDING
                   !key.startsWith('margin') && 
                   !key.startsWith('height') && 
                   (!key.startsWith('border') || key.includes('radius') || key.includes('style') || key.includes('color') || key.includes('image')); 
        }).join('; ') + ';';

        let w = width || 360;
        let h = height || 640;

        // 🔥 FIX: Respect Fixed Height/Width from XML explicitly
        const wAttr = this._getAttr(attr, 'layout_width');
        const hAttr = this._getAttr(attr, 'layout_height');

        if (wAttr && wAttr !== 'match_parent' && wAttr !== 'wrap_content') {
            const parsed = this.parsePx(wAttr);
            if (parsed > 0) w = parsed;
        }
        if (hAttr && hAttr !== 'match_parent' && hAttr !== 'wrap_content') {
            const parsed = this.parsePx(hAttr);
            if (parsed > 0) h = parsed;
        }

        // Padding Logic for Solver
        const p = this._getAttr(attr, 'padding');
        const pl = this.parsePx(this._getAttr(attr, 'paddingLeft') || this._getAttr(attr, 'paddingStart') || p);
        const pt = this.parsePx(this._getAttr(attr, 'paddingTop') || p);
        const pr = this.parsePx(this._getAttr(attr, 'paddingRight') || this._getAttr(attr, 'paddingEnd') || p);
        const pb = this.parsePx(this._getAttr(attr, 'paddingBottom') || p);

        const padding = { left: pl, top: pt, right: pr, bottom: pb };

        // Auto IDs generation
        node.children.forEach((child, index) => {
            const hasId = child.attributes.id || child.attributes['android:id'];
            if (!hasId) {
                child.attributes.id = `__auto_id_rel_${index}_${Date.now()}`;
            }
        });

        const isWrapContent = hAttr === 'wrap_content';

        // SOLVE POSITIONS
        const solvedStyles = this.solver.solve(node.children, w, h, padding, isWrapContent);

        let cssHeight = '100%';
        if (isWrapContent) {
            let maxBottom = 0;
            solvedStyles.forEach(s => {
                const styleTop = s.css.match(/top:\s*([\d.]+)px/);
                const topVal = styleTop ? parseFloat(styleTop[1]) : 0;
                const bottom = topVal + s.height;
                if (bottom > maxBottom) maxBottom = bottom;
            });
            cssHeight = `${maxBottom + pb}px !important`;
        } 
        else if (hAttr !== 'match_parent' && hAttr !== 'fill_parent') {
            if (h > 0) cssHeight = `${h}px`;
        }

        const layoutStyle = `
            position: relative;
            overflow: hidden;
            width: 100%;
            height: ${cssHeight};
        `;

        const childrenHtmlArray = await Promise.all(node.children.map(async child => {
            const rawId = this._getAttr(child.attributes, 'id');
            const id = rawId?.replace(/@\+?id\//, '');
            
            let absStyle = 'position:absolute; left:0; top:0;';
            let childW = w; 
            let childH = h;

            if (id && solvedStyles.has(id)) {
                const solution = solvedStyles.get(id);
                absStyle = solution.css;
                childW = solution.width;
                childH = solution.height;
            }

            let html = await renderChildCallback(child, 'RelativeLayout', childW, childH); 
            
            return html.replace(/style="([^"]*)"/, (match, existingStyle) => {
                const cleanedStyle = existingStyle.replace(/margin[^;]+;/g, '');
                return `style="${absStyle} ${cleanedStyle}"`;
            });
        }));

        return `
            <div class="android-layout relative-layout" style="${cleanStyle} ${layoutStyle}">
                ${childrenHtmlArray.join('')}
            </div>
        `;
    }

    parsePx(val) {
        if (!val) return 0;
        return parseFloat(this.converter.parse(val)) || 0;
    }
}